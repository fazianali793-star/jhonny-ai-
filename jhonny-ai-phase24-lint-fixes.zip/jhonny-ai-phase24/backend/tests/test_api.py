import hashlib, importlib, os, sys, uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app.main as api


def setup_function():
    root=Path('/tmp') / ('jhonny-test-'+uuid.uuid4().hex)
    root.mkdir()
    api.DATA_DIR=root; api.MEDIA_DIR=root/'media'; api.TEMP_DIR=root/'tmp'; api.DB_PATH=root/'test.sqlite3'
    api.MEDIA_DIR.mkdir(); api.TEMP_DIR.mkdir(); api.init_db()

def user_token(client, role='user', email=None):
    email=email or f'{uuid.uuid4().hex}@example.com'
    r=client.post('/api/auth/register',json={'name':'Test','email':email,'password':'long-test-password'})
    assert r.status_code==201
    if role!='user':
        with api.connect() as db: db.execute('UPDATE users SET role=? WHERE email=?',(role,email))
    r=client.post('/api/auth/login',json={'email':email,'password':'long-test-password'})
    assert r.status_code==200
    return r.json()['access_token'], email

def test_register_login_logout_and_session_expiry():
    c=TestClient(api.app); token,email=user_token(c)
    assert c.get('/api/auth/me',headers={'Authorization':f'Bearer {token}'}).status_code==200
    assert c.post('/api/auth/logout',headers={'Authorization':f'Bearer {token}'}).status_code==200
    assert c.get('/api/auth/me',headers={'Authorization':f'Bearer {token}'}).status_code==401
    assert c.post('/api/auth/register',json={'name':'Other','email':email,'password':'long-test-password'}).status_code==409

def test_server_side_admin_authorization():
    c=TestClient(api.app); token,_=user_token(c)
    assert c.get('/api/admin/submissions',headers={'Authorization':f'Bearer {token}'}).status_code==403
    assert c.get('/api/admin/submissions').status_code==401

def test_upload_rejects_unsupported_extension():
    c=TestClient(api.app); token,_=user_token(c,'creator')
    r=c.post('/api/clips/upload',headers={'Authorization':f'Bearer {token}'},files={'file':('script.exe',b'not a video','application/octet-stream')})
    assert r.status_code==415

def test_moderation_requires_active_license_and_admin():
    c=TestClient(api.app); creator_token,email=user_token(c,'creator')
    admin_token,_=user_token(c,'admin')
    clip_id=str(uuid.uuid4()); stored=clip_id+'.mp4'
    with api.connect() as db:
        db.execute('INSERT INTO clips(id,owner_id,title,original_name,stored_name,mime_type,size_bytes,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(clip_id,(db.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone()[0]),'test','test.mp4',stored,'video/mp4',10,'Pending',api.now_iso()))
        db.execute('INSERT INTO licenses(id,clip_id,status,allowed_uses,platform_restrictions,updated_at) VALUES(?,?,?,?,?,?)',(str(uuid.uuid4()),clip_id,'Pending Review','["personal"]','[]',api.now_iso()))
    assert c.post(f'/api/admin/clips/{clip_id}/moderate',headers={'Authorization':f'Bearer {creator_token}'},json={'action':'approve'}).status_code==403
    assert c.post(f'/api/admin/clips/{clip_id}/moderate',headers={'Authorization':f'Bearer {admin_token}'},json={'action':'approve'}).status_code==409

def test_download_rejects_unpublished_clip():
    c=TestClient(api.app); token,email=user_token(c)
    uid=None
    with api.connect() as db: uid=db.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone()[0]
    clip_id=str(uuid.uuid4())
    with api.connect() as db:
        db.execute('INSERT INTO clips(id,owner_id,title,original_name,stored_name,mime_type,size_bytes,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(clip_id,uid,'test','test.mp4',clip_id+'.mp4','video/mp4',10,'Pending',api.now_iso()))
        db.execute('INSERT INTO licenses(id,clip_id,status,allowed_uses,platform_restrictions,updated_at) VALUES(?,?,?,?,?,?)',(str(uuid.uuid4()),clip_id,'Active','["personal"]','[]',api.now_iso()))
    assert c.get(f'/api/clips/{clip_id}/download',headers={'Authorization':f'Bearer {token}'}).status_code==403

def test_project_ownership_is_enforced():
    c=TestClient(api.app); a,_=user_token(c); b,_=user_token(c)
    r=c.post('/api/projects',headers={'Authorization':f'Bearer {a}'},json={'name':'A project','settings':{'trim_start':0,'trim_end':10}})
    assert r.status_code==201
    assert c.put('/api/projects/'+r.json()['id'],headers={'Authorization':f'Bearer {b}'},json={'name':'Hijack','settings':{}}).status_code==403

def test_render_job_validation_and_owner_check():
    c=TestClient(api.app); a,_=user_token(c); b,_=user_token(c)
    p=c.post('/api/projects',headers={'Authorization':f'Bearer {a}'},json={'name':'No source'}).json()
    assert c.post(f"/api/projects/{p['id']}/renders",headers={'Authorization':f'Bearer {a}'},json={'trim_start':5,'trim_end':2}).status_code==400
    assert c.post(f"/api/projects/{p['id']}/renders",headers={'Authorization':f'Bearer {a}'},json={'trim_start':0,'trim_end':2}).status_code==400
    assert c.get('/api/renders/not-a-job',headers={'Authorization':f'Bearer {b}'}).status_code==404

def test_real_upload_license_approval_download_and_render_pipeline():
    import shutil, subprocess, time
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
        import pytest; pytest.skip('FFmpeg/FFprobe not installed')
    c=TestClient(api.app); creator_token,creator_email=user_token(c,'creator'); admin_token,_=user_token(c,'admin')
    source=api.TEMP_DIR/'fixture.mp4'
    subprocess.run(['ffmpeg','-y','-f','lavfi','-i','color=c=blue:s=160x284:d=2','-pix_fmt','yuv420p','-c:v','libx264',str(source)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True,timeout=30)
    with source.open('rb') as video:
        upload=c.post('/api/clips/upload',headers={'Authorization':f'Bearer {creator_token}'},files={'file':('fixture.mp4',video,'video/mp4')},data={'title':'Test fixture'})
    assert upload.status_code==201, upload.text
    clip=upload.json(); assert clip['status']=='Pending' and clip['duration']>0 and clip['width']==160
    assert c.get(f"/api/clips/{clip['id']}/download",headers={'Authorization':f'Bearer {creator_token}'}).status_code==403
    lic=c.put(f"/api/admin/clips/{clip['id']}/license",headers={'Authorization':f'Bearer {admin_token}'},json={'status':'Active','allowed_uses':['personal'],'platform_restrictions':[],'verification_note':'Rights documentation reviewed by admin'})
    assert lic.status_code==200, lic.text
    approved=c.post(f"/api/admin/clips/{clip['id']}/moderate",headers={'Authorization':f'Bearer {admin_token}'},json={'action':'approve','note':'rights verified'})
    assert approved.status_code==200 and approved.json()['status']=='Published'
    downloaded=c.get(f"/api/clips/{clip['id']}/download?requested_use=personal",headers={'Authorization':f'Bearer {creator_token}'})
    assert downloaded.status_code==200 and b'ftyp' in downloaded.content[:16]
    project=c.post('/api/projects',headers={'Authorization':f'Bearer {creator_token}'},json={'name':'Render test','source_clip_id':clip['id'],'settings':{}})
    assert project.status_code==201
    job=c.post(f"/api/projects/{project.json()['id']}/renders",headers={'Authorization':f'Bearer {creator_token}'},json={'trim_start':0,'trim_end':1,'width':144,'height':256,'aspect_ratio':'9:16','output_format':'mp4'})
    assert job.status_code==202, job.text
    status=c.get(f"/api/renders/{job.json()['id']}",headers={'Authorization':f'Bearer {creator_token}'})
    assert status.status_code==200 and status.json()['status']=='completed', status.text
    rendered=c.get(status.json()['download_url'],headers={'Authorization':f'Bearer {creator_token}'})
    assert rendered.status_code==200 and len(rendered.content)>1000


def test_admin_can_promote_creator_but_users_cannot():
    c=TestClient(api.app); admin_token,_=user_token(c,'admin'); user_token_value,email=user_token(c)
    with api.connect() as db: uid=db.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone()[0]
    assert c.put(f'/api/admin/users/{uid}/role',headers={'Authorization':f'Bearer {user_token_value}'},json={'role':'creator'}).status_code==403
    r=c.put(f'/api/admin/users/{uid}/role',headers={'Authorization':f'Bearer {admin_token}'},json={'role':'creator'})
    assert r.status_code==200 and r.json()['role']=='creator'

def test_expired_session_is_rejected():
    c=TestClient(api.app); token,email=user_token(c)
    with api.connect() as db: db.execute('UPDATE sessions SET expires_at=0 WHERE token_hash=?',(hashlib.sha256(token.encode()).hexdigest(),))
    assert c.get('/api/auth/me',headers={'Authorization':f'Bearer {token}'}).status_code==401


def test_public_library_only_returns_published_active_unexpired_clips():
    c=TestClient(api.app); creator_token,email=user_token(c,'creator')
    with api.connect() as db:
        owner=db.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone()['id']
        for title,status,license_status,expiry in [
            ('Public allowed','Published','Active',None),
            ('Pending hidden','Pending','Active',None),
            ('Revoked hidden','Published','Revoked',None),
            ('Expired hidden','Published','Active','2000-01-01T00:00:00+00:00'),
        ]:
            cid=str(uuid.uuid4())
            db.execute('INSERT INTO clips(id,owner_id,title,original_name,stored_name,mime_type,size_bytes,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(cid,owner,title,title+'.mp4',cid+'.mp4','video/mp4',10,status,api.now_iso()))
            db.execute('INSERT INTO licenses(id,clip_id,status,allowed_uses,expires_at,platform_restrictions,updated_at) VALUES(?,?,?,?,?,?,?)',(str(uuid.uuid4()),cid,license_status,'["personal"]',expiry,'[]',api.now_iso()))
    response=c.get('/api/clips?q=Public')
    assert response.status_code==200
    assert response.json()['total']==1
    assert response.json()['items'][0]['title']=='Public allowed'



def test_public_library_compares_license_expiry_as_timezone_aware_instants():
    """An expiry written in a positive timezone offset must not leak after it expires."""
    c = TestClient(api.app)
    _, email = user_token(c, 'creator')
    with api.connect() as db:
        owner = db.execute('SELECT id FROM users WHERE email=?', (email,)).fetchone()['id']
        cid = str(uuid.uuid4())
        db.execute(
            'INSERT INTO clips(id,owner_id,title,original_name,stored_name,mime_type,size_bytes,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)',
            (cid, owner, 'Offset-expired clip', 'clip.mp4', cid + '.mp4', 'video/mp4', 10, 'Published', api.now_iso())
        )
        # 20:00 at UTC+14 is 06:00 UTC; test with a stable far-past instant instead
        # of depending on the wall clock's exact minute.
        expired_offset = (datetime.now(timezone.utc) - timedelta(hours=2)).astimezone(
            timezone(timedelta(hours=14))
        ).isoformat()
        db.execute(
            'INSERT INTO licenses(id,clip_id,status,allowed_uses,expires_at,platform_restrictions,updated_at) VALUES(?,?,?,?,?,?,?)',
            (str(uuid.uuid4()), cid, 'Active', '["personal"]', expired_offset, '[]', api.now_iso())
        )
    response = c.get('/api/clips?q=Offset-expired')
    assert response.status_code == 200
    assert response.json()['total'] == 0


def test_project_duplicate_and_delete_are_owner_scoped():
    c=TestClient(api.app); a,_=user_token(c); b,_=user_token(c)
    original=c.post('/api/projects',headers={'Authorization':f'Bearer {a}'},json={'name':'Original','settings':{'trim_start':1}}).json()
    duplicate=c.post(f"/api/projects/{original['id']}/duplicate",headers={'Authorization':f'Bearer {a}'})
    assert duplicate.status_code==201 and duplicate.json()['settings']['trim_start']==1
    assert c.delete(f"/api/projects/{original['id']}",headers={'Authorization':f'Bearer {b}'}).status_code==404
    assert c.delete(f"/api/projects/{original['id']}",headers={'Authorization':f'Bearer {a}'}).status_code==200


def test_clip_detail_hides_private_storage_and_restricted_clips():
    c=TestClient(api.app); creator_token,email=user_token(c,'creator'); anon=TestClient(api.app)
    with api.connect() as db:
        owner=db.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone()['id']
        cid=str(uuid.uuid4())
        db.execute('INSERT INTO clips(id,owner_id,title,original_name,stored_name,mime_type,size_bytes,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(cid,owner,'A public title','secret-private-name.mp4',cid+'.mp4','video/mp4',12,'Published',api.now_iso()))
        db.execute('INSERT INTO licenses(id,clip_id,status,allowed_uses,platform_restrictions,updated_at) VALUES(?,?,?,?,?,?)',(str(uuid.uuid4()),cid,'Active','["personal"]','[]',api.now_iso()))
    detail=anon.get('/api/clips/'+cid)
    assert detail.status_code==200
    assert 'stored_name' not in detail.json() and 'original_name' not in detail.json() and 'owner_id' not in detail.json()
    assert anon.get('/api/clips/missing-private-clip').status_code==404


def test_admin_analytics_users_creators_licenses_reports_are_protected_and_real():
    c=TestClient(api.app); token,email=user_token(c); admin,_=user_token(c,'admin')
    for path in ('/api/admin/analytics','/api/admin/users','/api/admin/creators','/api/admin/licenses','/api/admin/reports','/api/admin/moderation'):
        assert c.get(path,headers={'Authorization':f'Bearer {token}'}).status_code==403
        assert c.get(path).status_code==401
    response=c.get('/api/admin/analytics',headers={'Authorization':f'Bearer {admin}'})
    assert response.status_code==200 and 'completed_downloads' in response.json()
    report=c.post('/api/reports',json={'reporter_name':'Reporter','reporter_email':'reporter@example.com','reason':'Copyright','details':'This report includes a detailed claim.'})
    assert report.status_code==201
    listing=c.get('/api/admin/reports',headers={'Authorization':f'Bearer {admin}'})
    assert listing.status_code==200 and any(r['id']==report.json()['id'] for r in listing.json())
    assert c.put('/api/admin/reports/'+report.json()['id'],headers={'Authorization':f'Bearer {admin}'},json={'status':'Resolved'}).status_code==200


def test_download_does_not_record_denied_requests():
    c=TestClient(api.app); token,email=user_token(c)
    with api.connect() as db:
        owner=db.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone()['id']; cid=str(uuid.uuid4())
        db.execute('INSERT INTO clips(id,owner_id,title,original_name,stored_name,mime_type,size_bytes,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(cid,owner,'pending','pending.mp4',cid+'.mp4','video/mp4',4,'Pending',api.now_iso()))
        db.execute('INSERT INTO licenses(id,clip_id,status,allowed_uses,platform_restrictions,updated_at) VALUES(?,?,?,?,?,?)',(str(uuid.uuid4()),cid,'Active','["personal"]','[]',api.now_iso()))
    assert c.get(f'/api/clips/{cid}/download',headers={'Authorization':f'Bearer {token}'}).status_code==403
    with api.connect() as db: assert db.execute('SELECT COUNT(*) n FROM downloads').fetchone()['n']==0


def _insert_clip_with_license(owner_id, *, status='Published', license_status='Active', expiry=None, stored_name=None):
    clip_id = str(uuid.uuid4())
    stored_name = stored_name or f'{clip_id}.mp4'
    with api.connect() as db:
        db.execute('INSERT INTO clips(id,owner_id,title,original_name,stored_name,mime_type,size_bytes,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)',
                   (clip_id, owner_id, 'Regression clip', 'regression.mp4', stored_name, 'video/mp4', 100, status, api.now_iso()))
        db.execute('INSERT INTO licenses(id,clip_id,status,allowed_uses,expires_at,platform_restrictions,updated_at) VALUES(?,?,?,?,?,?,?)',
                   (str(uuid.uuid4()), clip_id, license_status, '["personal"]', expiry, '[]', api.now_iso()))
    return clip_id


def test_expired_license_cannot_be_downloaded_even_with_old_clip_id():
    c = TestClient(api.app); token, email = user_token(c)
    with api.connect() as db: owner = db.execute('SELECT id FROM users WHERE email=?', (email,)).fetchone()['id']
    clip_id = _insert_clip_with_license(owner, expiry='2000-01-01T00:00:00+00:00')
    assert c.get(f'/api/clips/{clip_id}/download', headers={'Authorization': f'Bearer {token}'}).status_code == 403


def test_removed_clip_cannot_be_downloaded():
    c = TestClient(api.app); token, email = user_token(c)
    with api.connect() as db: owner = db.execute('SELECT id FROM users WHERE email=?', (email,)).fetchone()['id']
    clip_id = _insert_clip_with_license(owner, status='Removed')
    assert c.get(f'/api/clips/{clip_id}/download', headers={'Authorization': f'Bearer {token}'}).status_code == 403


def test_missing_media_and_path_traversal_are_rejected():
    c = TestClient(api.app); token, email = user_token(c)
    with api.connect() as db: owner = db.execute('SELECT id FROM users WHERE email=?', (email,)).fetchone()['id']
    missing = _insert_clip_with_license(owner)
    assert c.get(f'/api/clips/{missing}/download', headers={'Authorization': f'Bearer {token}'}).status_code == 404
    traversal = _insert_clip_with_license(owner, stored_name='../../etc/passwd')
    assert c.get(f'/api/clips/{traversal}/download', headers={'Authorization': f'Bearer {token}'}).status_code == 404


def test_admin_role_cannot_be_granted_through_role_endpoint():
    c = TestClient(api.app); admin, _ = user_token(c, 'admin'); token, email = user_token(c)
    with api.connect() as db: uid = db.execute('SELECT id FROM users WHERE email=?', (email,)).fetchone()['id']
    assert c.put(f'/api/admin/users/{uid}/role', headers={'Authorization': f'Bearer {admin}'}, json={'role': 'admin'}).status_code == 400
    assert c.put(f'/api/admin/users/{uid}/role', headers={'Authorization': f'Bearer {token}'}, json={'role': 'creator'}).status_code == 403


def test_login_rate_limit_returns_429_and_retry_after():
    c=TestClient(api.app)
    email=f'{uuid.uuid4().hex}@example.com'
    for _ in range(10):
        response=c.post('/api/auth/login',json={'email':email,'password':'incorrect-password'})
        assert response.status_code==401
    limited=c.post('/api/auth/login',json={'email':email,'password':'incorrect-password'})
    assert limited.status_code==429
    assert int(limited.headers['Retry-After']) >= 1


def test_public_report_rate_limit_is_scoped_to_reporter_email():
    c=TestClient(api.app)
    payload={'reporter_name':'Test Reporter','reporter_email':f'{uuid.uuid4().hex}@example.com','reason':'Copyright','details':'This is a detailed report for rate limit testing.'}
    for _ in range(5):
        response=c.post('/api/reports',json=payload)
        assert response.status_code==201, response.text
    limited=c.post('/api/reports',json=payload)
    assert limited.status_code==429



def test_registration_cannot_self_assign_privileged_role():
    c = TestClient(api.app)
    for role in ('creator', 'admin'):
        response = c.post('/api/auth/register', json={
            'name': 'Privilege escalation attempt',
            'email': f'{uuid.uuid4().hex}@example.com',
            'password': 'long-test-password',
            'role': role,
        })
        assert response.status_code == 400
        assert 'only register as user' in response.json()['detail']


def test_download_history_requires_auth_and_is_user_scoped():
    c=TestClient(api.app); token_a,email_a=user_token(c); token_b,email_b=user_token(c)
    with api.connect() as db:
        user_a=db.execute('SELECT id FROM users WHERE email=?',(email_a,)).fetchone()['id']
        user_b=db.execute('SELECT id FROM users WHERE email=?',(email_b,)).fetchone()['id']
        clip_id=str(uuid.uuid4())
        db.execute('INSERT INTO clips(id,owner_id,title,original_name,stored_name,mime_type,size_bytes,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(clip_id,user_a,'History fixture','fixture.mp4',clip_id+'.mp4','video/mp4',123,'Published',api.now_iso()))
        db.execute('INSERT INTO downloads(id,user_id,clip_id,requested_use,created_at) VALUES(?,?,?,?,?)',(str(uuid.uuid4()),user_a,clip_id,'personal',api.now_iso()))
    assert c.get('/api/me/downloads').status_code==401
    own=c.get('/api/me/downloads',headers={'Authorization':f'Bearer {token_a}'})
    other=c.get('/api/me/downloads',headers={'Authorization':f'Bearer {token_b}'})
    assert own.status_code==200 and own.json()['total']==1
    assert own.json()['items'][0]['clip_title']=='History fixture'
    assert other.status_code==200 and other.json()['total']==0


def test_revoked_license_and_disallowed_use_block_downloads():
    c = TestClient(api.app); token, email = user_token(c)
    with api.connect() as db:
        owner = db.execute('SELECT id FROM users WHERE email=?', (email,)).fetchone()['id']
    revoked = _insert_clip_with_license(owner, license_status='Revoked')
    restricted_use = _insert_clip_with_license(owner)
    with api.connect() as db:
        db.execute("UPDATE licenses SET allowed_uses='[\"personal\"]' WHERE clip_id=?", (restricted_use,))
        db.execute("UPDATE licenses SET platform_restrictions='[\"blocked-platform\"]' WHERE clip_id=?", (restricted_use,))
    for clip_id in (revoked, restricted_use):
        (api.MEDIA_DIR / f'{clip_id}.mp4').write_bytes(b'fixture-media')
    headers = {'Authorization': f'Bearer {token}'}
    assert c.get(f'/api/clips/{revoked}/download', headers=headers).status_code == 403
    assert c.get(f'/api/clips/{restricted_use}/download?requested_use=commercial', headers=headers).status_code == 403
    assert c.get(f'/api/clips/{restricted_use}/download?platform=blocked-platform', headers=headers).status_code == 403


def test_license_expiry_is_normalized_and_invalid_values_are_rejected():
    c = TestClient(api.app); admin_token, _ = user_token(c, 'admin'); creator_token, email = user_token(c, 'creator')
    with api.connect() as db:
        owner = db.execute('SELECT id FROM users WHERE email=?', (email,)).fetchone()['id']
    clip_id = _insert_clip_with_license(owner)
    headers = {'Authorization': f'Bearer {admin_token}'}
    payload = {'status': 'Active', 'allowed_uses': ['personal'], 'platform_restrictions': [], 'verification_note': 'Rights evidence checked'}
    future_offset = (datetime.now(timezone.utc) + timedelta(days=2)).astimezone(timezone(timedelta(hours=5))).isoformat()
    response = c.put(f'/api/admin/clips/{clip_id}/license', headers=headers, json={**payload, 'expires_at': future_offset})
    assert response.status_code == 200, response.text
    with api.connect() as db:
        stored = db.execute('SELECT expires_at FROM licenses WHERE clip_id=?', (clip_id,)).fetchone()['expires_at']
    assert stored.endswith('+00:00')
    invalid = c.put(f'/api/admin/clips/{clip_id}/license', headers=headers, json={**payload, 'expires_at': 'not-a-date'})
    assert invalid.status_code == 400



def test_creator_license_listing_is_scoped_to_authenticated_owner():
    c = TestClient(api.app)
    creator_token, creator_email = user_token(c, 'creator')
    other_token, other_email = user_token(c, 'creator')
    ordinary_token, _ = user_token(c, 'user')
    creator_id = None
    other_id = None
    with api.connect() as db:
        creator_id = db.execute('SELECT id FROM users WHERE email=?', (creator_email,)).fetchone()['id']
        other_id = db.execute('SELECT id FROM users WHERE email=?', (other_email,)).fetchone()['id']
        for owner_id, title in ((creator_id, 'Creator A clip'), (other_id, 'Creator B clip')):
            clip_id = str(uuid.uuid4())
            db.execute(
                'INSERT INTO clips(id,owner_id,title,original_name,stored_name,mime_type,size_bytes,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)',
                (clip_id, owner_id, title, 'source.mp4', clip_id + '.mp4', 'video/mp4', 100, 'Pending', api.now_iso())
            )
            db.execute(
                'INSERT INTO licenses(id,clip_id,status,allowed_uses,platform_restrictions,updated_at) VALUES(?,?,?,?,?,?)',
                (str(uuid.uuid4()), clip_id, 'Pending Review', '["personal"]', '[]', api.now_iso())
            )

    own = c.get('/api/me/licenses', headers={'Authorization': f'Bearer {creator_token}'})
    assert own.status_code == 200
    assert own.json()['total'] == 1
    assert own.json()['items'][0]['clip_title'] == 'Creator A clip'
    assert c.get('/api/me/licenses', headers={'Authorization': f'Bearer {other_token}'}).json()['items'][0]['clip_title'] == 'Creator B clip'
    assert c.get('/api/me/licenses', headers={'Authorization': f'Bearer {ordinary_token}'}).status_code == 403
    assert c.get('/api/me/licenses').status_code == 401



def test_render_does_not_mark_missing_output_as_completed(monkeypatch):
    c = TestClient(api.app)
    token, email = user_token(c, 'creator')
    with api.connect() as db:
        owner_id = db.execute('SELECT id FROM users WHERE email=?', (email,)).fetchone()['id']
        project_id = str(uuid.uuid4())
        job_id = str(uuid.uuid4())
        stamp = api.now_iso()
        db.execute(
            'INSERT INTO projects(id,owner_id,name,source_clip_id,settings_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',
            (project_id, owner_id, 'Render regression', None, '{}', stamp, stamp)
        )
        db.execute(
            "INSERT INTO render_jobs(id,project_id,owner_id,status,progress,created_at,updated_at) VALUES(?,?,?,'running',5,?,?)",
            (job_id, project_id, owner_id, stamp, stamp)
        )
    monkeypatch.setattr(api.shutil, 'which', lambda name: '/usr/bin/ffmpeg')
    import io
    class FakeProcess:
        def __init__(self, *args, **kwargs):
            self.stdout = io.StringIO('out_time_us=500000\nprogress=continue\nprogress=end\n')
            self.stderr = io.StringIO('')
            self.returncode = 0
        def poll(self): return self.returncode
        def wait(self, timeout=None): return self.returncode
        def kill(self): self.returncode = -9
    monkeypatch.setattr(api.subprocess, 'Popen', FakeProcess)
    source = api.MEDIA_DIR / 'source.mp4'
    source.write_bytes(b'fake source')
    api.run_render(job_id, {'id': project_id}, source, {
        'trim_start': 0, 'trim_end': 1, 'width': 1080, 'height': 1920
    })
    with api.connect() as db:
        row = db.execute('SELECT status,output_name,error FROM render_jobs WHERE id=?', (job_id,)).fetchone()
    assert row['status'] == 'failed'
    assert row['output_name'] is None
    assert 'no usable output file' in row['error']


def test_creator_clip_listing_is_authenticated_owner_scoped():
    c = TestClient(api.app)
    creator_token, creator_email = user_token(c, 'creator')
    other_token, other_email = user_token(c, 'creator')
    with api.connect() as db:
        owner = db.execute('SELECT id FROM users WHERE email=?', (creator_email,)).fetchone()['id']
        other_owner = db.execute('SELECT id FROM users WHERE email=?', (other_email,)).fetchone()['id']
        own_id = str(uuid.uuid4())
        other_id = str(uuid.uuid4())
        for cid, uid, title in ((own_id, owner, 'My private upload'), (other_id, other_owner, 'Another creators upload')):
            db.execute(
                'INSERT INTO clips(id,owner_id,title,original_name,stored_name,mime_type,size_bytes,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)',
                (cid, uid, title, r'C:\\private\\source.mp4', cid + '.mp4', 'video/mp4', 123, 'Pending', api.now_iso())
            )
            db.execute(
                'INSERT INTO licenses(id,clip_id,status,allowed_uses,platform_restrictions,verification_note,updated_at) VALUES(?,?,?,?,?,?,?)',
                (str(uuid.uuid4()), cid, 'Pending Review', '["personal"]', '[]', '', api.now_iso())
            )
    assert c.get('/api/me/clips').status_code == 401
    ordinary_token, _ = user_token(c, 'user')
    assert c.get('/api/me/clips', headers={'Authorization': f'Bearer {ordinary_token}'}).status_code == 403
    response = c.get('/api/me/clips', headers={'Authorization': f'Bearer {creator_token}'})
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload['total'] == 1
    assert payload['items'][0]['id'] == own_id
    assert 'stored_name' not in payload['items'][0]
    assert 'original_name' not in payload['items'][0]
    assert c.get('/api/me/clips', headers={'Authorization': f'Bearer {other_token}'}).json()['total'] == 1


def test_approval_requires_documented_rights_even_for_legacy_active_license():
    c = TestClient(api.app)
    creator_token, email = user_token(c, 'creator')
    admin_token, _ = user_token(c, 'admin')
    with api.connect() as db:
        owner = db.execute('SELECT id FROM users WHERE email=?', (email,)).fetchone()['id']
        clip_id = str(uuid.uuid4())
        db.execute(
            'INSERT INTO clips(id,owner_id,title,original_name,stored_name,mime_type,size_bytes,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)',
            (clip_id, owner, 'Legacy active license', 'source.mp4', clip_id + '.mp4', 'video/mp4', 10, 'Pending', api.now_iso())
        )
        db.execute(
            'INSERT INTO licenses(id,clip_id,status,allowed_uses,platform_restrictions,verification_note,updated_at) VALUES(?,?,?,?,?,?,?)',
            (str(uuid.uuid4()), clip_id, 'Active', '["personal"]', '[]', '', api.now_iso())
        )
    response = c.post(f'/api/admin/clips/{clip_id}/moderate', headers={'Authorization': f'Bearer {admin_token}'}, json={'action': 'approve'})
    assert response.status_code == 409
    assert 'rights verification' in response.json()['detail'].lower()
    assert c.post(f'/api/admin/clips/{clip_id}/moderate', headers={'Authorization': f'Bearer {creator_token}'}, json={'action': 'approve'}).status_code == 403


def test_expired_license_cannot_be_activated():
    c = TestClient(api.app)
    creator_token, email = user_token(c, 'creator')
    admin_token, _ = user_token(c, 'admin')
    with api.connect() as db:
        owner = db.execute('SELECT id FROM users WHERE email=?', (email,)).fetchone()['id']
        clip_id = str(uuid.uuid4())
        db.execute(
            'INSERT INTO clips(id,owner_id,title,original_name,stored_name,mime_type,size_bytes,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)',
            (clip_id, owner, 'Expired license', 'source.mp4', clip_id + '.mp4', 'video/mp4', 10, 'Pending', api.now_iso())
        )
        db.execute(
            'INSERT INTO licenses(id,clip_id,status,allowed_uses,platform_restrictions,verification_note,updated_at) VALUES(?,?,?,?,?,?,?)',
            (str(uuid.uuid4()), clip_id, 'Pending Review', '["personal"]', '[]', '', api.now_iso())
        )
    response = c.put(f'/api/admin/clips/{clip_id}/license', headers={'Authorization': f'Bearer {admin_token}'}, json={
        'status': 'Active', 'allowed_uses': ['personal'], 'expires_at': '2000-01-01T00:00:00Z',
        'platform_restrictions': [], 'verification_note': 'Rights reviewed with documentation'
    })
    assert response.status_code == 400
    assert c.get(f'/api/clips/{clip_id}/download?requested_use=personal', headers={'Authorization': f'Bearer {creator_token}'}).status_code == 403


def test_upload_filename_sanitization_handles_windows_paths_and_controls():
    assert api.safe_upload_filename(r'C:\\private\\..\\clip.mp4') == 'clip.mp4'
    assert api.safe_upload_filename('..\\..\\bad\nname.mp4') == 'badname.mp4'
    assert api.safe_upload_filename(None) == 'upload'


def test_upload_rejects_blank_title_before_writing_media():
    c = TestClient(api.app)
    token, _ = user_token(c, 'creator')
    response = c.post(
        '/api/clips/upload',
        headers={'Authorization': f'Bearer {token}'},
        files={'file': ('clip.mp4', b'not a video', 'video/mp4')},
        data={'title': '   '}
    )
    assert response.status_code == 422
    assert 'title cannot be empty' in response.json()['detail'].lower()
    assert list(api.TEMP_DIR.iterdir()) == []
    assert list(api.MEDIA_DIR.iterdir()) == []


def test_health_endpoint_checks_database_and_hides_database_errors(monkeypatch):
    from fastapi.testclient import TestClient
    c = TestClient(api.app)
    healthy = c.get('/api/health')
    assert healthy.status_code == 200
    assert healthy.json()['checks']['database'] == 'ok'
    def broken_connect():
        raise api.sqlite3.OperationalError('private database path /srv/private/jhonny.sqlite3 unavailable')
    monkeypatch.setattr(api, 'connect', broken_connect)
    unavailable = c.get('/api/health')
    assert unavailable.status_code == 503
    assert 'private database path' not in unavailable.text


def test_render_failure_does_not_persist_private_ffmpeg_paths(monkeypatch):
    c = TestClient(api.app)
    token, email = user_token(c, 'creator')
    with api.connect() as db:
        owner_id = db.execute('SELECT id FROM users WHERE email=?', (email,)).fetchone()['id']
        project_id, job_id, stamp = str(uuid.uuid4()), str(uuid.uuid4()), api.now_iso()
        db.execute('INSERT INTO projects(id,owner_id,name,source_clip_id,settings_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',
                   (project_id, owner_id, 'Private render', None, '{}', stamp, stamp))
        db.execute("INSERT INTO render_jobs(id,project_id,owner_id,status,progress,created_at,updated_at) VALUES(?,?,?,'running',5,?,?)",
                   (job_id, project_id, owner_id, stamp, stamp))
    class FailedProcess:
        def __init__(self, *args, **kwargs):
            import io
            self.stdout = io.StringIO('')
            self.stderr = io.StringIO('File /private/server/path/source.mp4 failed\n')
            self.returncode = 1
        def poll(self): return self.returncode
        def wait(self, timeout=None): return self.returncode
        def kill(self): self.returncode = -9
    monkeypatch.setattr(api.shutil, 'which', lambda name: '/usr/bin/ffmpeg')
    monkeypatch.setattr(api.subprocess, 'Popen', FailedProcess)
    source = api.MEDIA_DIR / 'private-source.mp4'; source.write_bytes(b'not a real video')
    try:
        api.run_render(job_id, {'id': project_id}, source, {'trim_start': 0, 'trim_end': 1, 'width': 144, 'height': 256})
    finally:
        source.unlink(missing_ok=True)
    with api.connect() as db:
        row = db.execute('SELECT status,error FROM render_jobs WHERE id=?', (job_id,)).fetchone()
    assert row['status'] == 'failed'
    assert '/private/server/path' not in row['error']



def test_registration_rejects_whitespace_only_name():
    c = TestClient(api.app)
    response = c.post('/api/auth/register', json={
        'name': '   ', 'email': f'{uuid.uuid4().hex}@example.com',
        'password': 'long-test-password'
    })
    assert response.status_code == 422
    assert response.json()['detail'] == 'Name cannot be empty'


def test_render_download_is_owner_scoped_even_for_completed_job():
    c = TestClient(api.app)
    owner_token, _ = user_token(c)
    other_token, _ = user_token(c)
    project = c.post('/api/projects', headers={'Authorization': f'Bearer {owner_token}'},
                     json={'name': 'Owned project', 'settings': {}}).json()
    job_id = str(uuid.uuid4())
    output_name = f'{job_id}.mp4'
    (api.MEDIA_DIR / output_name).write_bytes(b'fake-media-fixture')
    with api.connect() as db:
        db.execute(
            "INSERT INTO render_jobs(id,project_id,owner_id,status,progress,output_name,created_at,updated_at) "
            "VALUES(?,?,?,'completed',100,?,?,?)",
            (job_id, project['id'], db.execute(
                'SELECT id FROM users WHERE email=?',
                (c.get('/api/auth/me', headers={'Authorization': f'Bearer {owner_token}'}).json()['email'],)
            ).fetchone()['id'], output_name, api.now_iso(), api.now_iso())
        )
    denied = c.get(f'/api/renders/{job_id}/download', headers={'Authorization': f'Bearer {other_token}'})
    assert denied.status_code == 403
    allowed = c.get(f'/api/renders/{job_id}/download', headers={'Authorization': f'Bearer {owner_token}'})
    assert allowed.status_code == 200
    assert allowed.content == b'fake-media-fixture'
