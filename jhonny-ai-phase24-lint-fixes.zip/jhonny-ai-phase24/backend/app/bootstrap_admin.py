"""Create or promote an admin using explicitly supplied environment variables.
Never run this on every application startup and never commit the credentials.
"""
import os, uuid
from .main import connect, password_hash, now_iso

def main():
    email=os.getenv('JHONNY_ADMIN_EMAIL','').strip().lower()
    password=os.getenv('JHONNY_ADMIN_PASSWORD','')
    name=os.getenv('JHONNY_ADMIN_NAME','JHONNY Administrator').strip()
    if not email or len(password)<16:
        raise SystemExit('Set JHONNY_ADMIN_EMAIL and JHONNY_ADMIN_PASSWORD (minimum 16 characters) before running this one-time command.')
    with connect() as db:
        row=db.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone()
        if row:
            db.execute("UPDATE users SET role='admin',password_hash=?,disabled=0 WHERE id=?",(password_hash(password),row['id']))
        else:
            db.execute('INSERT INTO users(id,name,email,password_hash,role,created_at) VALUES(?,?,?,?,?,?)',(str(uuid.uuid4()),name,email,password_hash(password),'admin',now_iso()))
    print('Admin account provisioned. Keep the credentials private and unset the environment variables.')
if __name__=='__main__': main()
