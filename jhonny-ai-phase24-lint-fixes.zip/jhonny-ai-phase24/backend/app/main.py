from __future__ import annotations
import hashlib, hmac, json, os, queue, secrets, shutil, sqlite3, subprocess, threading, time, uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form, Header, BackgroundTasks, Request
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr, Field
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parents[1]
load_dotenv(BASE_DIR.parent / '.env')
DATA_DIR = Path(os.getenv('JHONNY_DATA_DIR', str(BASE_DIR / 'data'))).resolve()
MEDIA_DIR = (DATA_DIR / 'media').resolve()
TEMP_DIR = (DATA_DIR / 'tmp').resolve()
DB_PATH = Path(os.getenv('JHONNY_DB_PATH', str(DATA_DIR / 'jhonny.sqlite3'))).resolve()
MAX_UPLOAD_BYTES = int(os.getenv('MAX_UPLOAD_BYTES', str(500 * 1024 * 1024)))
TOKEN_TTL_SECONDS = int(os.getenv('TOKEN_TTL_SECONDS', '3600'))
ALLOWED_EXTS = {'.mp4', '.mov', '.webm', '.mkv', '.m4v'}
ALLOWED_MIMES = {'video/mp4', 'video/quicktime', 'video/webm', 'video/x-matroska', 'video/x-m4v', 'application/octet-stream'}
for p in (DATA_DIR, MEDIA_DIR, TEMP_DIR): p.mkdir(parents=True, exist_ok=True)

app = FastAPI(title='JHONNY AI API', version='8.0.0')
allowed_origins = [x.strip() for x in os.getenv('JHONNY_CORS_ORIGINS', 'http://localhost:3000,http://127.0.0.1:3000').split(',') if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=allowed_origins, allow_credentials=False, allow_methods=['GET','POST','PUT','DELETE','OPTIONS'], allow_headers=['Authorization','Content-Type'])


def now_iso(): return datetime.now(timezone.utc).isoformat()

def normalize_expiry(value: Optional[str]) -> Optional[str]:
    """Validate license expiry timestamps and persist them in canonical UTC form."""
    if value is None or not value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value.strip().replace('Z', '+00:00'))
    except ValueError as exc:
        raise HTTPException(400, 'Invalid license expiry timestamp; use ISO 8601 format') from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc).isoformat()

def safe_upload_filename(value: Optional[str]) -> str:
    """Return a display filename safe across POSIX and Windows path separators."""
    raw = (value or 'upload').replace('\\', '/')
    name = Path(raw).name
    # Remove control characters and keep the user-supplied extension only as metadata.
    name = ''.join(ch for ch in name if ord(ch) >= 32 and ord(ch) != 127).strip(' .')
    return name[:255] or 'upload'

def license_is_expired(value: Optional[str]) -> bool:
    """Fail closed for malformed legacy timestamps; compare instants, not strings."""
    if not value:
        return False
    try:
        parsed = datetime.fromisoformat(value.strip().replace('Z', '+00:00'))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc) <= datetime.now(timezone.utc)
    except (TypeError, ValueError):
        return True

def enforce_rate_limit(request: Request, scope: str, limit: int, window_seconds: int, identity: str = ''):
    """SQLite-backed endpoint rate limit. Use a shared persistent DB for multi-worker deployments."""
    client_host = request.client.host if request.client else 'unknown'
    raw_key = f'{scope}|{client_host}|{identity.strip().lower()}'
    bucket_key = hashlib.sha256(raw_key.encode()).hexdigest()
    now = time.time()
    cutoff = now - window_seconds
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        db.execute('DELETE FROM rate_limit_events WHERE occurred_at < ?', (now - 86400,))
        count = db.execute(
            'SELECT COUNT(*) AS n FROM rate_limit_events WHERE bucket_key=? AND occurred_at>?',
            (bucket_key, cutoff)
        ).fetchone()['n']
        if count >= limit:
            oldest = db.execute(
                'SELECT MIN(occurred_at) AS first_at FROM rate_limit_events WHERE bucket_key=? AND occurred_at>?',
                (bucket_key, cutoff)
            ).fetchone()['first_at']
            retry_after = max(1, int(window_seconds - (now - oldest)))
            raise HTTPException(429, 'Too many requests. Please try again later.', headers={'Retry-After': str(retry_after)})
        db.execute('INSERT INTO rate_limit_events(bucket_key, occurred_at) VALUES(?,?)', (bucket_key, now))

def connect():
    con = sqlite3.connect(DB_PATH, timeout=15)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    return con

def init_db():
    with connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('user','creator','admin')), created_at TEXT NOT NULL, disabled INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at REAL NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS clips(id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES users(id), title TEXT NOT NULL, original_name TEXT NOT NULL, stored_name TEXT NOT NULL UNIQUE, mime_type TEXT NOT NULL, size_bytes INTEGER NOT NULL, duration REAL, width INTEGER, height INTEGER, codec TEXT, status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN ('Pending','Published','Rejected','Suspended','Removed')), created_at TEXT NOT NULL, moderated_at TEXT, moderated_by TEXT REFERENCES users(id), moderation_note TEXT);
        CREATE TABLE IF NOT EXISTS licenses(id TEXT PRIMARY KEY, clip_id TEXT NOT NULL UNIQUE REFERENCES clips(id) ON DELETE CASCADE, status TEXT NOT NULL DEFAULT 'Pending Review' CHECK(status IN ('Pending Review','Active','Revoked','Expired')), allowed_uses TEXT NOT NULL DEFAULT '["personal"]', expires_at TEXT, platform_restrictions TEXT NOT NULL DEFAULT '[]', verification_note TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, name TEXT NOT NULL, source_clip_id TEXT REFERENCES clips(id), settings_json TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS downloads(id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), clip_id TEXT NOT NULL REFERENCES clips(id), requested_use TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS moderation(id TEXT PRIMARY KEY, clip_id TEXT NOT NULL REFERENCES clips(id), admin_id TEXT NOT NULL REFERENCES users(id), action TEXT NOT NULL, note TEXT, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS reports(id TEXT PRIMARY KEY, clip_id TEXT REFERENCES clips(id) ON DELETE SET NULL, reporter_name TEXT NOT NULL, reporter_email TEXT NOT NULL, reason TEXT NOT NULL, details TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Open', created_at TEXT NOT NULL, resolved_at TEXT, resolved_by TEXT REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS render_jobs(id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE, owner_id TEXT NOT NULL REFERENCES users(id), status TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0, output_name TEXT, error TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);\n        CREATE TABLE IF NOT EXISTS rate_limit_events(id INTEGER PRIMARY KEY AUTOINCREMENT, bucket_key TEXT NOT NULL, occurred_at REAL NOT NULL);\n        CREATE INDEX IF NOT EXISTS rate_limit_bucket_time_idx ON rate_limit_events(bucket_key, occurred_at);
        CREATE INDEX IF NOT EXISTS clips_status_idx ON clips(status); CREATE INDEX IF NOT EXISTS clips_owner_created_idx ON clips(owner_id, created_at DESC); CREATE INDEX IF NOT EXISTS licenses_status_expiry_idx ON licenses(status, expires_at); CREATE INDEX IF NOT EXISTS sessions_expiry_idx ON sessions(expires_at);
        ''')
        # Lightweight forward migration for existing Phase 3 development databases.
        license_columns = {row['name'] for row in db.execute('PRAGMA table_info(licenses)').fetchall()}
        if 'verification_note' not in license_columns:
            db.execute("ALTER TABLE licenses ADD COLUMN verification_note TEXT NOT NULL DEFAULT ''")
        # Normalize historical timestamps so SQL-based public-library filtering compares UTC values.
        for license_row in db.execute('SELECT id, expires_at FROM licenses WHERE expires_at IS NOT NULL').fetchall():
            try:
                normalized = normalize_expiry(license_row['expires_at'])
            except HTTPException:
                normalized = '1970-01-01T00:00:00+00:00'  # malformed legacy values fail closed
            if normalized != license_row['expires_at']:
                db.execute('UPDATE licenses SET expires_at=? WHERE id=?', (normalized, license_row['id']))
init_db()

# Password hashing is intentionally stdlib-only. Tokens are opaque random bearer values; only hashes are stored.
def password_hash(password: str, salt: Optional[bytes] = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 310_000)
    return salt.hex() + '$' + digest.hex()
def verify_password(password: str, stored: str) -> bool:
    try:
        salt_hex, digest_hex = stored.split('$', 1)
        actual = hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(salt_hex), 310_000).hex()
        return hmac.compare_digest(actual, digest_hex)
    except (ValueError, TypeError): return False

def current_user(authorization: Optional[str] = Header(default=None)):
    if not authorization or not authorization.startswith('Bearer '): raise HTTPException(401, 'Authentication required')
    token = authorization[7:].strip()
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    with connect() as db:
        row = db.execute('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.disabled=0', (token_hash, time.time())).fetchone()
    if not row: raise HTTPException(401, 'Session expired or invalid')
    return dict(row)
def require_admin(user=Depends(current_user)):
    if user['role'] != 'admin': raise HTTPException(403, 'Administrator permission required')
    return user
def require_creator(user=Depends(current_user)):
    if user['role'] not in ('creator','admin'): raise HTTPException(403, 'Creator permission required')
    return user

def optional_user(authorization: Optional[str] = Header(default=None)):
    if not authorization: return None
    return current_user(authorization)

class RegisterIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    password: str = Field(min_length=10, max_length=256)
    role: str = 'user'
class LoginIn(BaseModel): email: EmailStr; password: str
class ProjectIn(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    source_clip_id: Optional[str] = None
    settings: dict = Field(default_factory=dict)
class ModerateIn(BaseModel): action: str; note: str = Field(default='', max_length=2000)
class LicenseIn(BaseModel): status: str; allowed_uses: list[str] = Field(default_factory=lambda: ['personal']); expires_at: Optional[str] = None; platform_restrictions: list[str] = Field(default_factory=list); verification_note: str = Field(default='', max_length=2000)
class RoleIn(BaseModel): role: str
class ReportIn(BaseModel): reporter_name: str = Field(min_length=1, max_length=120); reporter_email: EmailStr; reason: str = Field(min_length=1, max_length=80); details: str = Field(min_length=10, max_length=5000)
class ReportStatusIn(BaseModel): status: str
class RenderIn(BaseModel): trim_start: float = Field(ge=0); trim_end: float = Field(gt=0); width: int = Field(default=1080, ge=144, le=3840); height: int = Field(default=1920, ge=144, le=3840); aspect_ratio: str = '9:16'; output_format: str = 'mp4'

@app.get('/api/health')
def health():
    # Report readiness only after a lightweight database check; never leak DB errors.
    try:
        with connect() as db:
            db.execute('SELECT 1').fetchone()
    except sqlite3.Error:
        raise HTTPException(503, 'Service temporarily unavailable')
    return {'status':'ok','service':'jhonny-ai-api','version':'8.0.0','checks':{'database':'ok'}}

@app.post('/api/auth/register', status_code=201)
def register(payload: RegisterIn, request: Request):
    email = str(payload.email).strip().lower()
    name = payload.name.strip()
    enforce_rate_limit(request, 'register', 8, 3600, email)
    if payload.role != 'user':
        raise HTTPException(400, 'New accounts can only register as user; creator/admin roles require authorized promotion')
    if not name:
        raise HTTPException(422, 'Name cannot be empty')
    uid = str(uuid.uuid4())
    try:
        with connect() as db:
            db.execute(
                'INSERT INTO users(id,name,email,password_hash,role,created_at) VALUES(?,?,?,?,?,?)',
                (uid, name, email, password_hash(payload.password), 'user', now_iso())
            )
    except sqlite3.IntegrityError:
        raise HTTPException(409, 'An account with this email already exists')
    return {'id':uid,'name':name,'email':email,'role':'user'}

@app.post('/api/auth/login')
def login(payload: LoginIn, request: Request):
    enforce_rate_limit(request, 'login', 10, 300, payload.email)
    with connect() as db: user = db.execute('SELECT * FROM users WHERE email=? AND disabled=0', (payload.email.lower(),)).fetchone()
    if not user or not verify_password(payload.password, user['password_hash']): raise HTTPException(401, 'Email or password is incorrect')
    token = secrets.token_urlsafe(48); expiry = time.time() + TOKEN_TTL_SECONDS
    with connect() as db: db.execute('INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)', (hashlib.sha256(token.encode()).hexdigest(),user['id'],expiry,now_iso()))
    return {'access_token':token,'token_type':'bearer','expires_in':TOKEN_TTL_SECONDS,'user':{'id':user['id'],'name':user['name'],'email':user['email'],'role':user['role']}}

@app.get('/api/auth/me')
def me(user=Depends(current_user)): return {k:user[k] for k in ('id','name','email','role','created_at')}
@app.post('/api/auth/logout')
def logout(authorization: Optional[str] = Header(default=None), user=Depends(current_user)):
    token=authorization[7:].strip()
    with connect() as db: db.execute('DELETE FROM sessions WHERE token_hash=?',(hashlib.sha256(token.encode()).hexdigest(),))
    return {'logged_out':True}

async def inspect_media(path: Path):
    ffprobe = shutil.which('ffprobe')
    if not ffprobe: raise HTTPException(503, 'FFprobe is required for secure uploads. Install FFmpeg/FFprobe and add it to PATH.')
    try:
        proc = await __import__('asyncio').create_subprocess_exec(ffprobe,'-v','error','-select_streams','v:0','-show_entries','format=duration:stream=width,height,codec_name','-of','json',str(path),stdout=__import__('asyncio').subprocess.PIPE,stderr=__import__('asyncio').subprocess.PIPE)
        try:
            stdout, _ = await __import__('asyncio').wait_for(proc.communicate(), timeout=30)
        except __import__('asyncio').TimeoutError:
            proc.kill()
            await proc.wait()
            raise HTTPException(408, 'Video metadata inspection timed out. Try a smaller or simpler video.')
        if proc.returncode != 0: raise ValueError()
        data=json.loads(stdout); stream=(data.get('streams') or [{}])[0]; duration=float((data.get('format') or {}).get('duration') or 0)
        if duration <= 0 or not stream.get('width') or not stream.get('height'): raise ValueError()
        return {'duration':duration,'width':int(stream['width']),'height':int(stream['height']),'codec':stream.get('codec_name'),'warning':None}
    except HTTPException:
        raise
    except Exception: raise HTTPException(400, 'Uploaded file is not a readable video or its metadata is invalid')

@app.post('/api/clips/upload', status_code=201)
async def upload_clip(request: Request, file: UploadFile = File(...), title: str = Form(default='Untitled upload', max_length=200), user=Depends(require_creator)):
    enforce_rate_limit(request, 'upload', 12, 3600, user['id'])
    title = title.strip()
    if not title:
        await file.close()
        raise HTTPException(422, 'Video title cannot be empty')
    original_name = safe_upload_filename(file.filename)
    suffix=Path(original_name).suffix.lower()
    if suffix not in ALLOWED_EXTS or (file.content_type and file.content_type not in ALLOWED_MIMES):
        await file.close()
        raise HTTPException(415,'Unsupported video type. Use MP4, MOV, WEBM, MKV, or M4V.')
    clip_id=str(uuid.uuid4()); stored=f'{clip_id}{suffix}'; temp=TEMP_DIR / f'{clip_id}.upload'; final=MEDIA_DIR / stored; size=0
    try:
        with temp.open('xb') as out:
            while True:
                chunk=await file.read(1024*1024)
                if not chunk: break
                size += len(chunk)
                if size > MAX_UPLOAD_BYTES: raise HTTPException(413,f'Video exceeds maximum upload size ({MAX_UPLOAD_BYTES} bytes)')
                out.write(chunk)
        if size == 0: raise HTTPException(400,'Uploaded file is empty')
        metadata=await inspect_media(temp)
        temp.replace(final)
        with connect() as db:
            db.execute('INSERT INTO clips(id,owner_id,title,original_name,stored_name,mime_type,size_bytes,duration,width,height,codec,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(clip_id,user['id'],title[:200],original_name,stored,file.content_type or 'application/octet-stream',size,metadata['duration'],metadata['width'],metadata['height'],metadata['codec'],'Pending',now_iso()))
            db.execute('INSERT INTO licenses(id,clip_id,status,allowed_uses,expires_at,platform_restrictions,updated_at) VALUES(?,?,?,?,?,?,?)',(str(uuid.uuid4()),clip_id,'Pending Review','["personal"]',None,'[]',now_iso()))
        return {'id':clip_id,'title':title[:200],'status':'Pending','size_bytes':size,**metadata}
    except Exception:
        temp.unlink(missing_ok=True); final.unlink(missing_ok=True); raise
    finally: await file.close()

@app.get('/api/clips')
def list_clips(status: Optional[str]=None, q: Optional[str]=None, sort: str='newest', page: int=1, page_size: int=24, user=Depends(lambda authorization=Header(default=None): optional_user(authorization))):
    # Anonymous callers only ever receive currently published, licensed, non-expired clips.
    if sort not in ('newest','title','duration'): raise HTTPException(400,'Unsupported sort option')
    if page < 1 or page_size < 1 or page_size > 100: raise HTTPException(400,'Invalid pagination')
    order = {'newest':'c.created_at DESC','title':'c.title COLLATE NOCASE ASC','duration':'c.duration ASC'}[sort]
    with connect() as db:
        public_clause = "c.status='Published' AND l.status='Active' AND (l.expires_at IS NULL OR datetime(l.expires_at)>datetime(?))"
        args=[]
        if user is None:
            where=public_clause; args.append(now_iso())
        elif user['role']=='admin':
            where='(? IS NULL OR c.status=?)'; args.extend([status,status])
        else:
            where=f"(c.owner_id=? OR ({public_clause})) AND (? IS NULL OR c.status=?)"
            args.extend([user['id'],now_iso(),status,status])
        if q and q.strip(): where += ' AND lower(c.title) LIKE ?'; args.append('%'+q.strip().lower()[:120]+'%')
        rows=db.execute(f'SELECT c.*,l.status AS license_status,l.allowed_uses,l.expires_at,l.platform_restrictions FROM clips c LEFT JOIN licenses l ON l.clip_id=c.id WHERE {where} ORDER BY {order} LIMIT ? OFFSET ?',(*args,page_size,(page-1)*page_size)).fetchall()
        total=db.execute(f'SELECT COUNT(*) AS n FROM clips c LEFT JOIN licenses l ON l.clip_id=c.id WHERE {where}',args).fetchone()['n']
    safe_items=[]
    for row in rows:
        item=dict(row)
        for private_field in ('stored_name','original_name','moderated_by','moderation_note'):
            item.pop(private_field,None)
        if user is None: item.pop('owner_id',None)
        safe_items.append(item)
    return {'items':safe_items, 'page':page, 'page_size':page_size, 'total':total}

@app.get('/api/me/clips')
def my_clips(status: Optional[str] = None, q: Optional[str] = None, page: int = 1, page_size: int = 100, user=Depends(require_creator)):
    """Return only the authenticated creator's own submissions, including review state."""
    if page < 1 or page_size < 1 or page_size > 100:
        raise HTTPException(400, 'Invalid pagination')
    allowed_statuses = {'Pending', 'Published', 'Rejected', 'Suspended', 'Removed'}
    if status and status not in allowed_statuses:
        raise HTTPException(400, 'Unsupported clip status')
    where = ['c.owner_id=?']
    args: list[object] = [user['id']]
    if status:
        where.append('c.status=?')
        args.append(status)
    if q and q.strip():
        where.append('lower(c.title) LIKE ?')
        args.append('%' + q.strip().lower()[:120] + '%')
    where_sql = ' AND '.join(where)
    with connect() as db:
        total = db.execute(f'SELECT COUNT(*) AS n FROM clips c WHERE {where_sql}', args).fetchone()['n']
        rows = db.execute(
            f'''SELECT c.*, l.status AS license_status, l.allowed_uses, l.expires_at,
                       l.platform_restrictions
                FROM clips c LEFT JOIN licenses l ON l.clip_id=c.id
                WHERE {where_sql} ORDER BY c.created_at DESC LIMIT ? OFFSET ?''',
            (*args, page_size, (page - 1) * page_size)
        ).fetchall()
    items = []
    for row in rows:
        item = dict(row)
        for private_field in ('stored_name', 'original_name', 'moderated_by', 'moderation_note'):
            item.pop(private_field, None)
        items.append(item)
    return {'items': items, 'page': page, 'page_size': page_size, 'total': total}


@app.get('/api/clips/{clip_id}')
def get_clip(clip_id: str, user=Depends(lambda authorization=Header(default=None): optional_user(authorization))):
    with connect() as db: row=db.execute("SELECT c.*,l.id AS license_id,l.status AS license_status,l.allowed_uses,l.expires_at,l.platform_restrictions,u.name AS creator_name FROM clips c LEFT JOIN licenses l ON l.clip_id=c.id JOIN users u ON u.id=c.owner_id WHERE c.id=? OR lower(trim(replace(c.title,' ','-')))=lower(?) ORDER BY CASE WHEN c.id=? THEN 0 ELSE 1 END LIMIT 1",(clip_id,clip_id,clip_id)).fetchone()
    if not row: raise HTTPException(404,'Clip not found')
    if user is None:
        if row['status']!='Published' or row['license_status']!='Active' or license_is_expired(row['expires_at']): raise HTTPException(404,'Clip not found')
    elif user['role']!='admin' and row['owner_id']!=user['id'] and (row['status']!='Published' or row['license_status']!='Active' or license_is_expired(row['expires_at'])): raise HTTPException(404,'Clip not found')
    # Explicit allowlist: never expose private storage names, owner IDs, or internal moderation notes.
    allowed=('id','title','mime_type','size_bytes','duration','width','height','codec','status','created_at','license_id','license_status','allowed_uses','expires_at','platform_restrictions','creator_name')
    return {key: row[key] for key in allowed if key in row.keys()}

@app.put('/api/admin/users/{user_id}/role')
def set_user_role(user_id: str, payload: RoleIn, admin=Depends(require_admin)):
    if payload.role not in ('user','creator'):
        raise HTTPException(400, 'Admin roles can only be provisioned through the trusted operator bootstrap process')
    with connect() as db:
        cur=db.execute('UPDATE users SET role=? WHERE id=?',(payload.role,user_id))
        if cur.rowcount != 1: raise HTTPException(404,'User not found')
    return {'user_id':user_id,'role':payload.role}

@app.get('/api/admin/submissions')
def pending_submissions(admin=Depends(require_admin)):
    with connect() as db: rows=db.execute("SELECT c.*,l.status AS license_status FROM clips c LEFT JOIN licenses l ON l.clip_id=c.id WHERE c.status='Pending' ORDER BY c.created_at ASC").fetchall()
    return [dict(r) for r in rows]

@app.post('/api/admin/clips/{clip_id}/moderate')
def moderate(clip_id: str, payload: ModerateIn, admin=Depends(require_admin)):
    if payload.action not in ('approve','reject','suspend','remove'): raise HTTPException(400,'Unsupported moderation action')
    with connect() as db:
        clip=db.execute('SELECT * FROM clips WHERE id=?',(clip_id,)).fetchone()
        if not clip: raise HTTPException(404,'Clip not found')
        if payload.action=='approve':
            license_row=db.execute('SELECT * FROM licenses WHERE clip_id=?',(clip_id,)).fetchone()
            if not license_row or license_row['status']!='Active': raise HTTPException(409,'Cannot publish: an active license is required')
            if license_is_expired(license_row['expires_at']): raise HTTPException(409,'Cannot publish: license has expired')
            if len((license_row['verification_note'] or '').strip()) < 10:
                raise HTTPException(409,'Cannot publish: documented rights verification is required')
            try:
                allowed_uses = json.loads(license_row['allowed_uses'])
                if not isinstance(allowed_uses, list) or not allowed_uses or any(use not in ('personal','commercial','social','editorial') for use in allowed_uses):
                    raise ValueError('invalid allowed uses')
            except (ValueError, TypeError):
                raise HTTPException(409,'Cannot publish: license permissions are invalid')
            status='Published'
        else: status={'reject':'Rejected','suspend':'Suspended','remove':'Removed'}[payload.action]
        db.execute('UPDATE clips SET status=?,moderated_at=?,moderated_by=?,moderation_note=? WHERE id=?',(status,now_iso(),admin['id'],payload.note,clip_id))
        db.execute('INSERT INTO moderation(id,clip_id,admin_id,action,note,created_at) VALUES(?,?,?,?,?,?)',(str(uuid.uuid4()),clip_id,admin['id'],payload.action,payload.note,now_iso()))
    return {'id':clip_id,'status':status,'moderated_at':now_iso()}

@app.put('/api/admin/clips/{clip_id}/license')
def update_license(clip_id: str, payload: LicenseIn, admin=Depends(require_admin)):
    if payload.status not in ('Active','Revoked','Expired','Pending Review'): raise HTTPException(400,'Invalid license status')
    if payload.status == 'Active' and len(payload.verification_note.strip()) < 10: raise HTTPException(400,'Activating a license requires a documented rights-verification note (at least 10 characters)')
    if not payload.allowed_uses or any(x not in ('personal','commercial','social','editorial') for x in payload.allowed_uses): raise HTTPException(400,'Invalid allowed_uses')
    normalized_expiry = normalize_expiry(payload.expires_at)
    if payload.status == 'Active' and license_is_expired(normalized_expiry):
        raise HTTPException(400, 'An expired license cannot be activated')
    with connect() as db:
        if not db.execute('SELECT 1 FROM clips WHERE id=?',(clip_id,)).fetchone(): raise HTTPException(404,'Clip not found')
        cur=db.execute('UPDATE licenses SET status=?,allowed_uses=?,expires_at=?,platform_restrictions=?,verification_note=?,updated_at=? WHERE clip_id=?',(payload.status,json.dumps(payload.allowed_uses),normalized_expiry,json.dumps(payload.platform_restrictions),payload.verification_note.strip(),now_iso(),clip_id))
        if cur.rowcount == 0: raise HTTPException(404,'License not found')
    return {'clip_id':clip_id,'status':payload.status}

@app.get('/api/clips/{clip_id}/download')
def download_clip(clip_id: str, requested_use: str='personal', platform: Optional[str]=None, user=Depends(current_user)):
    if requested_use not in ('personal','commercial','social','editorial'): raise HTTPException(400,'Invalid requested use')
    with connect() as db:
        row=db.execute('SELECT c.*,l.status AS license_status,l.allowed_uses,l.expires_at,l.platform_restrictions FROM clips c JOIN licenses l ON l.clip_id=c.id WHERE c.id=?',(clip_id,)).fetchone()
        if not row: raise HTTPException(404,'Clip not found')
        if row['status']!='Published': raise HTTPException(403,'Only published clips may be downloaded')
        if row['license_status']!='Active': raise HTTPException(403,'Clip license is not active')
        if license_is_expired(row['expires_at']): raise HTTPException(403,'Clip license has expired')
        if requested_use not in json.loads(row['allowed_uses']): raise HTTPException(403,'License does not permit this use')
        if platform and platform in json.loads(row['platform_restrictions']): raise HTTPException(403,'This platform is restricted by the license')
        if row['status'] in ('Suspended','Removed'): raise HTTPException(403,'Clip is unavailable')
        path=(MEDIA_DIR / row['stored_name']).resolve()
        if path.parent != MEDIA_DIR or not path.is_file(): raise HTTPException(404,'Media file unavailable')
        download_event=(str(uuid.uuid4()),user['id'],clip_id,requested_use,now_iso())
    def record_completed_download():
        # Starlette invokes this only after the response body has been sent successfully.
        with connect() as db:
            db.execute('INSERT INTO downloads(id,user_id,clip_id,requested_use,created_at) VALUES(?,?,?,?,?)',download_event)
    return FileResponse(path, media_type=row['mime_type'], filename=safe_upload_filename(row['original_name']), background=BackgroundTask(record_completed_download))

@app.get('/api/me/downloads')
def my_downloads(user=Depends(current_user)):
    """Return only the authenticated user's completed download history."""
    with connect() as db:
        rows = db.execute("""
            SELECT d.id, d.clip_id, d.requested_use, d.created_at,
                   c.title AS clip_title, c.size_bytes, c.mime_type
            FROM downloads d JOIN clips c ON c.id=d.clip_id
            WHERE d.user_id=? ORDER BY d.created_at DESC LIMIT 200
        """, (user['id'],)).fetchall()
    return {'items': [dict(row) for row in rows], 'total': len(rows)}


@app.get('/api/admin/analytics')
def admin_analytics(admin=Depends(require_admin)):
    with connect() as db:
        clips=db.execute("SELECT status,COUNT(*) n FROM clips GROUP BY status").fetchall()
        users=db.execute("SELECT role,COUNT(*) n FROM users WHERE disabled=0 GROUP BY role").fetchall()
        licenses=db.execute("SELECT status,COUNT(*) n FROM licenses GROUP BY status").fetchall()
        downloads=db.execute("SELECT COUNT(*) n FROM downloads").fetchone()['n']
        recent=db.execute("SELECT COUNT(*) n FROM clips WHERE created_at>=?",((datetime.now(timezone.utc)-timedelta(days=30)).isoformat(),)).fetchone()['n']
    return {'clips_by_status':{r['status']:r['n'] for r in clips},'users_by_role':{r['role']:r['n'] for r in users},'licenses_by_status':{r['status']:r['n'] for r in licenses},'completed_downloads':downloads,'clips_created_last_30_days':recent,'generated_at':now_iso()}

@app.get('/api/admin/users')
def admin_users(page: int=1, page_size: int=50, q: Optional[str]=None, admin=Depends(require_admin)):
    if page<1 or page_size<1 or page_size>100: raise HTTPException(400,'Invalid pagination')
    where='WHERE lower(name) LIKE ? OR lower(email) LIKE ?' if q and q.strip() else ''
    args=['%'+q.strip().lower()+'%','%'+q.strip().lower()+'%'] if where else []
    with connect() as db:
        rows=db.execute(f'SELECT id,name,email,role,created_at,disabled FROM users {where} ORDER BY created_at DESC LIMIT ? OFFSET ?',(*args,page_size,(page-1)*page_size)).fetchall()
        total=db.execute(f'SELECT COUNT(*) n FROM users {where}',args).fetchone()['n']
    return {'items':[dict(r) for r in rows],'total':total,'page':page,'page_size':page_size}

@app.get('/api/admin/creators')
def admin_creators(admin=Depends(require_admin)):
    with connect() as db:
        rows=db.execute("SELECT u.id,u.name,u.email,u.created_at,COUNT(c.id) clip_count,SUM(CASE WHEN c.status='Published' THEN 1 ELSE 0 END) published_count FROM users u LEFT JOIN clips c ON c.owner_id=u.id WHERE u.role='creator' GROUP BY u.id ORDER BY u.created_at DESC").fetchall()
    return [dict(r) for r in rows]

@app.get('/api/me/licenses')
def my_licenses(user=Depends(current_user)):
    """Return licenses attached only to clips owned by the authenticated creator."""
    if user['role'] not in ('creator', 'admin'):
        raise HTTPException(403, 'Creator permission required')
    with connect() as db:
        rows = db.execute('''
            SELECT l.id, l.clip_id, l.status, l.allowed_uses, l.expires_at,
                   l.platform_restrictions, l.verification_note, l.updated_at,
                   c.title AS clip_title, c.status AS clip_status
            FROM licenses l JOIN clips c ON c.id=l.clip_id
            WHERE c.owner_id=?
            ORDER BY l.updated_at DESC
        ''', (user['id'],)).fetchall()
    return {'items': [dict(row) for row in rows], 'total': len(rows)}


@app.get('/api/admin/licenses')
def admin_licenses(admin=Depends(require_admin)):
    with connect() as db:
        rows=db.execute('SELECT l.id,l.clip_id,l.status,l.allowed_uses,l.expires_at,l.platform_restrictions,l.verification_note,l.updated_at,c.title,c.status clip_status,u.name creator_name FROM licenses l JOIN clips c ON c.id=l.clip_id JOIN users u ON u.id=c.owner_id ORDER BY l.updated_at DESC').fetchall()
    return [dict(r) for r in rows]

@app.get('/api/admin/reports')
def admin_reports(status: Optional[str]=None, admin=Depends(require_admin)):
    with connect() as db:
        if status:
            rows=db.execute('SELECT r.*,c.title clip_title FROM reports r LEFT JOIN clips c ON c.id=r.clip_id WHERE r.status=? ORDER BY r.created_at DESC',(status,)).fetchall()
        else:
            rows=db.execute('SELECT r.*,c.title clip_title FROM reports r LEFT JOIN clips c ON c.id=r.clip_id ORDER BY r.created_at DESC').fetchall()
    return [dict(r) for r in rows]

@app.post('/api/reports',status_code=201)
def create_report(payload: ReportIn, request: Request, clip_id: Optional[str]=None):
    enforce_rate_limit(request, 'report', 5, 3600, payload.reporter_email)
    rid=str(uuid.uuid4())
    with connect() as db:
        if clip_id and not db.execute("SELECT 1 FROM clips WHERE id=? AND status='Published'",(clip_id,)).fetchone(): raise HTTPException(404,'Clip not found')
        db.execute('INSERT INTO reports(id,clip_id,reporter_name,reporter_email,reason,details,created_at) VALUES(?,?,?,?,?,?,?)',(rid,clip_id,payload.reporter_name.strip(),payload.reporter_email.lower(),payload.reason.strip(),payload.details.strip(),now_iso()))
    return {'id':rid,'status':'Open','created_at':now_iso()}

@app.put('/api/admin/reports/{report_id}')
def update_report(report_id: str, payload: ReportStatusIn, admin=Depends(require_admin)):
    if payload.status not in ('Open','Investigating','Resolved','Dismissed'): raise HTTPException(400,'Invalid report status')
    with connect() as db:
        cur=db.execute('UPDATE reports SET status=?,resolved_at=?,resolved_by=? WHERE id=?',(payload.status,now_iso() if payload.status in ('Resolved','Dismissed') else None,admin['id'] if payload.status in ('Resolved','Dismissed') else None,report_id))
        if cur.rowcount!=1: raise HTTPException(404,'Report not found')
    return {'id':report_id,'status':payload.status}

@app.get('/api/admin/moderation')
def admin_moderation_history(admin=Depends(require_admin)):
    with connect() as db:
        rows=db.execute('SELECT m.*,c.title clip_title,u.name admin_name FROM moderation m JOIN clips c ON c.id=m.clip_id JOIN users u ON u.id=m.admin_id ORDER BY m.created_at DESC LIMIT 500').fetchall()
    return [dict(r) for r in rows]

@app.post('/api/projects',status_code=201)
def create_project(payload: ProjectIn,user=Depends(current_user)):
    if payload.source_clip_id:
        with connect() as db:
            c=db.execute('SELECT owner_id,status FROM clips WHERE id=?',(payload.source_clip_id,)).fetchone()
        if not c or (c['owner_id']!=user['id'] and user['role']!='admin'): raise HTTPException(404,'Source clip not found or not owned by user')
    pid=str(uuid.uuid4()); stamp=now_iso()
    with connect() as db: db.execute('INSERT INTO projects(id,owner_id,name,source_clip_id,settings_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',(pid,user['id'],payload.name,payload.source_clip_id,json.dumps(payload.settings),stamp,stamp))
    return {'id':pid,'owner_id':user['id'],'name':payload.name,'source_clip_id':payload.source_clip_id,'settings':payload.settings,'created_at':stamp,'updated_at':stamp}
@app.get('/api/projects')
def list_projects(user=Depends(current_user)):
    with connect() as db: rows=db.execute('SELECT * FROM projects WHERE owner_id=? ORDER BY updated_at DESC',(user['id'],)).fetchall()
    return [{**dict(r),'settings':json.loads(r['settings_json'])} for r in rows]
@app.put('/api/projects/{project_id}')
def save_project(project_id:str,payload:ProjectIn,user=Depends(current_user)):
    with connect() as db:
        row=db.execute('SELECT * FROM projects WHERE id=?',(project_id,)).fetchone()
        if not row: raise HTTPException(404,'Project not found')
        if row['owner_id']!=user['id'] and user['role']!='admin': raise HTTPException(403,'You do not own this project')
        if payload.source_clip_id:
            source=db.execute('SELECT owner_id FROM clips WHERE id=?',(payload.source_clip_id,)).fetchone()
            if not source or (source['owner_id']!=user['id'] and user['role']!='admin'): raise HTTPException(404,'Source clip not found or not owned by user')
        stamp=now_iso(); db.execute('UPDATE projects SET name=?,source_clip_id=?,settings_json=?,updated_at=? WHERE id=?',(payload.name,payload.source_clip_id,json.dumps(payload.settings),stamp,project_id))
    return {'id':project_id,'updated_at':stamp}


@app.post('/api/projects/{project_id}/duplicate', status_code=201)
def duplicate_project(project_id: str, user=Depends(current_user)):
    with connect() as db:
        row=db.execute('SELECT * FROM projects WHERE id=?',(project_id,)).fetchone()
        if not row: raise HTTPException(404,'Project not found')
        if row['owner_id'] != user['id']: raise HTTPException(404,'Project not found')
        new_id=str(uuid.uuid4()); stamp=now_iso(); name=(row['name']+' copy')[:160]
        db.execute('INSERT INTO projects(id,owner_id,name,source_clip_id,settings_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',(new_id,user['id'],name,row['source_clip_id'],row['settings_json'],stamp,stamp))
    return {'id':new_id,'owner_id':user['id'],'name':name,'source_clip_id':row['source_clip_id'],'settings':json.loads(row['settings_json']),'created_at':stamp,'updated_at':stamp}

@app.delete('/api/projects/{project_id}')
def delete_project(project_id: str, user=Depends(current_user)):
    with connect() as db:
        row=db.execute('SELECT owner_id FROM projects WHERE id=?',(project_id,)).fetchone()
        if not row or (row['owner_id'] != user['id'] and user['role']!='admin'): raise HTTPException(404,'Project not found')
        db.execute('DELETE FROM projects WHERE id=?',(project_id,))
    return {'deleted':True,'id':project_id}

def run_render(job_id: str, project: dict, source: Path, opts: dict):
    output_name=f'{job_id}.mp4'; output=MEDIA_DIR / output_name
    process = None
    try:
        ffmpeg=shutil.which('ffmpeg')
        if not ffmpeg: raise RuntimeError('FFmpeg is not installed. Install FFmpeg and add it to PATH.')
        duration=opts['trim_end']-opts['trim_start']
        if duration <= 0:
            raise RuntimeError('Invalid render trim range')
        cmd=[ffmpeg,'-y','-v','error','-ss',str(opts['trim_start']),'-i',str(source),'-t',str(duration),'-vf',f"scale={opts['width']}:{opts['height']}:force_original_aspect_ratio=decrease,pad={opts['width']}:{opts['height']}:(ow-iw)/2:(oh-ih)/2",'-c:v','libx264','-preset','veryfast','-c:a','aac','-movflags','+faststart','-progress','pipe:1','-nostats',str(output)]
        with connect() as db: db.execute("UPDATE render_jobs SET status='running',progress=1,updated_at=? WHERE id=?",(now_iso(),job_id))
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1)
        events: queue.Queue[tuple[str, str]] = queue.Queue()
        def read_stream(stream, label):
            try:
                for line in iter(stream.readline, ''):
                    events.put((label, line.strip()))
            finally:
                events.put((label, '__EOF__'))
        stdout_thread = threading.Thread(target=read_stream, args=(process.stdout, 'stdout'), daemon=True)
        stderr_thread = threading.Thread(target=read_stream, args=(process.stderr, 'stderr'), daemon=True)
        stdout_thread.start(); stderr_thread.start()
        stderr_tail: list[str] = []
        out_time_us = 0
        last_progress = 1
        last_update = time.monotonic()
        deadline = last_update + 3600
        eof_streams: set[str] = set()
        while process.poll() is None or len(eof_streams) < 2 or not events.empty():
            if time.monotonic() > deadline:
                process.kill()
                raise RuntimeError('Render timed out after 60 minutes')
            try:
                label, line = events.get(timeout=0.2)
            except queue.Empty:
                continue
            if line == '__EOF__':
                eof_streams.add(label)
                continue
            if label == 'stderr':
                if line:
                    stderr_tail.append(line[-500:])
                    stderr_tail = stderr_tail[-8:]
                continue
            if line.startswith('out_time_us='):
                try: out_time_us = max(0, int(line.split('=', 1)[1]))
                except ValueError: pass
            elif line.startswith('out_time_ms='):
                # FFmpeg's progress protocol labels this value out_time_ms but reports microseconds.
                try: out_time_us = max(0, int(line.split('=', 1)[1]))
                except ValueError: pass
            elif line == 'progress=continue' or line == 'progress=end':
                calculated = min(95, max(1, int((out_time_us / (duration * 1_000_000)) * 94) + 1))
                now = time.monotonic()
                if calculated >= last_progress + 3 or now - last_update >= 1.5:
                    with connect() as db: db.execute("UPDATE render_jobs SET progress=?,updated_at=? WHERE id=? AND status='running'",(calculated,now_iso(),job_id))
                    last_progress = calculated; last_update = now
        return_code = process.wait(timeout=5)
        stdout_thread.join(timeout=1); stderr_thread.join(timeout=1)
        if return_code != 0:
            # Do not persist full FFmpeg diagnostics: they can contain private absolute storage paths.
            raise RuntimeError('FFmpeg render failed. Check source media compatibility and server configuration.')
        if not output.is_file() or output.stat().st_size <= 0:
            raise RuntimeError('FFmpeg reported success but no usable output file was created')
        with connect() as db: db.execute("UPDATE render_jobs SET status='completed',progress=100,output_name=?,error=NULL,updated_at=? WHERE id=?",(output_name,now_iso(),job_id))
    except Exception as e:
        if process is not None and process.poll() is None:
            process.kill()
            try: process.wait(timeout=5)
            except Exception: pass
        output.unlink(missing_ok=True)
        message = str(e)
        if isinstance(e, (OSError, subprocess.SubprocessError)):
            message = 'Unable to run FFmpeg. Verify the media-processing installation and server configuration.'
        with connect() as db: db.execute("UPDATE render_jobs SET status='failed',progress=0,error=?,updated_at=? WHERE id=?",(message[:300],now_iso(),job_id))

@app.post('/api/projects/{project_id}/renders',status_code=202)
def create_render(project_id:str,payload:RenderIn,request:Request,background:BackgroundTasks,user=Depends(current_user)):
    enforce_rate_limit(request, 'render', 10, 3600, user['id'])
    if payload.output_format!='mp4' or payload.aspect_ratio not in ('9:16','16:9','1:1','4:5'): raise HTTPException(400,'Unsupported output format or aspect ratio')
    if payload.trim_end<=payload.trim_start: raise HTTPException(400,'trim_end must be greater than trim_start')
    with connect() as db:
        active=db.execute("SELECT COUNT(*) n FROM render_jobs WHERE status IN ('queued','running')").fetchone()['n']
        if active >= int(os.getenv('JHONNY_MAX_ACTIVE_RENDERS','2')): raise HTTPException(429,'Render capacity reached. Wait for an active render to finish.')
        project=db.execute('SELECT * FROM projects WHERE id=?',(project_id,)).fetchone()
        if not project: raise HTTPException(404,'Project not found')
        if project['owner_id']!=user['id'] and user['role']!='admin': raise HTTPException(403,'You do not own this project')
        if not project['source_clip_id']: raise HTTPException(400,'Project has no source clip')
        clip=db.execute('SELECT * FROM clips WHERE id=?',(project['source_clip_id'],)).fetchone()
        if not clip or (clip['owner_id']!=user['id'] and user['role']!='admin'): raise HTTPException(403,'Source clip is not accessible')
        if clip['duration'] is None: raise HTTPException(409,'Source duration is unknown; metadata must be verified before rendering')
        if payload.trim_end>clip['duration']: raise HTTPException(400,'Trim range exceeds source duration')
        source=(MEDIA_DIR / clip['stored_name']).resolve()
        if source.parent!=MEDIA_DIR or not source.is_file(): raise HTTPException(404,'Source media is unavailable')
        job=str(uuid.uuid4()); stamp=now_iso(); db.execute("INSERT INTO render_jobs(id,project_id,owner_id,status,progress,created_at,updated_at) VALUES(?,?,?,'queued',0,?,?)",(job,project_id,user['id'],stamp,stamp))
    background.add_task(run_render,job,dict(project),source,payload.model_dump())
    return {'id':job,'status':'queued','progress':0}
@app.get('/api/renders/{job_id}')
def render_status(job_id:str,user=Depends(current_user)):
    with connect() as db: row=db.execute('SELECT * FROM render_jobs WHERE id=?',(job_id,)).fetchone()
    if not row: raise HTTPException(404,'Render job not found')
    if row['owner_id']!=user['id'] and user['role']!='admin': raise HTTPException(403,'You do not own this render job')
    result={k:row[k] for k in ('id','project_id','status','progress','error','created_at','updated_at')}
    if row['status']=='completed': result['download_url']=f"/api/renders/{job_id}/download"
    return result
@app.get('/api/renders/{job_id}/download')
def download_render(job_id:str,user=Depends(current_user)):
    with connect() as db: row=db.execute('SELECT * FROM render_jobs WHERE id=?',(job_id,)).fetchone()
    if not row: raise HTTPException(404,'Render job not found')
    if row['owner_id']!=user['id'] and user['role']!='admin': raise HTTPException(403,'You do not own this render job')
    if row['status']!='completed' or not row['output_name']: raise HTTPException(409,'Render is not complete')
    path=(MEDIA_DIR / row['output_name']).resolve()
    if path.parent!=MEDIA_DIR or not path.is_file(): raise HTTPException(404,'Rendered file unavailable')
    return FileResponse(path,media_type='video/mp4',filename=f'jhonny-render-{job_id}.mp4')
