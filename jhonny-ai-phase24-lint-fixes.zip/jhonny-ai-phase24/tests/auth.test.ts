import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { decideRouteAccess, requirementForPath } from '../src/lib/auth';

describe('decideRouteAccess', () => {
  it('lets anyone see public pages', () => {
    assert.deepEqual(decideRouteAccess('public', null), { allowed: true });
  });

  it('asks guests to sign in for protected pages', () => {
    assert.deepEqual(decideRouteAccess('admin', null), { allowed: false, reason: 'login_required' });
    assert.deepEqual(decideRouteAccess('signed_in', undefined), { allowed: false, reason: 'login_required' });
  });

  it('blocks non-admins from admin pages and allows admins', () => {
    assert.deepEqual(decideRouteAccess('admin', { role: 'user' }), { allowed: false, reason: 'forbidden' });
    assert.deepEqual(decideRouteAccess('admin', { role: 'creator' }), { allowed: false, reason: 'forbidden' });
    assert.deepEqual(decideRouteAccess('admin', { role: 'admin' }), { allowed: true });
  });

  it('lets creators and admins into creator pages only', () => {
    assert.equal(decideRouteAccess('creator', { role: 'user' }).allowed, false);
    assert.equal(decideRouteAccess('creator', { role: 'creator' }).allowed, true);
    assert.equal(decideRouteAccess('creator', { role: 'admin' }).allowed, true);
  });
});

describe('requirementForPath', () => {
  it('maps protected prefixes', () => {
    assert.equal(requirementForPath('/admin'), 'admin');
    assert.equal(requirementForPath('/admin/clips'), 'admin');
    assert.equal(requirementForPath('/admin/ai'), 'admin');
    assert.equal(requirementForPath('/creator/licenses'), 'creator');
    assert.equal(requirementForPath('/studio'), 'signed_in');
    assert.equal(requirementForPath('/studio/projects/p1'), 'signed_in');
    assert.equal(requirementForPath('/dashboard'), 'signed_in');
  });

  it('does not treat look-alike prefixes as protected', () => {
    assert.equal(requirementForPath('/administrator'), 'public');
    assert.equal(requirementForPath('/clips'), 'public');
    assert.equal(requirementForPath('/does-not-exist'), 'public');
  });
});
