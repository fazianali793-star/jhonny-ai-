import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { INITIAL_CLIPS, INITIAL_LICENSES, INITIAL_CREATORS, INITIAL_REPORTS } from '../src/data/mockData';
import { isClipRecord, isLicenseRecord, isCreatorRecord, isReportRecord, isUserAccount, isProjectRecord } from '../src/lib/models';

describe('record validators against seed data', () => {
  it('accepts every seeded clip', () => {
    const bad = INITIAL_CLIPS.filter(c => !isClipRecord(c as unknown)).map(c => c.id);
    assert.deepEqual(bad, []);
  });

  it('accepts every seeded license, creator and report', () => {
    assert.deepEqual(INITIAL_LICENSES.filter(l => !isLicenseRecord(l as unknown)).map(l => l.id), []);
    assert.deepEqual(INITIAL_CREATORS.filter(c => !isCreatorRecord(c as unknown)).map(c => c.id), []);
    assert.deepEqual(INITIAL_REPORTS.filter(r => !isReportRecord(r as unknown)).map(r => r.id), []);
  });

  it('rejects clips with unknown status or missing license', () => {
    const [c] = INITIAL_CLIPS;
    assert.equal(isClipRecord({ ...c, status: 'Bogus' }), false);
    assert.equal(isClipRecord({ ...c, licenseInfo: undefined }), false);
    assert.equal(isClipRecord({ ...c, mediaUrl: 42 }), false);
  });

  it('rejects users with unknown roles', () => {
    assert.equal(isUserAccount({ id: '1', name: 'a', email: 'a@b', role: 'root' }), false);
    assert.equal(isUserAccount({ id: '1', name: 'a', email: 'a@b', role: 'admin' }), true);
  });

  it('validates project records', () => {
    const good = {
      id: 'p', ownerId: 'u', name: 'n', sourceClipId: null, trimStart: 0, trimEnd: 5,
      hookText: '', status: 'draft', createdAt: 'x', updatedAt: 'x'
    };
    assert.equal(isProjectRecord(good), true);
    assert.equal(isProjectRecord({ ...good, status: 'published' }), false);
  });
});
