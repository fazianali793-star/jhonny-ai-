import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { paginate, queryClips, sortClips, matchesSearch, LIBRARY_PAGE_SIZE, isLibrarySort } from '../src/lib/library';
import { makeClip } from './helpers';

describe('paginate', () => {
  const items = Array.from({ length: 25 }, (_, i) => i);

  it('slices the requested page', () => {
    const p = paginate(items, 2, 10);
    assert.deepEqual(p.items, [10, 11, 12, 13, 14, 15, 16, 17, 18, 19]);
    assert.equal(p.totalPages, 3);
    assert.equal(p.totalItems, 25);
  });

  it('clamps pages below 1 and above the last page', () => {
    assert.equal(paginate(items, 0, 10).page, 1);
    assert.equal(paginate(items, -4, 10).page, 1);
    assert.equal(paginate(items, 99, 10).page, 3);
    assert.deepEqual(paginate(items, 99, 10).items, [20, 21, 22, 23, 24]);
  });

  it('handles non-numeric and fractional pages', () => {
    assert.equal(paginate(items, Number.NaN, 10).page, 1);
    assert.equal(paginate(items, 2.9, 10).page, 2);
  });

  it('returns one empty page for an empty list', () => {
    const p = paginate([], 5, 10);
    assert.equal(p.page, 1);
    assert.equal(p.totalPages, 1);
    assert.deepEqual(p.items, []);
  });

  it('falls back to the default size for invalid page sizes', () => {
    assert.equal(paginate(items, 1, 0).pageSize, LIBRARY_PAGE_SIZE);
    assert.equal(paginate(items, 1, 2.5).pageSize, LIBRARY_PAGE_SIZE);
  });
});

describe('sortClips', () => {
  const a = makeClip({ id: 'a', title: 'Banana', views: 10, downloads: 0, createdAt: '2026-01-01T00:00:00Z' });
  const b = makeClip({ id: 'b', title: 'apple', views: 1, downloads: 50, createdAt: '2026-03-01T00:00:00Z' });
  const c = makeClip({ id: 'c', title: 'Cherry', views: 5, downloads: 5, createdAt: 'garbage' });

  it('sorts by trending score (views + 2 x downloads)', () => {
    // scores: a=10, b=1+100=101, c=5+10=15
    assert.deepEqual(sortClips([a, b, c], 'trending').map(x => x.id), ['b', 'c', 'a']);
  });

  it('sorts newest first and treats invalid dates as oldest', () => {
    assert.deepEqual(sortClips([a, b, c], 'newest').map(x => x.id), ['b', 'a', 'c']);
  });

  it('sorts by downloads', () => {
    assert.deepEqual(sortClips([a, b, c], 'downloads').map(x => x.id), ['b', 'c', 'a']);
  });

  it('sorts by title case-insensitively', () => {
    assert.deepEqual(sortClips([a, b, c], 'title').map(x => x.title), ['apple', 'Banana', 'Cherry']);
  });

  it('does not mutate the input array', () => {
    const input = [a, b];
    sortClips(input, 'title');
    assert.deepEqual(input.map(x => x.id), ['a', 'b']);
  });

  it('is stable across equal keys by id', () => {
    const x = makeClip({ id: 'x', views: 1, downloads: 0 });
    const y = makeClip({ id: 'y', views: 1, downloads: 0 });
    assert.deepEqual(sortClips([y, x], 'trending').map(c => c.id), ['x', 'y']);
  });
});

describe('queryClips and search', () => {
  const clips = [
    makeClip({ id: '1', title: 'Minecraft Clutch', category: 'Minecraft', duration: 20, creatorId: 'c1' }),
    makeClip({ id: '2', title: 'Podcast Moment', category: 'Podcasts', duration: 45, creatorId: 'c2', tags: ['deep'] }),
    makeClip({ id: '3', title: 'Long Story', category: 'Podcasts', duration: 90, creatorId: 'c2', status: 'Pending' })
  ];

  it('matches title, creator, category and tags', () => {
    assert.equal(matchesSearch(clips[0], 'clutch'), true);
    assert.equal(matchesSearch(clips[0], 'marcus'), true);
    assert.equal(matchesSearch(clips[0], 'minecraft'), true);
    assert.equal(matchesSearch(clips[1], 'deep'), true);
    assert.equal(matchesSearch(clips[0], 'zzz'), false);
    assert.equal(matchesSearch(clips[0], '   '), true);
  });

  it('filters by status tab', () => {
    assert.deepEqual(queryClips(clips, { status: 'Pending' }).map(c => c.id), ['3']);
    assert.equal(queryClips(clips, { status: 'All' }).length, 3);
  });

  it('filters by category, creator and duration together', () => {
    const r = queryClips(clips, { category: 'Podcasts', creatorId: 'c2', duration: 'medium' });
    assert.deepEqual(r.map(c => c.id), ['2']);
  });

  it('applies duration buckets with the same boundaries as the original page', () => {
    assert.deepEqual(queryClips(clips, { duration: 'short' }).map(c => c.id), ['1']);
    assert.deepEqual(queryClips(clips, { duration: 'long' }).map(c => c.id), ['3']);
  });

  it('validates sort keys from untrusted query strings', () => {
    assert.equal(isLibrarySort('newest'), true);
    assert.equal(isLibrarySort('<script>'), false);
  });
});
