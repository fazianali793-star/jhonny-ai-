import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { loadCollection, loadValue, saveVersioned, STORAGE_KEYS } from '../src/lib/storage';
import { memoryStorage } from './helpers';

const isNum = (x: unknown): x is number => typeof x === 'number';
const isItem = (x: unknown): x is { id: string; n: number } =>
  typeof x === 'object' && x !== null && typeof (x as { id?: unknown }).id === 'string' && isNum((x as { n?: unknown }).n);

describe('loadCollection', () => {
  it('uses fallback when storage is unavailable and marks writes blocked', () => {
    const r = loadCollection('k', isItem, () => [{ id: 'f', n: 1 }], { storage: null });
    assert.equal(r.status, 'unavailable');
    assert.equal(r.writable, false);
    assert.deepEqual(r.value, [{ id: 'f', n: 1 }]);
  });

  it('uses fallback when nothing is stored', () => {
    const r = loadCollection('k', isItem, () => [{ id: 'f', n: 1 }], { storage: memoryStorage() });
    assert.equal(r.status, 'empty');
    assert.equal(r.writable, true);
  });

  it('reads a valid versioned envelope', () => {
    const s = memoryStorage();
    saveVersioned('k', [{ id: 'a', n: 2 }], { storage: s });
    const r = loadCollection('k', isItem, () => [], { storage: s });
    assert.equal(r.status, 'loaded');
    assert.deepEqual(r.value, [{ id: 'a', n: 2 }]);
  });

  it('migrates legacy unversioned arrays', () => {
    const s = memoryStorage({ k: JSON.stringify([{ id: 'legacy', n: 3 }]) });
    const r = loadCollection('k', isItem, () => [], { storage: s });
    assert.equal(r.status, 'migrated');
    assert.deepEqual(r.value, [{ id: 'legacy', n: 3 }]);
  });

  it('backs up corrupt JSON and falls back without throwing', () => {
    const s = memoryStorage({ k: '{not json' });
    const r = loadCollection('k', isItem, () => [{ id: 'f', n: 1 }], { storage: s });
    assert.equal(r.status, 'corrupt');
    assert.deepEqual(r.value, [{ id: 'f', n: 1 }]);
    assert.equal(s.data.get('k.corrupt'), '{not json');
  });

  it('treats a non-array payload as corrupt', () => {
    const s = memoryStorage({ k: JSON.stringify({ hello: 'world' }) });
    const r = loadCollection('k', isItem, () => [], { storage: s });
    assert.equal(r.status, 'corrupt');
  });

  it('blocks writes over data saved by a newer schema version', () => {
    const s = memoryStorage({ k: JSON.stringify({ schemaVersion: 99, savedAt: 'x', data: [] }) });
    const r = loadCollection('k', isItem, () => [{ id: 'f', n: 1 }], { storage: s });
    assert.equal(r.status, 'unsupported');
    assert.equal(r.writable, false);
  });

  it('drops invalid items, counts them, and reports corruption', () => {
    const s = memoryStorage({ k: JSON.stringify([{ id: 'ok', n: 1 }, { id: 5 }, null, 'x']) });
    const r = loadCollection('k', isItem, () => [], { storage: s });
    assert.equal(r.droppedCount, 3);
    assert.equal(r.status, 'corrupt');
    assert.deepEqual(r.value.map(i => i.id), ['ok']);
  });

  it('repairs duplicate and missing ids so keys stay unique', () => {
    const s = memoryStorage({ k: JSON.stringify([{ id: 'x', n: 1 }, { id: 'x', n: 2 }, { id: 'y', n: 3 }]) });
    const r = loadCollection('k', isItem, () => [], { storage: s, idOf: i => i.id, repairPrefix: 'rep' });
    const ids = r.value.map(i => i.id);
    assert.equal(new Set(ids).size, ids.length);
    assert.equal(ids[0], 'x');
    assert.equal(ids[2], 'y');
  });

  it('falls back when every stored item is invalid', () => {
    const s = memoryStorage({ k: JSON.stringify([{ bad: true }]) });
    const r = loadCollection('k', isItem, () => [{ id: 'f', n: 1 }], { storage: s });
    assert.deepEqual(r.value, [{ id: 'f', n: 1 }]);
  });
});

describe('loadValue', () => {
  const isUser = (x: unknown): x is { name: string } =>
    typeof x === 'object' && x !== null && typeof (x as { name?: unknown }).name === 'string';

  it('returns the stored value when it validates', () => {
    const s = memoryStorage();
    saveVersioned(STORAGE_KEYS.currentUser, { name: 'Ana' }, { storage: s });
    assert.deepEqual(loadValue(STORAGE_KEYS.currentUser, isUser, () => null, { storage: s }).value, { name: 'Ana' });
  });

  it('returns null for a value that fails validation', () => {
    const s = memoryStorage({ k: JSON.stringify({ name: 42 }) });
    const r = loadValue('k', isUser, () => null, { storage: s });
    assert.equal(r.value, null);
    assert.equal(r.status, 'corrupt');
  });
});

describe('saveVersioned', () => {
  it('writes a schema envelope', () => {
    const s = memoryStorage();
    assert.equal(saveVersioned('k', [1], { storage: s, now: new Date('2026-02-02T00:00:00Z') }), true);
    const parsed = JSON.parse(s.data.get('k') as string);
    assert.equal(parsed.schemaVersion, 1);
    assert.equal(parsed.savedAt, '2026-02-02T00:00:00.000Z');
    assert.deepEqual(parsed.data, [1]);
  });

  it('returns false instead of throwing when the quota is exceeded', () => {
    const s = memoryStorage();
    s.setItem = () => { throw new Error('QuotaExceededError'); };
    const originalWarn = console.warn;
    console.warn = () => {};
    try {
      assert.equal(saveVersioned('k', [1], { storage: s }), false);
    } finally {
      console.warn = originalWarn;
    }
  });
});
