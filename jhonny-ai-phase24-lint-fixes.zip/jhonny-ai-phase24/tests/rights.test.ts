import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { canDownloadClip, canViewClipDetail, getLicenseState, isPublicClip } from '../src/lib/rights';
import { makeClip } from './helpers';

const NOW = Date.parse('2026-06-01T00:00:00.000Z');

describe('isPublicClip', () => {
  it('is true for a published clip with an active, unexpired license', () => {
    assert.equal(isPublicClip(makeClip(), NOW), true);
  });

  it('is true for an Expiring license that has not yet expired', () => {
    assert.equal(isPublicClip(makeClip({ licenseInfo: { status: 'Expiring' } as never }), NOW), true);
  });

  it('is false for Pending, Processing, Disabled and Takedown clips', () => {
    for (const status of ['Pending', 'Processing', 'Disabled', 'Takedown'] as const) {
      assert.equal(isPublicClip(makeClip({ status }), NOW), false, status);
    }
  });

  it('is false for revoked, expired or pending-review licenses', () => {
    for (const status of ['Revoked', 'Expired', 'Pending Review'] as const) {
      assert.equal(isPublicClip(makeClip({ licenseInfo: { status } as never }), NOW), false, status);
    }
  });

  it('is false once the license expiry date has passed', () => {
    const clip = makeClip({ licenseInfo: { expiresAt: '2026-05-31T23:59:59.000Z' } as never });
    assert.equal(getLicenseState(clip, NOW), 'expired');
    assert.equal(isPublicClip(clip, NOW), false);
  });

  it('fails closed when the expiry date cannot be parsed', () => {
    const clip = makeClip({ licenseInfo: { expiresAt: 'not-a-date' } as never });
    assert.equal(getLicenseState(clip, NOW), 'expired');
  });
});

describe('canDownloadClip', () => {
  it('denies unpublished clips even with a valid license', () => {
    const d = canDownloadClip(makeClip({ status: 'Takedown', mediaUrl: 'https://cdn.example/x.mp4' }), NOW);
    assert.equal(d.allowed, false);
    assert.equal(d.allowed === false && d.reason, 'not_published');
  });

  it('denies expired licenses', () => {
    const d = canDownloadClip(makeClip({ licenseInfo: { expiresAt: '2025-01-01T00:00:00Z' } as never, mediaUrl: 'https://cdn.example/x.mp4' }), NOW);
    assert.equal(d.allowed === false && d.reason, 'license_expired');
  });

  it('denies revoked licenses', () => {
    const d = canDownloadClip(makeClip({ licenseInfo: { status: 'Revoked' } as never, mediaUrl: 'https://cdn.example/x.mp4' }), NOW);
    assert.equal(d.allowed === false && d.reason, 'license_inactive');
  });

  it('denies clips with no server-issued media URL instead of faking a file', () => {
    const d = canDownloadClip(makeClip(), NOW);
    assert.equal(d.allowed === false && d.reason, 'no_media');
    assert.match(d.allowed === false ? d.message : '', /not available in this build/);
  });

  it('allows a published clip with an active license and a media URL', () => {
    assert.deepEqual(canDownloadClip(makeClip({ mediaUrl: 'https://cdn.example/signed.mp4' }), NOW), { allowed: true });
  });
});

describe('canViewClipDetail', () => {
  it('lets guests and users see only public clips', () => {
    const takedown = makeClip({ status: 'Takedown' });
    assert.equal(canViewClipDetail(takedown, null, NOW), false);
    assert.equal(canViewClipDetail(takedown, 'user', NOW), false);
    assert.equal(canViewClipDetail(makeClip(), null, NOW), true);
  });

  it('lets admins open non-public clips for review', () => {
    assert.equal(canViewClipDetail(makeClip({ status: 'Takedown' }), 'admin', NOW), true);
  });
});

describe('download target URL', () => {
  it('refuses a media URL that is not a well-formed https URL', () => {
    for (const mediaUrl of ['javascript:alert(1)', 'data:video/mp4;base64,AAAA', 'blob:https://x/y', 'http://cdn.example/x.mp4', 'not a url', '//cdn.example/x.mp4']) {
      const d = canDownloadClip(makeClip({ mediaUrl }), NOW);
      assert.equal(d.allowed, false, mediaUrl);
    }
  });

  it('still refuses an unlicensed clip that has a valid https media URL', () => {
    const clip = makeClip({ licenseInfo: { status: 'Revoked' } as never, mediaUrl: 'https://cdn.example/x.mp4' });
    assert.equal(canDownloadClip(clip, NOW).allowed, false);
  });
});
