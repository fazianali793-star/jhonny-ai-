import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  createProject,
  updateProject,
  duplicateProject,
  projectsForOwner,
  removeOwnedProject,
  findOwnedProject,
  PROJECT_NAME_MAX,
  type Project
} from '../src/lib/projects';

const input = { name: '  Clip edit  ', sourceClipId: 'clip-1', trimStart: 2, trimEnd: 30, hookText: ' Hook ' };
const NOW = new Date('2026-05-05T10:00:00Z');

function make(owner: string, id: string, name = 'P'): Project {
  const r = createProject(owner, { ...input, name }, { id, now: NOW });
  if (!r.ok) throw new Error(r.error);
  return r.project;
}

describe('createProject', () => {
  it('creates a draft owned by the user with trimmed fields', () => {
    const r = createProject('u1', input, { id: 'p1', now: NOW });
    assert.equal(r.ok, true);
    if (!r.ok) return;
    assert.equal(r.project.name, 'Clip edit');
    assert.equal(r.project.hookText, 'Hook');
    assert.equal(r.project.status, 'draft');
    assert.equal(r.project.ownerId, 'u1');
    assert.equal(r.project.createdAt, '2026-05-05T10:00:00.000Z');
  });

  it('rejects an empty name', () => {
    const r = createProject('u1', { ...input, name: '   ' }, { id: 'p' });
    assert.equal(r.ok, false);
  });

  it('rejects an end time at or before the start time', () => {
    const r = createProject('u1', { ...input, trimStart: 10, trimEnd: 10 }, { id: 'p' });
    assert.equal(!r.ok && r.error, 'End time must be after the start time.');
  });

  it('rejects an end time past the source clip length', () => {
    const r = createProject('u1', input, { id: 'p', sourceDurationSeconds: 20 });
    assert.equal(!r.ok && r.error, 'End time is beyond the length of the source clip.');
  });

  it('rejects overlong names and non-finite times', () => {
    assert.equal(createProject('u1', { ...input, name: 'x'.repeat(PROJECT_NAME_MAX + 1) }, { id: 'p' }).ok, false);
    assert.equal(createProject('u1', { ...input, trimStart: Number.NaN }, { id: 'p' }).ok, false);
  });
});

describe('updateProject', () => {
  it('lets the owner save edits and marks the project saved', () => {
    const p = make('u1', 'p1');
    const later = new Date('2026-05-06T10:00:00Z');
    const r = updateProject(p, { trimEnd: 40 }, 'u1', { now: later });
    assert.equal(r.ok, true);
    if (!r.ok) return;
    assert.equal(r.project.trimEnd, 40);
    assert.equal(r.project.status, 'saved');
    assert.equal(r.project.updatedAt, '2026-05-06T10:00:00.000Z');
    assert.equal(r.project.createdAt, p.createdAt);
  });

  it('refuses edits from another user', () => {
    const r = updateProject(make('u1', 'p1'), { name: 'Hacked' }, 'u2');
    assert.equal(!r.ok && r.error, 'You can only edit your own projects.');
  });

  it('refuses edits from a guest with no user id', () => {
    assert.equal(updateProject(make('u1', 'p1'), { name: 'x' }, null).ok, false);
  });

  it('keeps the saved project unchanged when validation fails', () => {
    const p = make('u1', 'p1');
    const r = updateProject(p, { trimStart: 50 }, 'u1');
    assert.equal(r.ok, false);
    assert.equal(p.trimStart, 2);
  });
});

describe('duplicateProject', () => {
  it('creates an independent draft copy with a new id and suffix', () => {
    const p = make('u1', 'p1', 'Original');
    const r = duplicateProject(p, 'u1', { id: 'p2', now: new Date('2026-05-07T00:00:00Z') });
    assert.equal(r.ok, true);
    if (!r.ok) return;
    assert.equal(r.project.id, 'p2');
    assert.equal(r.project.name, 'Original (copy)');
    assert.equal(r.project.status, 'draft');
    assert.equal(r.project.ownerId, 'u1');
  });

  it('keeps duplicated names within the length limit', () => {
    const p = make('u1', 'p1', 'n'.repeat(PROJECT_NAME_MAX));
    const r = duplicateProject(p, 'u1', { id: 'p2' });
    assert.equal(r.ok && r.project.name.length <= PROJECT_NAME_MAX, true);
  });

  it('refuses duplicating another user\'s project', () => {
    assert.equal(duplicateProject(make('u1', 'p1'), 'u2', { id: 'x' }).ok, false);
  });
});

describe('ownership isolation', () => {
  const all = [make('u1', 'a', 'A'), make('u2', 'b', 'B'), make('u1', 'c', 'C')];

  it('lists only the owner\'s projects, most recently updated first', () => {
    assert.deepEqual(projectsForOwner(all, 'u1').map(p => p.id).sort(), ['a', 'c']);
    assert.deepEqual(projectsForOwner(all, 'u2').map(p => p.id), ['b']);
    assert.deepEqual(projectsForOwner(all, null), []);
  });

  it('finds a project only for its owner', () => {
    assert.equal(findOwnedProject(all, 'b', 'u1'), undefined);
    assert.equal(findOwnedProject(all, 'b', 'u2')?.id, 'b');
  });

  it('deletes only for the owner and reports unknown ids', () => {
    assert.equal(removeOwnedProject(all, 'b', 'u1').ok, false);
    const r = removeOwnedProject(all, 'a', 'u1');
    assert.equal(r.ok && r.projects.length, 2);
    assert.equal(removeOwnedProject(all, 'missing', 'u1').ok, false);
  });
});
