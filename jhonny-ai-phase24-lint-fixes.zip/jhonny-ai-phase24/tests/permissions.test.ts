import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { canEditClip, decideStatusChange, isAdmin, ownsClip } from '../src/lib/permissions';
import { makeClip } from './helpers';

const NOW = Date.parse('2026-06-01T00:00:00.000Z');
const admin = { role: 'admin' as const };
const owner = { role: 'creator' as const, creatorId: 'c1' };
const otherCreator = { role: 'creator' as const, creatorId: 'c2' };
const user = { role: 'user' as const };

const allowed = (d: { allowed: boolean }) => d.allowed;

describe('ownership and edit rights', () => {
  it('lets admins and the owning creator edit a clip', () => {
    const clip = makeClip();
    assert.equal(canEditClip(clip, admin), true);
    assert.equal(canEditClip(clip, owner), true);
  });

  it('refuses guests, regular users and other creators', () => {
    const clip = makeClip();
    assert.equal(canEditClip(clip, null), false);
    assert.equal(canEditClip(clip, user), false);
    assert.equal(canEditClip(clip, otherCreator), false);
  });

  it('does not treat a creator without a creator id as an owner', () => {
    assert.equal(ownsClip(makeClip(), { role: 'creator' }), false);
    assert.equal(isAdmin({ role: 'creator' }), false);
  });
});

describe('decideStatusChange: publishing', () => {
  it('refuses a creator restoring their own disabled clip', () => {
    const d = decideStatusChange(makeClip({ status: 'Disabled' }), 'Published', owner, { now: NOW });
    assert.equal(d.allowed, false);
  });

  it('refuses a creator re-publishing a clip in takedown', () => {
    assert.equal(allowed(decideStatusChange(makeClip({ status: 'Takedown' }), 'Published', owner, { now: NOW })), false);
  });

  it('refuses a creator publishing a pending submission, even with an active license', () => {
    assert.equal(allowed(decideStatusChange(makeClip({ status: 'Pending' }), 'Published', owner, { now: NOW })), false);
  });

  it('refuses an admin publishing a pending submission through the status path (approval is separate)', () => {
    assert.equal(allowed(decideStatusChange(makeClip({ status: 'Pending' }), 'Published', admin, { now: NOW })), false);
  });

  it('refuses any change out of takedown, for admins too', () => {
    for (const target of ['Published', 'Disabled'] as const) {
      assert.equal(allowed(decideStatusChange(makeClip({ status: 'Takedown' }), target, admin, { now: NOW })), false, target);
    }
  });

  it('lets an admin restore a disabled clip whose license is valid', () => {
    assert.equal(allowed(decideStatusChange(makeClip({ status: 'Disabled' }), 'Published', admin, { now: NOW })), true);
  });

  it('refuses restoring a disabled clip whose license has expired or is revoked', () => {
    const expired = makeClip({ status: 'Disabled', licenseInfo: { expiresAt: '2026-01-01T00:00:00.000Z' } as never });
    const revoked = makeClip({ status: 'Disabled', licenseInfo: { status: 'Revoked' } as never });
    assert.equal(allowed(decideStatusChange(expired, 'Published', admin, { now: NOW })), false);
    assert.equal(allowed(decideStatusChange(revoked, 'Published', admin, { now: NOW })), false);
  });

  it('refuses guests and regular users', () => {
    assert.equal(allowed(decideStatusChange(makeClip({ status: 'Disabled' }), 'Published', null, { now: NOW })), false);
    assert.equal(allowed(decideStatusChange(makeClip(), 'Disabled', user, { now: NOW })), false);
  });
});

describe('decideStatusChange: disabling and takedown', () => {
  it('lets the owner disable their own published clip', () => {
    assert.equal(allowed(decideStatusChange(makeClip(), 'Disabled', owner, { creatorActive: true, now: NOW })), true);
  });

  it('refuses a suspended creator, and a creator acting on another creator\'s clip', () => {
    assert.equal(allowed(decideStatusChange(makeClip(), 'Disabled', owner, { creatorActive: false, now: NOW })), false);
    assert.equal(allowed(decideStatusChange(makeClip(), 'Disabled', otherCreator, { creatorActive: true, now: NOW })), false);
  });

  it('refuses a creator placing a clip into takedown', () => {
    assert.equal(allowed(decideStatusChange(makeClip(), 'Takedown', owner, { creatorActive: true, now: NOW })), false);
  });

  it('lets an admin disable or take down a published clip', () => {
    assert.equal(allowed(decideStatusChange(makeClip(), 'Disabled', admin, { now: NOW })), true);
    assert.equal(allowed(decideStatusChange(makeClip(), 'Takedown', admin, { now: NOW })), true);
  });

  it('refuses moving a clip back to Pending or Processing', () => {
    assert.equal(allowed(decideStatusChange(makeClip(), 'Pending', admin, { now: NOW })), false);
    assert.equal(allowed(decideStatusChange(makeClip(), 'Processing', admin, { now: NOW })), false);
  });

  it('refuses a no-op change', () => {
    assert.equal(allowed(decideStatusChange(makeClip(), 'Published', admin, { now: NOW })), false);
  });
});
