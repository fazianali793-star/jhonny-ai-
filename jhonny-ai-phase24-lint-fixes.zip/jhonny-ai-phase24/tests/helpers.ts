import type { Clip } from '../src/types';
import type { StorageAdapter } from '../src/lib/storage';

export function memoryStorage(initial: Record<string, string> = {}): StorageAdapter & { data: Map<string, string> } {
  const data = new Map<string, string>(Object.entries(initial));
  return {
    data,
    getItem: k => (data.has(k) ? (data.get(k) as string) : null),
    setItem: (k, v) => { data.set(k, String(v)); },
    removeItem: k => { data.delete(k); }
  };
}

export function makeClip(overrides: Partial<Clip> = {}): Clip {
  const base: Clip = {
    id: 'clip-a',
    slug: 'clip-a',
    title: 'Sample Clip',
    description: 'Test clip',
    thumbnail: 'data:,',
    creatorId: 'c1',
    creator: { id: 'c1', name: 'Marcus Vance', handle: '@marcus', avatar: '', verified: true },
    category: 'Gaming',
    duration: 42,
    durationFormatted: '0:42',
    resolution: '1080x1920 (9:16)',
    fps: 60,
    downloads: 10,
    views: 100,
    likes: 1,
    tags: ['fun'],
    status: 'Published',
    createdAt: '2026-01-01T00:00:00.000Z',
    licenseInfo: {
      licenseId: 'LIC-1',
      type: 'Non-Exclusive',
      status: 'Active',
      sourceUrl: 'https://example.com',
      allowedPlatforms: ['TikTok'],
      attributionRequired: false,
      expiresAt: '2030-01-01T00:00:00.000Z'
    }
  };
  return { ...base, ...overrides, licenseInfo: { ...base.licenseInfo, ...(overrides.licenseInfo || {}) } };
}
