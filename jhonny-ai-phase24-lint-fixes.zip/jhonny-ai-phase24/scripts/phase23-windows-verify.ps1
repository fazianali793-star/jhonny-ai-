[CmdletBinding()]
param(
    [switch]$InstallAndVerify,
    [string]$LogPath = ".\phase24-verification.log"
)

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
$root = (Get-Location).Path
$logFullPath = [System.IO.Path]::GetFullPath($LogPath)
# Never overwrite a diagnostic log supplied by the user; choose a timestamped sibling.
if (Test-Path -LiteralPath $logFullPath) {
    $logDir = [System.IO.Path]::GetDirectoryName($logFullPath)
    $logBase = [System.IO.Path]::GetFileNameWithoutExtension($logFullPath)
    $logExt = [System.IO.Path]::GetExtension($logFullPath)
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $logFullPath = Join-Path $logDir ("{0}-{1}{2}" -f $logBase, $stamp, $logExt)
}
Start-Transcript -Path $logFullPath | Out-Null
$script:failures = 0

function Write-Section([string]$Title) {
    Write-Host "`n===== $Title ====="
}
function Run-Check([string]$Label, [scriptblock]$Command) {
    Write-Host "--- $Label ---"
    try {
        & $Command
        $code = $LASTEXITCODE
        if ($null -ne $code -and $code -ne 0) {
            Write-Host "RESULT: FAIL (exit $code)"
            $script:failures++
            return $false
        }
        Write-Host 'RESULT: command completed'
        return $true
    } catch {
        Write-Host "RESULT: FAIL ($($_.Exception.Message))"
        $script:failures++
        return $false
    }
}

Write-Section 'Project and toolchain'
Write-Host "Project root: $root"
node --version
npm --version
Write-Host "npm registry: $(npm config get registry)"
# Proxy URLs can embed credentials. Record only whether values are configured.
foreach ($key in @('proxy','https-proxy')) {
    $configured = (npm config get $key 2>$null | Out-String).Trim()
    $isSet = -not [string]::IsNullOrWhiteSpace($configured) -and $configured -ne 'null' -and $configured -ne 'undefined'
    Write-Host ("npm {0}: {1}" -f $key, $(if ($isSet) {'configured (value redacted)'} else {'not configured'}))
}
$strictSsl = (npm config get strict-ssl).Trim()
Write-Host "npm strict-ssl: $strictSsl"
Write-Host "Proxy environment variables are reported only as set/unset (values may contain credentials):"
foreach ($name in @('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy')) {
    $value = [Environment]::GetEnvironmentVariable($name)
    Write-Host ("{0}: {1}" -f $name, $(if ([string]::IsNullOrWhiteSpace($value)) {'unset'} else {'set'}))
}

Write-Section 'DNS and HTTPS diagnosis'
$dnsOk = $false
try {
    $answers = Resolve-DnsName registry.npmjs.org -ErrorAction Stop
    $answers | Where-Object { $_.Type -in @('A','AAAA') } | Select-Object Name,Type,IPAddress | Format-Table -AutoSize
    $dnsOk = [bool]($answers | Where-Object { $_.Type -in @('A','AAAA') })
} catch {
    Write-Host "Resolve-DnsName failed: $($_.Exception.Message)"
}
try {
    nslookup registry.npmjs.org
} catch {
    Write-Host "nslookup failed: $($_.Exception.Message)"
}
$tcpOk = $false
try {
    $tcp = Test-NetConnection registry.npmjs.org -Port 443 -WarningAction SilentlyContinue
    $tcp | Select-Object ComputerName,RemoteAddress,RemotePort,TcpTestSucceeded | Format-List
    $tcpOk = [bool]$tcp.TcpTestSucceeded
} catch {
    Write-Host "TCP test failed: $($_.Exception.Message)"
}
$httpsOk = $false
if ($dnsOk -and $tcpOk) {
    if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
        $httpsOk = (Run-Check 'HTTPS/TLS request to official registry (curl)' { curl.exe --silent --show-error --head --max-time 15 https://registry.npmjs.org/ })
    } else {
        Write-Host 'curl.exe unavailable; HTTPS/TLS diagnosis will rely on npm ping output.'
    }
} else {
    Write-Host 'HTTPS/TLS probe not attempted: DNS or TCP/443 is failing.'
}
$pingOk = $false
if ($dnsOk -and $tcpOk) {
    $pingOk = (Run-Check 'npm ping (registry reachability)' { npm ping --fetch-retries=0 --fetch-timeout=15000 })
} else {
    Write-Host 'npm ping not attempted: DNS or TCP/443 is still failing; avoiding a redundant install attempt.'
}

if (-not $InstallAndVerify) {
    Write-Section 'Diagnosis-only result'
    if (-not $dnsOk) { Write-Host 'DIAGNOSIS: Windows could not resolve registry.npmjs.org. Check active network/VPN DNS policy with your administrator; do not change DNS servers blindly.' }
    elseif (-not $tcpOk) { Write-Host 'DIAGNOSIS: DNS resolved but TCP/443 failed. Check firewall, VPN, captive portal, or network policy.' }
    elseif (-not $httpsOk -and (Get-Command curl.exe -ErrorAction SilentlyContinue)) { Write-Host 'DIAGNOSIS: DNS/TCP succeeded but HTTPS/TLS request failed; inspect curl error, certificate trust, interception proxy, firewall, and system clock. Do not disable TLS verification.' }
    elseif (-not $pingOk) { Write-Host 'DIAGNOSIS: DNS and TCP/443 worked, but npm ping failed. Inspect the exact npm error for proxy, npm configuration, or TLS/certificate issues.' }
    else { Write-Host 'DIAGNOSIS: registry DNS, TCP/443, and npm ping succeeded. Run this script again with -InstallAndVerify to install and validate.' }
    Write-Host "Log saved to: $logFullPath"
    Stop-Transcript | Out-Null
    exit 0
}

if (-not $dnsOk -or -not $tcpOk -or -not $pingOk -or ((Get-Command curl.exe -ErrorAction SilentlyContinue) -and -not $httpsOk)) {
    Write-Section 'Safe stop'
    Write-Host 'Install/verification stopped because registry DNS/HTTPS was not verified. No DNS changes, TLS bypasses, or registry mirror changes were attempted.'
    Write-Host "Log saved to: $logFullPath"
    Stop-Transcript | Out-Null
    exit 2
}

Write-Section 'Generate genuine lockfile and clean-install dependencies'
if ((npm config get registry).TrimEnd('/') -ne 'https://registry.npmjs.org') {
    Write-Host 'STOP: npm registry is not the expected official registry. Review your organization configuration before continuing.'
    Stop-Transcript | Out-Null
    exit 3
}
if ($strictSsl -ne 'true') {
    Write-Host 'STOP: npm strict-ssl is not true. Do not disable TLS verification; restore the secure setting or resolve the certificate configuration with your administrator.'
    Stop-Transcript | Out-Null
    exit 5
}
$installOk = Run-Check 'npm install --no-audit --no-fund' { npm install --no-audit --no-fund }
if (-not $installOk -or -not (Test-Path '.\package-lock.json')) {
    Write-Host 'STOP: npm install failed or did not produce package-lock.json. No npm ci or frontend checks will be claimed.'
    Stop-Transcript | Out-Null
    exit 4
}
Write-Host "Lockfile created: $(Get-Item .\package-lock.json | Select-Object -ExpandProperty Length) bytes"
$ciOk = Run-Check 'npm ci --no-audit --no-fund' { npm ci --no-audit --no-fund }
if ($ciOk) {
    Run-Check 'npm test' { npm test }
    Run-Check 'npm run typecheck' { npm run typecheck }
    Run-Check 'npm run lint' { npm run lint }
    Run-Check 'npm run build' { npm run build }
} else {
    Write-Host 'Frontend checks skipped because clean npm ci failed.'
}

Write-Section 'Backend regression checks (if Python and pytest are available)'
$pythonCmd = $null
if (Get-Command py -ErrorAction SilentlyContinue) { $pythonCmd = 'py' }
elseif (Get-Command python -ErrorAction SilentlyContinue) { $pythonCmd = 'python' }
if ($pythonCmd) {
    if ($pythonCmd -eq 'py') { & py -3 -m compileall -q backend\app backend\tests; $compileCode = $LASTEXITCODE }
    else { & python -m compileall -q backend\app backend\tests; $compileCode = $LASTEXITCODE }
    Write-Host "Python compileall exit: $compileCode"
    if ($compileCode -ne 0) { $script:failures++ }
    if ($pythonCmd -eq 'py') { & py -3 -m pytest backend\tests -q -ra; $testCode = $LASTEXITCODE }
    else { & python -m pytest backend\tests -q -ra; $testCode = $LASTEXITCODE }
    Write-Host "Backend pytest exit: $testCode"
    if ($testCode -ne 0) { $script:failures++ }
} else {
    Write-Host 'Python not found; backend checks not run.'
    $script:failures++
}

Write-Section 'Summary'
Write-Host "Failure count: $script:failures"
Write-Host "Log saved to: $logFullPath"
Stop-Transcript | Out-Null
if ($script:failures -gt 0) { exit 1 }
exit 0
