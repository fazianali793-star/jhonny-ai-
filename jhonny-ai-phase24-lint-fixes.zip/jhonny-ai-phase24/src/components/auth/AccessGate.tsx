import React from 'react';
import { ShieldAlert, LogIn } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useRouter } from '../../router/Router';
import { decideRouteAccess, RouteRequirement } from '../../lib/auth';
import { EmptyState } from '../common/EmptyState';

/**
 * Renders children only when the current session may view them. This is a UI
 * gate: the role comes from browser storage or the demo switcher, so the server
 * must enforce the same rules on every request.
 */
export const AccessGate: React.FC<{ requirement: RouteRequirement; children: React.ReactNode }> = ({
  requirement,
  children
}) => {
  const { currentUser } = useApp();
  const { navigate } = useRouter();
  const decision = decideRouteAccess(requirement, currentUser);

  if (decision.allowed) return <>{children}</>;

  if (decision.reason === 'login_required') {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20">
        <EmptyState
          icon={LogIn}
          title="Sign in required"
          description="This page is only available to signed-in accounts. Sign in to continue."
          actionLabel="Go to sign in"
          onAction={() => navigate('/login')}
        />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-20">
      <EmptyState
        icon={ShieldAlert}
        title="Access denied"
        description="Your account does not have permission to view this page. Admin pages require an administrator account."
        actionLabel="Return home"
        onAction={() => navigate('/')}
      />
    </div>
  );
};
