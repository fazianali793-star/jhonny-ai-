import React, { useCallback, useEffect, useState } from 'react';
import { Link } from '../../router/Router';
import { ApiClip, ApiProject, ApiError, createApiProject, deleteApiProject, duplicateApiProject, fetchApiClips, fetchMyClips, fetchApiProjects, moderateApiClip, saveApiProject, createApiRender, fetchApiRender, downloadApiFile, currentUserApi } from '../../lib/api';

const panel = 'rounded-xl border border-neutral-800 bg-neutral-900/80 p-4';
const button = 'rounded-lg border border-neutral-700 px-3 py-2 text-xs text-neutral-100 hover:bg-neutral-800 disabled:opacity-50';
const errorText = 'text-xs text-rose-400';
const dateText = (value?: string | null) => value ? new Date(value).toLocaleString() : '—';

export const BackendLibraryPanel: React.FC = () => {
  const [items, setItems] = useState<ApiClip[]>([]); const [q, setQ] = useState(''); const [sort, setSort] = useState('newest');
  const [page, setPage] = useState(1); const [total, setTotal] = useState(0); const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  const load = useCallback(async () => { setBusy(true); setError(''); try { const data = await fetchApiClips({ q, sort, page, pageSize: 12 }); setItems(data.items); setTotal(data.total); } catch (e) { setItems([]); setTotal(0); setError(e instanceof Error ? e.message : 'Could not load Library from backend.'); } finally { setBusy(false); } }, [q, sort, page]);
  useEffect(() => { void load(); }, [load]);
  return <section className={panel} aria-label="Backend Library">
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3"><div><h2 className="text-sm font-bold text-white">Live Library · Backend</h2><p className="text-xs text-neutral-400">Only published clips with active, unexpired licenses are returned to public visitors.</p></div><button className={button} onClick={() => void load()} disabled={busy}>Refresh</button></div>
    <div className="flex flex-col sm:flex-row gap-2 mb-3"><input aria-label="Search server clips" value={q} onChange={e => { setPage(1); setQ(e.target.value); }} placeholder="Search published clips" className="flex-1 rounded-lg bg-neutral-950 border border-neutral-700 px-3 py-2 text-xs text-white"/><select aria-label="Sort server clips" value={sort} onChange={e => { setPage(1); setSort(e.target.value); }} className="rounded-lg bg-neutral-950 border border-neutral-700 px-3 py-2 text-xs text-white"><option value="newest">Newest</option><option value="title">Title A–Z</option><option value="duration">Duration</option></select></div>
    {busy && <p role="status" className="text-xs text-neutral-300">Loading published clips…</p>}{error && <p role="alert" className={errorText}>{error} Demo data is not substituted for failed API results.</p>}
    {!busy && !error && items.length === 0 && <p className="text-xs text-neutral-400 py-4">No published, licensed clips match this search yet.</p>}
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">{items.map(c => <article key={c.id} className="rounded-lg border border-neutral-800 bg-neutral-950 p-3"><h3 className="text-sm font-semibold text-white break-words"><Link href={`/clips/${encodeURIComponent(c.id)}`} className="hover:text-rose-300 underline-offset-2 hover:underline">{c.title}</Link></h3><p className="mt-1 text-[11px] text-neutral-400">{c.duration ? `${Math.round(c.duration)} sec` : 'Duration unknown'} · {c.width ?? '?'}×{c.height ?? '?'}</p><p className="mt-1 text-[11px] text-emerald-400">Published · License {c.license_status ?? 'unavailable'}</p><p className="mt-1 text-[10px] text-neutral-500">Added {dateText(c.created_at)}</p><p className="mt-2 text-[10px] text-neutral-600 break-all">Clip ID: {c.id}</p></article>)}</div>
    {!error && total > 12 && <div className="flex justify-between items-center mt-3"><span className="text-[11px] text-neutral-400">{total} published clips</span><div className="flex gap-2"><button className={button} disabled={page<=1||busy} onClick={() => setPage(p=>p-1)}>Previous</button><button className={button} disabled={page*12>=total||busy} onClick={() => setPage(p=>p+1)}>Next</button></div></div>}
  </section>;
};


export const CreatorSubmissionsPanel: React.FC = () => {
  const [items, setItems] = useState<ApiClip[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const load = useCallback(async () => {
    setBusy(true); setError(''); setNotice('');
    try {
      const page = await fetchMyClips({ page: 1, pageSize: 100 });
      setItems(page.items);
    } catch (e) {
      setItems([]); setError(e instanceof Error ? e.message : 'Your submissions could not be loaded from the backend.');
    } finally { setBusy(false); }
  }, []);
  useEffect(() => { void load(); }, [load]);
  return <section className={panel} aria-label="Your server submissions">
    <div className="flex items-start justify-between gap-3"><div><h2 className="text-sm font-bold text-white">Your Submissions · Live Backend</h2><p className="text-xs text-neutral-400">Review state and license status are read from your authenticated server records.</p></div><button className={button} onClick={() => void load()} disabled={busy}>Refresh</button></div>
    {busy && <p role="status" className="text-xs text-neutral-300 mt-3">Loading your submissions…</p>}
    {error && <p role="alert" className={`${errorText} mt-3`}>Could not load live submissions: {error}. Local/demo records are not used as a fallback.</p>}
    {!busy && !error && items.length === 0 && <p className="text-xs text-neutral-400 mt-3">No submissions have been returned for this account.</p>}
    {!error && items.length > 0 && <div className="overflow-x-auto mt-3"><table className="w-full text-left text-xs"><thead><tr><th className="p-2 border-b border-neutral-700">Title</th><th className="p-2 border-b border-neutral-700">Review status</th><th className="p-2 border-b border-neutral-700">License</th><th className="p-2 border-b border-neutral-700">Duration</th><th className="p-2 border-b border-neutral-700">Submitted</th></tr></thead><tbody>{items.map(clip => <tr key={clip.id} className="border-b border-neutral-800"><td className="p-2 text-neutral-100">{clip.title}</td><td className="p-2 text-neutral-200">{clip.status}</td><td className="p-2 text-neutral-200">{clip.license_status ?? 'Missing'}</td><td className="p-2 text-neutral-300">{clip.duration == null ? 'Unknown' : `${Math.round(clip.duration)} sec`}</td><td className="p-2 text-neutral-400">{dateText(clip.created_at)}</td></tr>)}</tbody></table></div>}
  </section>;
};

export const BackendStudioPanel: React.FC = () => {
  const [projects, setProjects] = useState<ApiProject[]>([]); const [clips, setClips] = useState<ApiClip[]>([]); const [name, setName] = useState(''); const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const [notice, setNotice] = useState(''); const [renderId, setRenderId] = useState(''); const [renderInfo, setRenderInfo] = useState('');
  const load = useCallback(async () => { try { const [saved, me, media] = await Promise.all([fetchApiProjects(), currentUserApi(), fetchApiClips({page:1,pageSize:100})]); setProjects(saved); setClips(media.items.filter(c => c.owner_id === me.id && ['Pending','Published','Rejected','Suspended'].includes(c.status))); setError(''); } catch(e) { setProjects([]); setClips([]); setError(e instanceof Error ? e.message : 'Could not load saved projects.'); } }, []);
  useEffect(() => { void load(); }, [load]);
  // Poll only while a job exists; the interval is always cleared on job change/unmount.
  useEffect(() => {
    if (!renderId) return;
    let active = true;
    const poll = async () => { try { const r = await fetchApiRender(renderId); if (active) setRenderInfo(`${r.status} · ${r.progress}%${r.error ? ` · ${r.error}` : ''}`); } catch (e) { if (active) setError(e instanceof Error ? e.message : 'Could not retrieve render status.'); } };
    void poll();
    const timer = window.setInterval(() => { void poll(); }, 2500);
    return () => { active = false; window.clearInterval(timer); };
  }, [renderId]);
  const create = async (e: React.FormEvent) => { e.preventDefault(); if (!name.trim()) return; setBusy(true); setError(''); try { const source = clips[0]; await createApiProject(name.trim(), source?.id ?? null, source ? { trim_start: 0, trim_end: Math.max(1, Number(source.duration ?? 30)) } : {}); setName(''); setNotice('Project saved to the server.'); await load(); } catch(e) { setError(e instanceof Error ? e.message : 'Project creation failed.'); } finally { setBusy(false); } };
  const duplicate = async (id: string) => { setBusy(true); try { await duplicateApiProject(id); setNotice('Project duplicated on server.'); await load(); } catch(e) { setError(e instanceof Error ? e.message : 'Could not duplicate project.'); } finally { setBusy(false); } };
  const remove = async (id: string) => { if (!window.confirm('Delete this server-saved project?')) return; setBusy(true); try { await deleteApiProject(id); await load(); setNotice('Project deleted.'); } catch(e) { setError(e instanceof Error ? e.message : 'Could not delete project.'); } finally { setBusy(false); } };
  const saveSettings = async (p: ApiProject, sourceId: string, trimStart: number, trimEnd: number) => {
    if (!Number.isFinite(trimStart) || !Number.isFinite(trimEnd) || trimStart < 0 || trimEnd <= trimStart) { setError('Trim end must be greater than trim start.'); return; }
    const source = clips.find(c => c.id === sourceId);
    if (!source) { setError('Select a source clip owned by your account.'); return; }
    if (source.duration && trimEnd > source.duration) { setError('Trim end exceeds the source clip duration.'); return; }
    setBusy(true); setError('');
    try { await saveApiProject({ ...p, source_clip_id: sourceId, settings: { ...p.settings, trim_start: trimStart, trim_end: trimEnd } }); setNotice('Project settings saved to the server.'); await load(); }
    catch(e) { setError(e instanceof Error ? e.message : 'Could not save project settings.'); }
    finally { setBusy(false); }
  };
  const startRender = async (p: ApiProject) => { const settings = p.settings; const start = Number(settings.trim_start ?? settings.trimStart ?? 0); const end = Number(settings.trim_end ?? settings.trimEnd ?? 0); if (!p.source_clip_id || !Number.isFinite(end) || end <= start) { setError('Choose an owned source clip and save a valid trim range before rendering.'); return; } setBusy(true); try { const job = await createApiRender(p.id,{trim_start:start,trim_end:end,width:1080,height:1920,aspect_ratio:'9:16',output_format:'mp4'}); setRenderId(job.id); setRenderInfo(`Render ${job.status}`); } catch(e) { setError(e instanceof Error ? e.message : 'Render could not be started.'); } finally { setBusy(false); } };
  const pollRender = async () => { if (!renderId) return; try { const r = await fetchApiRender(renderId); setRenderInfo(`${r.status} · ${r.progress}%${r.error ? ` · ${r.error}` : ''}`); if (r.status === 'completed') await downloadApiFile(`/api/renders/${r.id}/download`,`jhonny-render-${r.id}.mp4`); } catch(e) { setError(e instanceof Error ? e.message : 'Could not retrieve render status.'); } };
  return <section className={panel} aria-label="Server Studio projects"><div className="flex justify-between gap-3 items-start"><div><h2 className="text-sm font-bold text-white">Saved Studio Projects · Backend</h2><p className="text-xs text-neutral-400">Projects persist in SQLite and are scoped to your authenticated account.</p></div><button className={button} onClick={() => void load()} disabled={busy}>Refresh</button></div>
    <form onSubmit={create} className="flex gap-2 mt-3"><input value={name} onChange={e=>setName(e.target.value)} maxLength={160} placeholder="New server project name" aria-label="New server project name" className="min-w-0 flex-1 rounded-lg bg-neutral-950 border border-neutral-700 px-3 py-2 text-xs text-white"/><button className={button} disabled={busy||!name.trim()}>Create</button></form>
    {error && <p role="alert" className={`${errorText} mt-2`}>{error}</p>}{notice && <p role="status" className="text-xs text-emerald-400 mt-2">{notice}</p>}
    {projects.length===0 && !error ? <p className="text-xs text-neutral-400 py-4">No server-saved projects yet.</p> : <ul className="mt-3 space-y-2">{projects.map(p=><li key={p.id} className="rounded-lg border border-neutral-800 p-3 flex flex-col sm:flex-row sm:items-center gap-2 justify-between"><div className="min-w-0"><p className="text-xs font-semibold text-white">{p.name}</p><p className="text-[10px] text-neutral-500">Updated {dateText(p.updated_at)} · {p.source_clip_id ? 'Source selected' : 'No source selected'}</p><p className="text-[10px] text-neutral-600 break-all">{p.id}</p><div className="mt-2 grid sm:grid-cols-3 gap-2"><label className="text-[10px] text-neutral-400">Owned source clip<select aria-label={`Source clip for ${p.name}`} defaultValue={p.source_clip_id ?? ''} id={`source-${p.id}`} className="block mt-1 w-full rounded bg-neutral-900 border border-neutral-700 px-2 py-2 text-xs text-white"><option value="">Choose owned clip</option>{clips.map(c=><option key={c.id} value={c.id}>{c.title} ({c.duration ? `${Math.round(c.duration)}s` : 'duration ?'})</option>)}</select></label><label className="text-[10px] text-neutral-400">Trim start (seconds)<input aria-label={`Trim start for ${p.name}`} id={`start-${p.id}`} type="number" min="0" step="0.1" defaultValue={Number(p.settings.trim_start ?? 0)} className="block mt-1 w-full rounded bg-neutral-900 border border-neutral-700 px-2 py-2 text-xs text-white"/></label><label className="text-[10px] text-neutral-400">Trim end (seconds)<input aria-label={`Trim end for ${p.name}`} id={`end-${p.id}`} type="number" min="0.1" step="0.1" defaultValue={Number(p.settings.trim_end ?? 0)} className="block mt-1 w-full rounded bg-neutral-900 border border-neutral-700 px-2 py-2 text-xs text-white"/></label></div></div><div className="flex flex-wrap gap-2"><button className={button} disabled={busy} onClick={()=>{const source=(document.getElementById(`source-${p.id}`) as HTMLSelectElement)?.value; const start=Number((document.getElementById(`start-${p.id}`) as HTMLInputElement)?.value); const end=Number((document.getElementById(`end-${p.id}`) as HTMLInputElement)?.value); void saveSettings(p,source,start,end);}}>Save settings</button><button className={button} disabled={busy} onClick={()=>void duplicate(p.id)}>Duplicate</button><button className={button} disabled={busy} onClick={()=>void startRender(p)}>Render MP4</button><button className={button} disabled={busy} onClick={()=>void remove(p.id)}>Delete</button></div></li>)}</ul>}
    {renderId && <div className="mt-3 rounded-lg bg-neutral-950 p-3"><p className="text-xs text-neutral-200">Render job: {renderId}</p><p className="text-xs text-neutral-400 mt-1">{renderInfo}</p><button className={`${button} mt-2`} onClick={()=>void pollRender()}>Refresh status / download if complete</button></div>}
  </section>;
};

export const BackendAdminPanel: React.FC = () => {
  const [items,setItems] = useState<ApiClip[]>([]); const [busy,setBusy] = useState(false); const [error,setError] = useState(''); const [note,setNote] = useState('');
  const load = useCallback(async()=>{setBusy(true);setError('');try{const data=await fetchApiClips({status:'Pending',sort:'newest',page:1,pageSize:100});setItems(data.items);}catch(e){setItems([]);setError(e instanceof ApiError ? e.message : e instanceof Error ? e.message : 'Unable to load moderation queue.');}finally{setBusy(false);}},[]);
  useEffect(()=>{void load();},[load]);
  const moderate = async (clip: ApiClip, action: 'approve'|'reject'|'suspend'|'remove') => { setBusy(true); setError(''); try { if(action==='approve' && clip.license_status!=='Active') throw new Error('Activate and verify this clip license in the Rights Registry before approval.'); await moderateApiClip(clip.id,action,note); setNote(''); await load(); } catch(e) { setError(e instanceof Error ? e.message : 'Moderation action failed.'); } finally { setBusy(false); } };
  return <section className={panel} aria-label="Server moderation queue"><div className="flex items-start justify-between gap-3"><div><h2 className="text-sm font-bold text-white">Real Moderation Queue · Backend</h2><p className="text-xs text-neutral-400">Every action is checked by FastAPI admin authorization. Approval requires rights verification.</p></div><button className={button} onClick={()=>void load()} disabled={busy}>Refresh</button></div>
    <label className="block text-xs text-neutral-300 mt-3 mb-1" htmlFor="rights-note">Rights verification / moderation note (required to activate a license)</label><textarea id="rights-note" value={note} onChange={e=>setNote(e.target.value)} rows={2} className="w-full rounded-lg bg-neutral-950 border border-neutral-700 px-3 py-2 text-xs text-white" placeholder="Describe the rights evidence reviewed…"/>
    {error && <p role="alert" className={`${errorText} mt-2`}>{error}</p>}{busy && <p role="status" className="text-xs text-neutral-300 mt-2">Contacting backend…</p>}{!busy&&!error&&!items.length&&<p className="text-xs text-neutral-400 py-4">No pending server submissions.</p>}
    <ul className="mt-3 space-y-2">{items.map(c=><li key={c.id} className="rounded-lg border border-neutral-800 p-3"><div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3"><div><h3 className="text-xs font-semibold text-white">{c.title}</h3><p className="text-[10px] text-neutral-400">{c.width}×{c.height} · {c.duration ? `${Math.round(c.duration)}s` : 'Unknown duration'} · License: {c.license_status ?? 'missing'}</p><p className="text-[10px] text-neutral-600 break-all">{c.id}</p></div><div className="flex flex-wrap gap-2"><button className={button} disabled={busy||note.trim().length<10||c.license_status!=='Active'} title={c.license_status!=='Active'?'Activate the license in Rights Registry first':'Requires a moderation note of at least 10 characters'} onClick={()=>void moderate(c,'approve')}>Verify rights & approve</button><button className={button} disabled={busy} onClick={()=>void moderate(c,'reject')}>Reject</button><button className={button} disabled={busy} onClick={()=>void moderate(c,'suspend')}>Suspend</button><button className={button} disabled={busy} onClick={()=>void moderate(c,'remove')}>Remove</button></div></div></li>)}</ul>
  </section>;
};
