import React from 'react';
import { X, CheckCircle2, Download, ShieldCheck, AlertTriangle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { canDownloadClip } from '../../lib/rights';

/**
 * Download dialog. A download starts only when the rights check passes AND the
 * clip has a server-issued media URL. This build has no media storage, so every
 * clip shows "unavailable" with the reason. No placeholder files are created.
 */
export const DownloadModal: React.FC = () => {
  const { activeDownloadClip, closeDownloadModal, recordDownload, addToast } = useApp();

  if (!activeDownloadClip) return null;

  const clip = activeDownloadClip;
  const decision = canDownloadClip(clip);

  const handleStartDownload = () => {
    if (!decision.allowed) return;
    // Re-check at the moment of the action; the modal may have been open a while.
    if (!recordDownload(clip)) return;

    const link = document.createElement('a');
    link.href = clip.mediaUrl as string;
    link.rel = 'noopener';
    link.download = `jhonny-ai-${clip.slug}.mp4`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    addToast('Download Started', 'If the file does not start, the link may have expired. Try again from the clip page.', 'info');
    closeDownloadModal();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
      aria-labelledby="download-dialog-title"
    >
      <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden p-6">
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-neutral-800 flex items-center justify-center border border-neutral-700">
              <Download className="w-4 h-4 text-rose-400" />
            </div>
            <div>
              <h3 id="download-dialog-title" className="font-semibold text-sm text-neutral-100">Download Clip</h3>
              <p className="text-[11px] text-neutral-400">JHONNY AI licensed clip</p>
            </div>
          </div>
          <button
            type="button"
            onClick={closeDownloadModal}
            aria-label="Close"
            className="p-1 rounded-lg text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="my-5 p-3 rounded-xl bg-neutral-950/60 border border-neutral-800 flex items-center gap-3">
          <img
            src={clip.thumbnail}
            alt=""
            referrerPolicy="no-referrer"
            className="w-14 h-20 rounded-lg object-cover border border-neutral-800 shrink-0"
          />
          <div className="min-w-0 flex-1">
            <h4 className="font-medium text-xs text-neutral-200 line-clamp-2 mb-1">{clip.title}</h4>
            <div className="text-[11px] text-neutral-400 flex items-center gap-2 mb-1 font-mono">
              <span>{clip.durationFormatted}</span>
              <span>·</span>
              <span>{clip.resolution}</span>
            </div>
            <div className="text-[11px] text-neutral-400">Licensed by {clip.creator.name}</div>
          </div>
        </div>

        {decision.allowed ? (
          <>
            <div className="mb-5 p-3 rounded-lg bg-neutral-950/40 border border-neutral-800/80 text-[11px] text-neutral-400 space-y-1">
              <div className="flex items-center gap-1.5 text-neutral-300 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>License active · Allowed on {clip.licenseInfo.allowedPlatforms.join(', ')}</span>
              </div>
              {clip.licenseInfo.attributionRequired && (
                <p className="pl-5">Attribution to {clip.creator.name} is required.</p>
              )}
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={closeDownloadModal}
                className="flex-1 py-2 px-4 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-neutral-300 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleStartDownload}
                className="flex-1 py-2 px-4 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 bg-rose-500 hover:bg-rose-600 text-white shadow-lg shadow-rose-950 active:scale-95 transition-all"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download MP4</span>
              </button>
            </div>
          </>
        ) : (
          <>
            <div
              role="alert"
              className="mb-5 p-3 rounded-lg bg-amber-500/5 border border-amber-500/30 text-[11px] text-amber-200 flex gap-2"
            >
              <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
              <p>{decision.message}</p>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-neutral-500 mb-4">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Rights are checked on every download request. The production service must confirm them again.</span>
            </div>
            <button
              type="button"
              onClick={closeDownloadModal}
              className="w-full py-2 px-4 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-neutral-300 transition-colors"
            >
              Close
            </button>
          </>
        )}
      </div>
    </div>
  );
};
