import React, { useState } from 'react';
import { Search, User, Video, Menu, X, Check } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useRouter, Link } from '../../router/Router';
import { DEMO_ADMIN_PERSONA_ENABLED, DEMO_PERSONAS_ENABLED } from '../../lib/demo';

export const Navbar: React.FC = () => {
  const { currentUser, switchRole } = useApp();
  const { path, navigate } = useRouter();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [roleMenuOpen, setRoleMenuOpen] = useState(false);

  const isActive = (href: string) => {
    if (href === '/' && path === '/') return true;
    if (href !== '/' && path.startsWith(href)) return true;
    return false;
  };

  const currentRoleLabel = currentUser
    ? currentUser.role === 'admin'
      ? 'Admin'
      : currentUser.role === 'creator'
      ? 'Creator'
      : 'User'
    : 'Guest';

  return (
    <>
      <header className="sticky top-0 z-40 w-full bg-neutral-950/85 backdrop-blur-md border-b border-neutral-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Zone 1: Brand Wordmark (Single text element) */}
          <Link
            href="/"
            className="flex items-center gap-2 group focus:outline-none"
          >
            <span className="text-lg font-extrabold tracking-tight text-white group-hover:text-rose-400 transition-colors">
              JHONNY <span className="text-rose-500">AI</span>
            </span>
          </Link>

          {/* Zone 2: Navigation Links (Clean text links) */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-neutral-300">
            <Link
              href="/clips"
              className={`hover:text-white transition-colors ${
                isActive('/clips') && !path.startsWith('/clips/') ? 'text-white font-semibold' : ''
              }`}
            >
              Browse Clips
            </Link>
            {currentUser && (
              <Link
                href="/studio"
                className={`hover:text-white transition-colors ${
                  isActive('/studio') ? 'text-white font-semibold' : ''
                }`}
              >
                Studio
              </Link>
            )}
            <Link
              href="/creator"
              className={`hover:text-white transition-colors ${
                isActive('/creator') ? 'text-white font-semibold' : ''
              }`}
            >
              Creators
            </Link>
            <Link
              href="/admin"
              className={`hover:text-white transition-colors ${
                isActive('/admin') ? 'text-white font-semibold' : ''
              }`}
            >
              Admin Console
            </Link>
            <Link
              href="/copyright"
              className={`hover:text-white transition-colors ${
                isActive('/copyright') ? 'text-white font-semibold' : ''
              }`}
            >
              Rights & DMCA
            </Link>
          </nav>

          {/* Zone 3: Actions (Search, Demo Role Switcher, Dashboard/Login CTA) */}
          <div className="flex items-center gap-3">
            {/* Search Trigger */}
            <Link
              href="/search"
              aria-label="Search clips"
              className="p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors"
            >
              <Search className="w-4 h-4" />
            </Link>

            {/* Prototype Role Switcher Dropdown */}
            {DEMO_PERSONAS_ENABLED && <div className="relative">
              <button
                onClick={() => setRoleMenuOpen(!roleMenuOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs font-mono text-neutral-300 transition-colors"
                title="Switch demo persona for testing"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                <span>{currentRoleLabel}</span>
              </button>

              {roleMenuOpen && (
                <div
                  className="absolute right-0 mt-2 w-52 bg-neutral-900 border border-neutral-800 rounded-xl shadow-2xl py-2 z-50 text-xs"
                  onClick={() => setRoleMenuOpen(false)}
                >
                  <div className="px-3 py-1.5 font-semibold text-neutral-500 border-b border-neutral-800 text-[10px] uppercase font-mono">
                    Demo Personas (Prototype)
                  </div>
                  <button
                    onClick={() => switchRole('user')}
                    className="w-full text-left px-3 py-2 text-neutral-200 hover:bg-neutral-800 flex items-center justify-between"
                  >
                    <span>Regular User (Jordan)</span>
                    {currentUser?.role === 'user' && <Check className="w-3.5 h-3.5 text-rose-400" />}
                  </button>
                  <button
                    onClick={() => switchRole('creator')}
                    className="w-full text-left px-3 py-2 text-neutral-200 hover:bg-neutral-800 flex items-center justify-between"
                  >
                    <span>Creator (Marcus Vance)</span>
                    {currentUser?.role === 'creator' && <Check className="w-3.5 h-3.5 text-rose-400" />}
                  </button>
                  {DEMO_ADMIN_PERSONA_ENABLED && (
                    <button
                      onClick={() => switchRole('admin')}
                      className="w-full text-left px-3 py-2 text-neutral-200 hover:bg-neutral-800 flex items-center justify-between"
                    >
                      <span>Admin (dev only)</span>
                      {currentUser?.role === 'admin' && <Check className="w-3.5 h-3.5 text-rose-400" />}
                    </button>
                  )}
                  <button
                    onClick={() => switchRole('guest')}
                    className="w-full text-left px-3 py-2 text-neutral-400 hover:bg-neutral-800 flex items-center justify-between"
                  >
                    <span>Guest (Logged out)</span>
                    {!currentUser && <Check className="w-3.5 h-3.5 text-rose-400" />}
                  </button>
                </div>
              )}
            </div>}

            {/* Dashboard / Auth CTA */}
            {currentUser ? (
              <Link
                href={
                  currentUser.role === 'admin'
                    ? '/admin'
                    : currentUser.role === 'creator'
                    ? '/creator'
                    : '/dashboard'
                }
                className="hidden sm:flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-700/80 text-xs font-semibold text-neutral-100 transition-colors whitespace-nowrap"
              >
                <img
                  src={currentUser.avatar}
                  alt=""
                  className="w-4 h-4 rounded-full object-cover"
                />
                <span className="truncate max-w-[100px]">{currentUser.name.split(' ')[0]}</span>
              </Link>
            ) : (
              <Link
                href="/login"
                className="hidden sm:inline-flex items-center px-3.5 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-xs font-semibold text-neutral-200 border border-neutral-800 hover:border-neutral-700 transition-colors whitespace-nowrap"
              >
                Sign In
              </Link>
            )}

            {/* Mobile Menu Toggle Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-neutral-800 bg-neutral-950 px-4 py-4 space-y-3">
            <Link
              href="/clips"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-sm font-medium text-neutral-200 hover:text-white"
            >
              Browse Clips
            </Link>
            {currentUser && (
              <Link
                href="/studio"
                onClick={() => setMobileMenuOpen(false)}
                className="block py-2 text-sm font-medium text-neutral-200 hover:text-white"
              >
                Studio
              </Link>
            )}
            <Link
              href="/creator"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-sm font-medium text-neutral-200 hover:text-white"
            >
              Creator Portal
            </Link>
            <Link
              href="/admin"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-sm font-medium text-neutral-200 hover:text-white"
            >
              Admin & Rights Console
            </Link>
            <Link
              href="/copyright"
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-sm font-medium text-neutral-200 hover:text-white"
            >
              Copyright & DMCA Policy
            </Link>
            <div className="pt-3 border-t border-neutral-800 flex items-center justify-between">
              {currentUser ? (
                <Link
                  href="/dashboard"
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-xs font-semibold text-rose-400"
                >
                  Go to {currentUser.role} dashboard →
                </Link>
              ) : (
                <Link
                  href="/login"
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-xs font-semibold text-rose-400"
                >
                  Sign In / Create Account →
                </Link>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Mobile Bottom Navigation Bar (thumb friendly, <= 15% sticky height) */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-neutral-950/95 backdrop-blur-md border-t border-neutral-800 px-3 py-2 flex items-center justify-around text-[10px] font-medium text-neutral-400">
        <Link
          href="/"
          className={`flex flex-col items-center gap-1 ${path === '/' ? 'text-rose-400' : 'hover:text-white'}`}
        >
          <span className="text-xs">🏠</span>
          <span>Home</span>
        </Link>
        <Link
          href="/clips"
          className={`flex flex-col items-center gap-1 ${path.startsWith('/clips') ? 'text-rose-400' : 'hover:text-white'}`}
        >
          <Video className="w-4 h-4" />
          <span>Clips</span>
        </Link>
        <Link
          href="/search"
          className={`flex flex-col items-center gap-1 ${path === '/search' ? 'text-rose-400' : 'hover:text-white'}`}
        >
          <Search className="w-4 h-4" />
          <span>Search</span>
        </Link>
        <Link
          href={currentUser ? (currentUser.role === 'admin' ? '/admin' : currentUser.role === 'creator' ? '/creator' : '/dashboard') : '/login'}
          className={`flex flex-col items-center gap-1 ${path.startsWith('/dashboard') || path.startsWith('/creator') || path.startsWith('/admin') ? 'text-rose-400' : 'hover:text-white'}`}
        >
          <User className="w-4 h-4" />
          <span>{currentUser ? 'Account' : 'Login'}</span>
        </Link>
      </nav>
    </>
  );
};
