import React from 'react';
import { ShieldCheck } from 'lucide-react';
import { Link } from '../../router/Router';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full bg-neutral-950 border-t border-neutral-850 pt-16 pb-24 md:pb-16 text-neutral-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 mb-12">
          {/* Brand info */}
          <div className="col-span-2">
            <Link href="/" className="inline-block text-base font-extrabold text-white mb-3">
              JHONNY <span className="text-rose-500">AI</span>
            </Link>
            <p className="text-xs text-neutral-400 max-w-sm mb-4 leading-relaxed">
              Licensed short-form video clip platform. Discover, preview, and download permission-cleared video clips for TikTok, Instagram Reels, and YouTube Shorts.
            </p>
            <div className="flex items-center gap-2 text-[11px] text-emerald-400 font-mono">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>100% Permission & Rights Verified</span>
            </div>
          </div>

          {/* Column: Browse */}
          <div>
            <h4 className="font-semibold text-neutral-200 text-xs uppercase tracking-wider mb-3">
              Browse Clips
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link href="/clips?category=Gaming" className="hover:text-white transition-colors">
                  Gaming & Esports
                </Link>
              </li>
              <li>
                <Link href="/clips?category=Podcasts" className="hover:text-white transition-colors">
                  Podcasts & Interviews
                </Link>
              </li>
              <li>
                <Link href="/clips?category=Motivation" className="hover:text-white transition-colors">
                  Motivation & Discipline
                </Link>
              </li>
              <li>
                <Link href="/clips?category=Minecraft" className="hover:text-white transition-colors">
                  Minecraft Clips
                </Link>
              </li>
              <li>
                <Link href="/clips?category=AI" className="hover:text-white transition-colors">
                  AI & Technology
                </Link>
              </li>
            </ul>
          </div>

          {/* Column: Platform & Creators */}
          <div>
            <h4 className="font-semibold text-neutral-200 text-xs uppercase tracking-wider mb-3">
              Creators & Admin
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link href="/creator" className="hover:text-white transition-colors">
                  Creator Dashboard
                </Link>
              </li>
              <li>
                <Link href="/creator/content" className="hover:text-white transition-colors">
                  Content Management
                </Link>
              </li>
              <li>
                <Link href="/creator/earnings" className="hover:text-white transition-colors">
                  Revenue Share
                </Link>
              </li>
              <li>
                <Link href="/admin" className="hover:text-white transition-colors">
                  Admin & Moderation
                </Link>
              </li>
              <li>
                <Link href="/admin/reports" className="hover:text-white transition-colors">
                  Takedown Queue
                </Link>
              </li>
            </ul>
          </div>

          {/* Column: Legal & Rights */}
          <div>
            <h4 className="font-semibold text-neutral-200 text-xs uppercase tracking-wider mb-3">
              Trust & Legal
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link href="/copyright" className="hover:text-white transition-colors">
                  Copyright & DMCA
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-white transition-colors">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-white transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-white transition-colors">
                  Contact Support
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-neutral-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-neutral-500">
          <p>© {new Date().getFullYear()} JHONNY AI. All rights reserved. Prototype release.</p>
          <p>
            Phase 1 model: Ad-supported, free downloads, zero watermarks.
          </p>
        </div>
      </div>
    </footer>
  );
};
