import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string | number;
  change?: string;
  trend?: 'up' | 'down' | 'neutral';
  icon: LucideIcon;
  description?: string;
}

export const StatCard: React.FC<StatCardProps> = ({
  label,
  value,
  change,
  trend = 'neutral',
  icon: Icon,
  description
}) => {
  return (
    <div className="bg-neutral-900/70 border border-neutral-800 rounded-xl p-5 flex flex-col justify-between hover:border-neutral-700/80 transition-all">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-medium text-neutral-400">{label}</span>
        <div className="w-8 h-8 rounded-lg bg-neutral-800 flex items-center justify-center text-neutral-400 border border-neutral-700/60">
          <Icon className="w-4 h-4" />
        </div>
      </div>

      <div>
        <div className="text-2xl font-bold text-neutral-100 font-mono tabular-nums tracking-tight">
          {value}
        </div>

        {(change || description) && (
          <div className="flex items-center gap-2 mt-2 text-xs">
            {change && (
              <span
                className={`font-mono tabular-nums font-medium ${
                  trend === 'up'
                    ? 'text-emerald-400'
                    : trend === 'down'
                    ? 'text-rose-400'
                    : 'text-neutral-400'
                }`}
              >
                {change}
              </span>
            )}
            {description && <span className="text-neutral-500 truncate">{description}</span>}
          </div>
        )}
      </div>
    </div>
  );
};
