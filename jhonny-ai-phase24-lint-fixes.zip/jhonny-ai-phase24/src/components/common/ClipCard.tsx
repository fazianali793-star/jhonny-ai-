import React from 'react';
import { Play, Download, Bookmark, ShieldCheck, Sliders } from 'lucide-react';
import { Clip } from '../../types';
import { useApp } from '../../context/AppContext';
import { Link } from '../../router/Router';

interface ClipCardProps {
  clip: Clip;
  compact?: boolean;
}

export const ClipCard: React.FC<ClipCardProps> = ({ clip, compact = false }) => {
  const { openDownloadModal, openPreviewModal, openStudioModal, isClipSaved, toggleSaveClip } = useApp();
  const saved = isClipSaved(clip.id);

  const formatDownloads = (num: number) => {
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'k';
    }
    return num.toString();
  };

  return (
    <div className="group relative flex flex-col bg-neutral-900/70 rounded-xl border border-neutral-800/80 overflow-hidden hover:border-neutral-700 transition-all duration-200">
      {/* Thumbnail Container (Vertical 9:16 aspect ratio feel or compact) */}
      <div className="relative aspect-[9/14] w-full overflow-hidden bg-neutral-950">
        <img
          src={clip.thumbnail}
          alt={clip.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        />

        {/* Gradient Scrim for Legibility */}
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

        {/* Top Badges / Indicators */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
          {/* Duration Indicator */}
          <span className="font-mono text-xs px-2 py-0.5 rounded bg-black/60 backdrop-blur-md text-neutral-200 tabular-nums border border-white/10">
            {clip.durationFormatted}
          </span>

          {/* Licensed Indicator */}
          <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-300 bg-emerald-950/70 border border-emerald-500/30 px-2 py-0.5 rounded backdrop-blur-md">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            Licensed
          </span>
        </div>

        {/* Hover / Direct Play Overlay Button */}
        <button
          onClick={() => openPreviewModal(clip)}
          aria-label={`Preview ${clip.title}`}
          className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-white/90 text-neutral-950 flex items-center justify-center opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-all duration-200 shadow-xl hover:scale-110 active:scale-95"
        >
          <Play className="w-5 h-5 ml-0.5 fill-current" />
        </button>

        {/* Save/Favorite Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleSaveClip(clip.id);
          }}
          title={saved ? 'Remove from Saved' : 'Save clip'}
          className={`absolute bottom-3 right-3 p-2 rounded-lg backdrop-blur-md transition-all duration-150 ${
            saved
              ? 'bg-rose-500 text-white'
              : 'bg-black/60 text-neutral-300 hover:text-white hover:bg-black/80 border border-white/10'
          }`}
        >
          <Bookmark className={`w-4 h-4 ${saved ? 'fill-current' : ''}`} />
        </button>
      </div>

      {/* Card Body */}
      <div className="p-4 flex flex-col flex-1 justify-between gap-3">
        <div>
          {/* Unboxed Metadata (Zero-Pill Rule) */}
          <div className="flex items-center gap-2 text-xs text-neutral-400 mb-1.5 font-medium">
            <span className="text-neutral-300">{clip.category}</span>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span className="tabular-nums font-mono">{formatDownloads(clip.downloads)} dls</span>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span className="text-neutral-400">{clip.fps}fps</span>
          </div>

          {/* Title */}
          <Link
            href={`/clips/${clip.slug}`}
            className="font-medium text-sm text-neutral-100 hover:text-white line-clamp-2 leading-snug group-hover:text-rose-300 transition-colors"
          >
            {clip.title}
          </Link>
        </div>

        {/* Creator Info and Quick Download CTA */}
        <div className="pt-3 border-t border-neutral-800/80 flex items-center justify-between gap-2">
          {/* Creator Profile */}
          <div className="flex items-center gap-2 min-w-0">
            <img
              src={clip.creator.avatar}
              alt={clip.creator.name}
              referrerPolicy="no-referrer"
              className="w-6 h-6 rounded-full object-cover shrink-0 border border-neutral-700"
            />
            <span className="text-xs text-neutral-300 truncate font-normal">
              {clip.creator.name}
            </span>
          </div>

          {/* Download and Studio Edit Actions */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={(e) => {
                e.stopPropagation();
                openStudioModal(clip);
              }}
              title="Edit in Studio (Captions, Reframe, Hooks)"
              className="inline-flex items-center p-1.5 text-xs rounded-lg bg-neutral-900 text-neutral-300 hover:text-white hover:bg-neutral-800 border border-neutral-800 hover:border-neutral-700 transition-colors"
            >
              <Sliders className="w-3.5 h-3.5 text-rose-400" />
            </button>
            <button
              onClick={() => openDownloadModal(clip)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-neutral-800 text-neutral-100 hover:bg-neutral-700 active:bg-neutral-600 border border-neutral-700 hover:border-neutral-600 transition-all duration-150 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5 text-neutral-400" />
              <span>Download</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
