import React from 'react';
import { Sparkles, ExternalLink } from 'lucide-react';

interface AdPlacementProps {
  type: 'leaderboard' | 'sidebar' | 'infeed' | 'inline';
  className?: string;
}

export const AdPlacement: React.FC<AdPlacementProps> = ({ type, className = '' }) => {
  if (type === 'leaderboard') {
    return (
      <div className={`w-full my-6 p-4 rounded-xl border border-dashed border-neutral-800 bg-neutral-900/40 text-center relative overflow-hidden ${className}`}>
        <div className="absolute top-2 right-3 text-[10px] tracking-wider uppercase font-mono text-neutral-500">
          Advertisement · Prototype Slot (728×90)
        </div>
        <div className="max-w-2xl mx-auto py-2 flex flex-col sm:flex-row items-center justify-between gap-3 text-left">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-neutral-800 flex items-center justify-center shrink-0 border border-neutral-700">
              <Sparkles className="w-5 h-5 text-rose-400" />
            </div>
            <div>
              <p className="text-xs font-semibold text-neutral-200">
                StudioGear Pro · 4K Creator Monitor & Dynamic Mic
              </p>
              <p className="text-[11px] text-neutral-400">
                Official hardware partner for high-framerate short-form video editors.
              </p>
            </div>
          </div>
          <button
            onClick={() => alert('Prototype ad click: in production this links to verified advertiser network.')}
            className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-neutral-300 border border-neutral-700 whitespace-nowrap transition-colors"
          >
            Learn More
          </button>
        </div>
      </div>
    );
  }

  if (type === 'sidebar') {
    return (
      <div className={`p-4 rounded-xl border border-dashed border-neutral-800 bg-neutral-900/40 text-left ${className}`}>
        <div className="flex items-center justify-between text-[10px] uppercase font-mono text-neutral-500 mb-2">
          <span>Sponsored Ad</span>
          <span>300×250</span>
        </div>
        <div className="aspect-[4/3] rounded-lg bg-neutral-800/80 border border-neutral-700/60 flex flex-col justify-end p-3 relative overflow-hidden mb-2">
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-900/40 to-transparent" />
          <div className="relative z-10">
            <span className="text-[11px] font-semibold text-rose-300 block">VocalClear Suite</span>
            <span className="text-[10px] text-neutral-300">Clean AI noise removal plugin for podcasts</span>
          </div>
        </div>
        <p className="text-[11px] text-neutral-400 mb-2 leading-relaxed">
          Remove background hiss and optimize audio for vertical reels in 1 click.
        </p>
        <button
          onClick={() => alert('Prototype ad click: in production this links to partner site.')}
          className="w-full py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-neutral-300 flex items-center justify-center gap-1 border border-neutral-700"
        >
          <span>Visit Sponsor</span>
          <ExternalLink className="w-3 h-3 text-neutral-500" />
        </button>
      </div>
    );
  }

  // in-feed native card
  return (
    <div className={`flex flex-col bg-neutral-900/40 rounded-xl border border-dashed border-neutral-800 p-4 justify-between ${className}`}>
      <div>
        <div className="flex items-center justify-between text-[10px] uppercase font-mono text-neutral-500 mb-2">
          <span>Sponsored Recommendation</span>
        </div>
        <div className="aspect-[9/10] rounded-lg bg-neutral-800/60 border border-neutral-700/50 flex flex-col items-center justify-center p-4 text-center mb-3">
          <div className="w-10 h-10 rounded-full bg-rose-500/10 flex items-center justify-center mb-2">
            <Sparkles className="w-5 h-5 text-rose-400" />
          </div>
          <p className="text-xs font-semibold text-neutral-200 mb-1">StreamDeck Neo Studio</p>
          <p className="text-[11px] text-neutral-400">Streamline fast hotkey clipping and timeline scrub</p>
        </div>
      </div>
      <button
        onClick={() => alert('Prototype ad click: In-feed sponsored network.')}
        className="w-full py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-neutral-300 border border-neutral-700"
      >
        View Offer
      </button>
    </div>
  );
};
