import React from 'react';
import { ClipStatus } from '../../types';

interface StatusBadgeProps {
  status: ClipStatus;
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, className = '' }) => {
  switch (status) {
    case 'Published':
      return (
        <span className={`inline-flex items-center gap-1.5 text-xs font-medium text-emerald-400 ${className}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          Published
        </span>
      );
    case 'Processing':
      return (
        <span className={`inline-flex items-center gap-1.5 text-xs font-medium text-amber-400 ${className}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-spin" />
          Processing
        </span>
      );
    case 'Pending':
      return (
        <span className={`inline-flex items-center gap-1.5 text-xs font-medium text-sky-400 ${className}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-sky-500" />
          Pending Review
        </span>
      );
    case 'Disabled':
      return (
        <span className={`inline-flex items-center gap-1.5 text-xs font-medium text-neutral-400 ${className}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-neutral-500" />
          Disabled
        </span>
      );
    case 'Takedown':
      return (
        <span className={`inline-flex items-center gap-1.5 text-xs font-medium text-rose-400 ${className}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
          Takedown Notice
        </span>
      );
    default:
      return <span className="text-xs text-neutral-400">{status}</span>;
  }
};
