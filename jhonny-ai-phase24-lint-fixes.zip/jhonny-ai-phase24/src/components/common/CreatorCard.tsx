import React from 'react';
import { CheckCircle2, Video, Download } from 'lucide-react';
import { Creator } from '../../types';
import { Link } from '../../router/Router';

interface CreatorCardProps {
  creator: Creator;
}

export const CreatorCard: React.FC<CreatorCardProps> = ({ creator }) => {
  const formatNumber = (num: number) => {
    if (num >= 1000) return (num / 1000).toFixed(0) + 'k';
    return num.toString();
  };

  return (
    <div className="bg-neutral-900/60 rounded-xl border border-neutral-800 p-5 flex flex-col justify-between hover:border-neutral-700 transition-all">
      <div>
        <div className="flex items-center gap-3 mb-3">
          <img
            src={creator.avatar}
            alt={creator.name}
            referrerPolicy="no-referrer"
            className="w-12 h-12 rounded-full object-cover border border-neutral-700"
          />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <h4 className="font-semibold text-sm text-neutral-100 truncate">{creator.name}</h4>
              {creator.verified && (
                <CheckCircle2 className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              )}
            </div>
            <p className="text-xs text-neutral-400 font-mono truncate">{creator.handle}</p>
          </div>
        </div>

        <p className="text-xs text-neutral-300 line-clamp-2 leading-relaxed mb-4">
          {creator.bio}
        </p>
      </div>

      <div className="pt-3 border-t border-neutral-800/80 flex items-center justify-between">
        <div className="flex items-center gap-3 text-xs text-neutral-400 font-mono">
          <span className="flex items-center gap-1">
            <Video className="w-3.5 h-3.5 text-neutral-500" />
            <strong className="text-neutral-200 font-normal tabular-nums">{creator.totalClips}</strong> clips
          </span>
          <span className="flex items-center gap-1">
            <Download className="w-3.5 h-3.5 text-neutral-500" />
            <strong className="text-neutral-200 font-normal tabular-nums">{formatNumber(creator.totalDownloads)}</strong>
          </span>
        </div>

        <Link
          href={`/clips?creator=${encodeURIComponent(creator.id)}`}
          className="text-xs font-medium text-rose-400 hover:text-rose-300 transition-colors"
        >
          View clips →
        </Link>
      </div>
    </div>
  );
};
