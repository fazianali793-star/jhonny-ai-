import React from 'react';
import { LicenseStatus } from '../../types';

interface LicenseBadgeProps {
  status: LicenseStatus;
  className?: string;
}

export const LicenseBadge: React.FC<LicenseBadgeProps> = ({ status, className = '' }) => {
  switch (status) {
    case 'Active':
      return (
        <span className={`inline-flex items-center gap-1.5 text-xs font-medium text-emerald-400 ${className}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
          Active License
        </span>
      );
    case 'Expiring':
      return (
        <span className={`inline-flex items-center gap-1.5 text-xs font-medium text-amber-400 ${className}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
          Expiring Soon
        </span>
      );
    case 'Expired':
      return (
        <span className={`inline-flex items-center gap-1.5 text-xs font-medium text-neutral-400 ${className}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-neutral-600" />
          Expired
        </span>
      );
    case 'Pending Review':
      return (
        <span className={`inline-flex items-center gap-1.5 text-xs font-medium text-amber-300 ${className}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
          Pending Review
        </span>
      );
    case 'Revoked':
      return (
        <span className={`inline-flex items-center gap-1.5 text-xs font-medium text-rose-400 ${className}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
          Revoked
        </span>
      );
    default:
      return <span className="text-xs text-neutral-400">{status}</span>;
  }
};
