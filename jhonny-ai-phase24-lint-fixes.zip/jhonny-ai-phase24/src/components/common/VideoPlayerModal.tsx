import React, { useState, useEffect, useRef } from 'react';
import { X, Play, Pause, Volume2, VolumeX, RotateCcw, Download, ShieldCheck, Share2, Bookmark, Sliders } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const VideoPlayerModal: React.FC = () => {
  const { activePreviewClip, closePreviewModal, openDownloadModal, openStudioModal, toggleSaveClip, isClipSaved, addToast } = useApp();
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isLooping, setIsLooping] = useState<boolean>(true);
  const animationFrameRef = useRef<number | null>(null);

  const duration = activePreviewClip?.duration || 30;

  useEffect(() => {
    if (!activePreviewClip) {
      setCurrentTime(0);
      setIsPlaying(true);
      return;
    }

    let current = 0;

    const tick = (now: number) => {
      if (isPlaying) {
        current += 0.05;
        if (current >= duration) {
          if (isLooping) {
            current = 0;
          } else {
            current = duration;
            setIsPlaying(false);
          }
        }
        setCurrentTime(current);
      }
      animationFrameRef.current = requestAnimationFrame(tick);
    };

    animationFrameRef.current = requestAnimationFrame(tick);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [activePreviewClip, isPlaying, isLooping, duration]);

  if (!activePreviewClip) return null;

  const saved = isClipSaved(activePreviewClip.id);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCurrentTime(Number(e.target.value));
  };

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.origin + `/clips/${activePreviewClip.slug}`);
    addToast('Link Copied', 'Clip URL copied to clipboard.', 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="px-4 py-3 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <h3 className="font-semibold text-xs text-neutral-200 truncate">
              {activePreviewClip.title}
            </h3>
          </div>
          <button
            onClick={closePreviewModal}
            className="p-1 rounded-lg text-neutral-400 hover:text-neutral-100 hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Canvas / Player Area (9:16 vertical ratio) */}
        <div className="relative flex-1 bg-black flex items-center justify-center overflow-hidden min-h-[360px] sm:min-h-[460px]">
          {/* Background blurred ambiance */}
          <img
            src={activePreviewClip.thumbnail}
            alt=""
            className="absolute inset-0 w-full h-full object-cover blur-2xl opacity-20 scale-125"
          />

          {/* Central 9:16 Vertical Phone Display */}
          <div className="relative h-full aspect-[9/16] max-h-[500px] bg-neutral-950 rounded-xl overflow-hidden shadow-2xl border border-neutral-800/80 flex flex-col justify-between">
            <img
              src={activePreviewClip.thumbnail}
              alt={activePreviewClip.title}
              className="absolute inset-0 w-full h-full object-cover"
            />

            {/* Simulated Live Playing Audio Waves / Frame Counter */}
            {isPlaying && (
              <div className="absolute top-3 left-3 px-2 py-1 rounded bg-black/60 backdrop-blur-md text-[10px] font-mono text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                <span>60 FPS PREVIEW</span>
              </div>
            )}

            {/* Play / Pause tap backdrop */}
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="absolute inset-0 flex items-center justify-center group"
            >
              {!isPlaying && (
                <div className="w-14 h-14 rounded-full bg-white/90 text-neutral-950 flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform">
                  <Play className="w-6 h-6 ml-0.5 fill-current" />
                </div>
              )}
            </button>

            {/* Bottom Scrim for Controls */}
            <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-neutral-950 via-neutral-950/80 to-transparent pt-8">
              {/* Scrubber */}
              <div className="flex items-center gap-2 mb-2">
                <input
                  type="range"
                  min="0"
                  max={duration}
                  step="0.1"
                  value={currentTime}
                  onChange={handleSeek}
                  className="w-full h-1 bg-neutral-700 accent-rose-500 rounded-lg cursor-pointer"
                />
                <span className="text-[10px] font-mono text-neutral-300 tabular-nums shrink-0">
                  {formatTime(currentTime)} / {activePreviewClip.durationFormatted}
                </span>
              </div>

              {/* Player Bottom Bar */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="p-1.5 text-neutral-300 hover:text-white rounded"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
                  </button>
                  <button
                    onClick={() => setIsMuted(!isMuted)}
                    className="p-1.5 text-neutral-300 hover:text-white rounded"
                  >
                    {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => setIsLooping(!isLooping)}
                    title={isLooping ? 'Looping enabled' : 'Looping disabled'}
                    className={`p-1.5 rounded text-xs ${isLooping ? 'text-rose-400' : 'text-neutral-500'}`}
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => toggleSaveClip(activePreviewClip.id)}
                    className={`p-1.5 rounded transition-colors ${saved ? 'text-rose-400' : 'text-neutral-300 hover:text-white'}`}
                  >
                    <Bookmark className={`w-4 h-4 ${saved ? 'fill-current' : ''}`} />
                  </button>
                  <button
                    onClick={handleShare}
                    className="p-1.5 text-neutral-300 hover:text-white rounded"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer info & CTA */}
        <div className="p-4 bg-neutral-900 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-neutral-300">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Licensed for TikTok, Reels, Shorts</span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => {
                const clip = activePreviewClip;
                closePreviewModal();
                openStudioModal(clip);
              }}
              className="flex-1 sm:flex-initial px-3.5 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 border border-neutral-700 transition-all active:scale-95"
            >
              <Sliders className="w-3.5 h-3.5 text-rose-400" />
              <span>Edit in Studio</span>
            </button>

            <button
              onClick={() => {
                closePreviewModal();
                openDownloadModal(activePreviewClip);
              }}
              className="flex-1 sm:flex-initial px-4 py-2 rounded-lg bg-rose-500 hover:bg-rose-600 text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-md transition-all active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Free Download</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
