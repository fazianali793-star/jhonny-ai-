import React, { useState } from 'react';
import { X, AlertTriangle } from 'lucide-react';
import { CopyrightReport } from '../../types';
import { useApp } from '../../context/AppContext';

interface ReportDetailModalProps {
  report: CopyrightReport | null;
  onClose: () => void;
}

export const ReportDetailModal: React.FC<ReportDetailModalProps> = ({ report, onClose }) => {
  const { disableClipFromReport, updateReportStatus, addToast } = useApp();
  const [actionNotes, setActionNotes] = useState('');

  if (!report) return null;


  const handleDisableClip = () => {
    disableClipFromReport(report.id, report.clipId);
    onClose();
  };

  const handleResolve = () => {
    updateReportStatus(
      report.id,
      'Resolved',
      actionNotes || 'Rights dispute examined; resolved amicably with claimant.'
    );
    onClose();
  };

  const handleReject = () => {
    updateReportStatus(
      report.id,
      'Rejected',
      actionNotes || 'Claim rejected: Valid original creator license contract on file.'
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl p-6">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
              {report.id}
            </span>
            <h3 className="font-semibold text-sm text-neutral-100">Review Copyright Report</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 space-y-4">
          {/* Clip Context */}
          <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 text-xs">
            <span className="text-[10px] text-neutral-500 uppercase font-mono block mb-1">
              Target Content
            </span>
            <h4 className="font-medium text-neutral-200">{report.clipTitle}</h4>
            <p className="text-neutral-400 mt-1">Creator: {report.creatorName} · Clip ID: {report.clipId}</p>
          </div>

          {/* Reporter & Claim Details */}
          <div className="space-y-2 text-xs">
            <div className="flex justify-between border-b border-neutral-800/80 pb-2">
              <span className="text-neutral-400">Reporter</span>
              <span className="text-neutral-200 font-medium">
                {report.reporterName} {report.reporterOrg ? `(${report.reporterOrg})` : ''}
              </span>
            </div>
            <div className="flex justify-between border-b border-neutral-800/80 pb-2">
              <span className="text-neutral-400">Reporter Contact</span>
              <span className="text-neutral-200 font-mono">{report.reporterEmail}</span>
            </div>
            <div className="flex justify-between border-b border-neutral-800/80 pb-2">
              <span className="text-neutral-400">Claim Reason</span>
              <span className="text-rose-400 font-medium">{report.reason}</span>
            </div>
            <div className="flex justify-between border-b border-neutral-800/80 pb-2">
              <span className="text-neutral-400">Submitted</span>
              <span className="text-neutral-300 font-mono">
                {new Date(report.submittedAt).toLocaleDateString()}
              </span>
            </div>
          </div>

          <div>
            <span className="text-[11px] font-medium text-neutral-400 block mb-1">Claim Statement:</span>
            <p className="p-3 rounded-lg bg-neutral-950/60 border border-neutral-800 text-xs text-neutral-300 leading-relaxed italic">
              "{report.details}"
            </p>
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-400 mb-1">
              Resolution Audit Notes (Optional)
            </label>
            <input
              type="text"
              value={actionNotes}
              onChange={(e) => setActionNotes(e.target.value)}
              placeholder="e.g. Valid syndication grant confirmed with creator"
              className="w-full px-3 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-rose-500"
            />
          </div>
        </div>

        {/* Takedown & Moderation Action Buttons */}
        <div className="mt-6 pt-4 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-2">
          <button
            onClick={handleDisableClip}
            className="w-full sm:w-auto px-3.5 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Disable Clip (Takedown)</span>
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleReject}
              className="flex-1 sm:flex-none px-3.5 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-medium transition-colors"
            >
              Reject Claim
            </button>
            <button
              onClick={handleResolve}
              className="flex-1 sm:flex-none px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold transition-colors"
            >
              Mark Resolved
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
