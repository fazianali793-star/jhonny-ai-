import React, { useState } from 'react';
import { X, UploadCloud, ShieldAlert, Sparkles } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CATEGORIES } from '../../data/mockData';
import { ClipCategory, LicenseType } from '../../types';
import { uploadApi, getApiToken, ApiError } from '../../lib/api';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const MAX_FILE_BYTES = 250 * 1024 * 1024;
const ACCEPTED_EXTENSIONS = /\.(mp4|mov|webm)$/i;
const ACCEPTED_MIME_TYPES = ['video/mp4', 'video/quicktime', 'video/webm'];

interface VideoMedia {
  duration: number;
  width: number;
  height: number;
}

/** Reads duration and dimensions in the browser. The file itself is not uploaded in this build. */
function readVideoMetadata(file: File): Promise<VideoMedia> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const video = document.createElement('video');
    video.preload = 'metadata';
    const cleanup = () => {
      URL.revokeObjectURL(url);
      video.removeAttribute('src');
      video.load();
    };
    video.onloadedmetadata = () => {
      const result = { duration: video.duration, width: video.videoWidth, height: video.videoHeight };
      cleanup();
      resolve(result);
    };
    video.onerror = () => {
      cleanup();
      reject(new Error('This browser could not read the video. Try an MP4 (H.264) file.'));
    };
    video.src = url;
  });
}

export const UploadModal: React.FC<UploadModalProps> = ({ isOpen, onClose }) => {
  const { addClip, currentUser, openAiPipelineModal } = useApp();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<ClipCategory>('Gaming');
  const [tagsInput, setTagsInput] = useState('gaming, clip, highlights');
  const [sourceUrl, setSourceUrl] = useState('https://youtube.com/watch?v=');
  const [licenseType, setLicenseType] = useState<LicenseType>('Non-Exclusive');
  const [allowedPlatforms, setAllowedPlatforms] = useState<string[]>([
    'TikTok',
    'Instagram Reels',
    'YouTube Shorts'
  ]);
  const [hasConfirmedRights, setHasConfirmedRights] = useState(false);
  const [selectedFileName, setSelectedFileName] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [media, setMedia] = useState<VideoMedia | null>(null);
  const [isCheckingFile, setIsCheckingFile] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  /** Validates a chosen file and reads its real duration and dimensions. */
  const acceptFile = async (file: File) => {
    setErrorMsg(null);
    setSelectedFile(null);
    setMedia(null);
    setSelectedFileName(null);

    if (!ACCEPTED_MIME_TYPES.includes(file.type) && !ACCEPTED_EXTENSIONS.test(file.name)) {
      setErrorMsg('Unsupported file type. Choose an MP4, MOV or WebM video.');
      return;
    }
    if (file.size > MAX_FILE_BYTES) {
      setErrorMsg('This file is larger than 250 MB.');
      return;
    }

    setIsCheckingFile(true);
    try {
      const m = await readVideoMetadata(file);
      if (!Number.isFinite(m.duration) || m.duration <= 0) {
        throw new Error('The video has no readable duration.');
      }
      if (m.height <= m.width) {
        throw new Error(`Clips must be vertical (9:16). This video is ${m.width}×${m.height}.`);
      }
      setSelectedFile(file);
      setMedia(m);
      setSelectedFileName(file.name);
      if (!title) {
        setTitle(file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '));
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'The video could not be read.');
    } finally {
      setIsCheckingFile(false);
    }
  };

  const handleFileDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files && e.dataTransfer.files[0];
    if (file) void acceptFile(file);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files && e.target.files[0];
    if (file) void acceptFile(file);
  };

  const handlePlatformToggle = (platform: string) => {
    if (allowedPlatforms.includes(platform)) {
      setAllowedPlatforms(allowedPlatforms.filter(p => p !== platform));
    } else {
      setAllowedPlatforms([...allowedPlatforms, platform]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!title.trim()) {
      setErrorMsg('Please enter a title for the clip.');
      return;
    }
    if (!hasConfirmedRights) {
      setErrorMsg('You must certify that you own the rights or hold explicit license authorization.');
      return;
    }
    if (isCheckingFile) {
      setErrorMsg('Still reading the selected video. Try again in a moment.');
      return;
    }
    if (!selectedFile || !media) {
      setErrorMsg('Choose a readable, vertical (9:16) video file before submitting.');
      return;
    }

    if (!getApiToken()) {
      setErrorMsg('Please sign in with a real backend account. Demo sessions cannot upload files.');
      return;
    }
    setIsSubmitting(true);
    setUploadProgress(0);
    try {
      const result = await uploadApi(selectedFile, title.trim(), setUploadProgress);
      const duration = Math.max(1, Math.round(result.duration));
      const durationFormatted = `${Math.floor(duration / 60)}:${String(duration % 60).padStart(2, '0')}`;
      const tags = tagsInput.split(',').map(t => t.trim().toLowerCase()).filter(Boolean);
      const customThumb = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="540" height="960"><rect width="100%" height="100%" fill="%2318181b"/><text x="270" y="480" fill="white" text-anchor="middle">PENDING REVIEW</text></svg>`;
      addClip({
        id: result.id,
        title: title.trim(),
        description: description || 'Submitted for review. Publication requires verified rights approval.',
        category, tags, duration, durationFormatted, thumbnail: customThumb,
        status: 'Pending',
        creatorId: currentUser?.id || '',
        licenseInfo: {
          licenseId: `pending-${result.id}`, type: licenseType, status: 'Pending Review',
          sourceUrl: sourceUrl || '', allowedPlatforms, attributionRequired: false,
          expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString()
        }
      });
      onClose();
    } catch (err) {
      setErrorMsg(err instanceof ApiError ? err.message : 'Upload failed. No submission was reported as successful.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl p-6 my-8 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div>
            <h3 className="font-semibold text-base text-neutral-100">Upload Licensed Video Clip</h3>
            <p className="text-xs text-neutral-400">
              Submit short-form video for compliance clearance and social syndication
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* AI Auto-Clipping Ingestion Launcher */}
        <div className="mt-4 p-3.5 rounded-xl bg-gradient-to-r from-rose-500/10 via-neutral-900 to-neutral-900 border border-rose-500/25 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-rose-500/20 flex items-center justify-center text-rose-400 shrink-0 border border-rose-500/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-xs text-white block">Auto-generate clips from long videos?</span>
              <span className="text-[11px] text-neutral-400">Whisper transcription, viral moment detection, and auto-captions</span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              onClose();
              openAiPipelineModal();
            }}
            className="px-3.5 py-1.5 rounded-lg bg-rose-500 hover:bg-rose-600 text-white font-semibold text-xs whitespace-nowrap shadow-sm transition-all self-start sm:self-auto shrink-0"
          >
            Launch AI Pipeline →
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {errorMsg && (
            <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Drag & Drop File Selector */}
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleFileDrop}
            className="border-2 border-dashed border-neutral-700 hover:border-neutral-600 rounded-xl p-6 text-center bg-neutral-950/40 cursor-pointer transition-all"
          >
            <input
              type="file"
              accept="video/*"
              id="file-upload"
              onChange={handleFileSelect}
              className="hidden"
            />
            <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center">
              <div className="w-12 h-12 rounded-full bg-neutral-800 flex items-center justify-center text-rose-400 mb-3 border border-neutral-700">
                <UploadCloud className="w-6 h-6" />
              </div>
              <p className="text-xs font-semibold text-neutral-200 mb-1">
                {selectedFileName ? selectedFileName : 'Drag & drop your 9:16 vertical video here'}
              </p>
              <p className="text-[11px] text-neutral-400 font-mono">
                MP4, MOV, or WebM · 1080×1920 recommended · Max 250 MB
              </p>
              {isCheckingFile && <p className="text-[11px] text-neutral-300 mt-2">Reading video…</p>}
              {media && (
                <p className="text-[11px] text-emerald-400 font-mono mt-2">
                  {media.width}×{media.height} · {Math.round(media.duration)}s · checked locally, not uploaded
                </p>
              )}
            </label>
          </div>

          {/* Title & Description */}
          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1">Clip Title *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. 1v4 Clutch Reaction at Regional Finals"
              required
              className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-rose-500 transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1">Description</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief context on the moment and episode/game details..."
              className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-rose-500 transition-colors"
            />
          </div>

          {/* Category & Tags */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ClipCategory)}
                className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-100 focus:outline-none focus:border-rose-500"
              >
                {CATEGORIES.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">Tags (comma separated)</label>
              <input
                type="text"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                placeholder="clutch, gaming, esports"
                className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          {/* Rights & Source Information */}
          <div className="p-4 rounded-xl bg-neutral-950/60 border border-neutral-800 space-y-3">
            <h4 className="text-xs font-semibold text-neutral-200 uppercase tracking-wider font-mono">
              Licensing & Rights Information
            </h4>

            <div>
              <label className="block text-xs text-neutral-400 mb-1">Original Source Broadcast / Stream URL</label>
              <input
                type="url"
                value={sourceUrl}
                onChange={(e) => setSourceUrl(e.target.value)}
                placeholder="https://youtube.com/watch?v=... or https://twitch.tv/..."
                className="w-full px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-700 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-rose-500 font-mono"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-neutral-400 mb-1">License Scope</label>
                <select
                  value={licenseType}
                  onChange={(e) => setLicenseType(e.target.value as LicenseType)}
                  className="w-full px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-700 text-xs text-neutral-200 focus:outline-none focus:border-rose-500"
                >
                  <option value="Non-Exclusive">Non-Exclusive Syndication</option>
                  <option value="Exclusive">Exclusive to JHONNY AI</option>
                  <option value="Syndicate Partner">Verified Tournament Partner</option>
                  <option value="Creative Commons (CC-BY)">Creative Commons (CC-BY)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-neutral-400 mb-1">Allowed Social Platforms</label>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {['TikTok', 'Instagram Reels', 'YouTube Shorts', 'X'].map((plat) => (
                    <button
                      key={plat}
                      type="button"
                      onClick={() => handlePlatformToggle(plat)}
                      className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                        allowedPlatforms.includes(plat)
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          : 'bg-neutral-800 text-neutral-500 border border-neutral-700'
                      }`}
                    >
                      {plat}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Permission Checkbox */}
            <div className="pt-2 border-t border-neutral-800/80">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasConfirmedRights}
                  onChange={(e) => setHasConfirmedRights(e.target.checked)}
                  className="mt-0.5 rounded border-neutral-700 text-rose-500 focus:ring-0"
                />
                <span className="text-[11px] text-neutral-300 leading-snug">
                  <strong>I certify and warrant</strong> that I own the full copyright or hold explicit, valid syndication authorization to license this clip on JHONNY AI for third-party social media re-distribution.
                </span>
              </label>
            </div>
          </div>

          {isSubmitting && <div className="text-xs text-neutral-300" role="status">Uploading to JHONNY AI backend: {uploadProgress}%<div className="mt-2 h-1.5 bg-neutral-800 rounded-full overflow-hidden"><div className="h-full bg-rose-500 transition-all" style={{ width: `${uploadProgress}%` }} /></div></div>}

          {/* Form Actions */}
          <div className="pt-3 border-t border-neutral-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-neutral-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 rounded-lg bg-rose-500 hover:bg-rose-600 text-white text-xs font-semibold flex items-center gap-2 shadow-md transition-all active:scale-95"
            >
              {isSubmitting ? 'Uploading...' : 'Submit Clip for Review'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
