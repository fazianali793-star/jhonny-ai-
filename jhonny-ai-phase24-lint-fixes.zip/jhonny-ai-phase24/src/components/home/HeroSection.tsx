import React from 'react';
import { ArrowRight, ShieldCheck, Video, CheckCircle2 } from 'lucide-react';
import { Link } from '../../router/Router';

export const HeroSection: React.FC = () => {
  return (
    <section className="relative overflow-hidden pt-12 pb-16 lg:pt-20 lg:pb-24 border-b border-neutral-900 bg-radial-gradient">
      {/* Subtle atmospheric backdrop */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-5xl h-72 bg-rose-500/5 blur-3xl pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        {/* Quiet Kicker (Zero-Pill Rule: quiet unboxed text) */}
        <div className="inline-flex items-center gap-2 text-xs font-medium text-rose-400 mb-6">
          <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" />
          <span>Licensed Short-Form Video Syndication</span>
          <span aria-hidden="true" className="text-neutral-600">·</span>
          <span className="text-neutral-400">Zero Watermark Phase 1</span>
        </div>

        {/* Hero Title (Balanced, high visual hierarchy) */}
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white max-w-4xl mx-auto leading-tight text-balance mb-6">
          Ready-to-Post Clips for Your Channel
        </h1>

        {/* Supporting Copy */}
        <p className="text-base sm:text-lg text-neutral-300 max-w-2xl mx-auto mb-8 leading-relaxed">
          Discover high-impact, licensed short-form clips provided directly by creators and tournament partners. Preview in vertical 9:16 and download instantly for your social media channels.
        </p>

        {/* Primary CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 max-w-md mx-auto mb-12">
          <Link
            href="/clips"
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg shadow-rose-950 transition-all active:scale-95"
          >
            <span>Browse Clips</span>
            <ArrowRight className="w-4 h-4" />
          </Link>

          <Link
            href="/creator"
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-200 border border-neutral-800 hover:border-neutral-700 font-semibold text-sm flex items-center justify-center gap-2 transition-all"
          >
            <span>Become a Creator</span>
          </Link>
        </div>

        {/* Trust Markers Bar */}
        <div className="pt-8 border-t border-neutral-900 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto text-left">
          <div className="flex items-center gap-2 text-xs text-neutral-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>100% Free Downloads</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-neutral-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>No Watermark</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-neutral-300">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Permission-Cleared Rights</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-neutral-300">
            <Video className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>1080×1920 60 FPS Master</span>
          </div>
        </div>
      </div>
    </section>
  );
};
