import React from 'react';
import { Search, Play, Download, Share2 } from 'lucide-react';

export const HowItWorksSection: React.FC = () => {
  const steps = [
    {
      num: '01',
      title: 'Browse',
      desc: 'Explore permission-cleared clips across gaming, podcasts, and sports.',
      icon: Search
    },
    {
      num: '02',
      title: 'Preview',
      desc: 'Watch instant vertical previews in full 60 FPS resolution.',
      icon: Play
    },
    {
      num: '03',
      title: 'Download',
      desc: 'Export watermark-free MP4s with clean syndication licenses.',
      icon: Download
    },
    {
      num: '04',
      title: 'Post',
      desc: 'Publish directly to TikTok, Instagram Reels, and YouTube Shorts.',
      icon: Share2
    }
  ];

  return (
    <section className="py-16 border-b border-neutral-900 bg-neutral-950/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-semibold text-rose-400 uppercase tracking-wider font-mono">
            Syndication Workflow
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight mt-1 mb-3">
            How JHONNY AI Works
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
            A frictionless pipeline engineered for creators who want viral, authorized content without copyright strikes or manual DMCA risk.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step) => {
            const Icon = step.icon;
            return (
              <div
                key={step.num}
                className="relative bg-neutral-900/40 rounded-xl border border-neutral-800 p-6 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="font-mono text-xs font-bold text-neutral-500">
                      {step.num}
                    </span>
                    <div className="w-8 h-8 rounded-lg bg-neutral-800 flex items-center justify-center text-rose-400 border border-neutral-700/60">
                      <Icon className="w-4 h-4" />
                    </div>
                  </div>
                  <h3 className="font-semibold text-sm text-neutral-100 mb-2">
                    {step.title}
                  </h3>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    {step.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
