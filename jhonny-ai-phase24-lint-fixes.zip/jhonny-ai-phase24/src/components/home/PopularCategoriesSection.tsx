import React from 'react';
import { CATEGORIES } from '../../data/mockData';
import { Link } from '../../router/Router';
import { Gamepad2, Box, Mic, Flame, Laugh, Eye, Trophy, Cpu, Film } from 'lucide-react';
import { ClipCategory } from '../../types';

const CATEGORY_ICONS: Record<ClipCategory, React.ElementType> = {
  Gaming: Gamepad2,
  Minecraft: Box,
  Podcasts: Mic,
  Motivation: Flame,
  Comedy: Laugh,
  Reactions: Eye,
  Sports: Trophy,
  AI: Cpu,
  Entertainment: Film
};

export const PopularCategoriesSection: React.FC = () => {
  return (
    <section className="py-12 border-b border-neutral-900 bg-neutral-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">Popular Categories</h2>
            <p className="text-xs text-neutral-400 mt-1">
              Curated short-form clips organized by niche and syndication theme
            </p>
          </div>
          <Link
            href="/clips"
            className="text-xs font-medium text-rose-400 hover:text-rose-300 transition-colors"
          >
            All categories →
          </Link>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-2.5">
          {CATEGORIES.map(category => {
            const Icon = CATEGORY_ICONS[category] || Film;
            return (
              <Link
                key={category}
                href={`/clips?category=${encodeURIComponent(category)}`}
                className="group p-3 rounded-xl bg-neutral-900/60 border border-neutral-800/80 hover:border-neutral-700 flex flex-col items-center text-center transition-all hover:-translate-y-0.5"
              >
                <div className="w-8 h-8 rounded-lg bg-neutral-800 flex items-center justify-center text-neutral-400 group-hover:text-rose-400 group-hover:bg-neutral-800/80 transition-colors mb-2 border border-neutral-700/60">
                  <Icon className="w-4 h-4" />
                </div>
                <span className="text-xs font-medium text-neutral-200 group-hover:text-white truncate w-full">
                  {category}
                </span>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
};
