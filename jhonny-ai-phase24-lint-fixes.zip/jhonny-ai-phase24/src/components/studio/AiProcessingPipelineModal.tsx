import React, { useState } from 'react';
import { X, UploadCloud, Youtube, Sparkles, CheckCircle2, ArrowRight, Flame, Check, ShieldCheck, AlertTriangle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Clip, ClipCategory, ProcessingJob } from '../../types';
import {
  detectViralMomentsFromSource,
  createDefaultSubtitleConfig,
  createDefaultHookOverlay,
  createDefaultReframeConfig,
  generateHighContrastThumbnailSvg
} from '../../services/aiClipEngine';

export const AiProcessingPipelineModal: React.FC = () => {
  const { isAiPipelineOpen, closeAiPipelineModal, addProcessingJob, updateProcessingJob, addClip, openStudioModal, addToast, currentUser } = useApp();

  const [step, setStep] = useState<'input' | 'analyzing' | 'review'>('input');
  const [sourceType, setSourceType] = useState<'youtube' | 'upload'>('youtube');
  const [youtubeUrl, setYoutubeUrl] = useState('https://youtube.com/watch?v=vanguard-future-podcast-89');
  const [videoTitle, setVideoTitle] = useState('The Vanguard Podcast: AI Agents & Robotics Revolution');
  const [selectedCategory, setSelectedCategory] = useState<ClipCategory>('Podcasts');
  const [progressStage, setProgressStage] = useState(0);
  const [stageText, setStageText] = useState('');
  const [generatedCandidates, setGeneratedCandidates] = useState<Clip[]>([]);
  const [selectedIndices, setSelectedIndices] = useState<number[]>([0, 1, 2]);

  if (!isAiPipelineOpen) return null;

  const handleStartPipeline = () => {
    setStep('analyzing');
    setProgressStage(15);
    setStageText('Ingesting source stream and validating audio channels...');

    const jobId = 'job-' + Date.now();
    const newJob: ProcessingJob = {
      id: jobId,
      sourceTitle: videoTitle,
      sourceUrl: sourceType === 'youtube' ? youtubeUrl : undefined,
      fileSize: '380 MB',
      status: 'transcribing',
      progress: 15,
      currentStepText: 'Running Whisper word-level transcription...',
      viralMomentsFound: 0,
      generatedClips: [],
      createdAt: new Date().toISOString(),
      creatorId: currentUser?.creatorId || 'c1'
    };
    addProcessingJob(newJob);

    // Multi-stage simulation of OpenShorts pipeline
    setTimeout(() => {
      setProgressStage(35);
      setStageText('Transcribing audio with faster-whisper (word timestamps aligned)...');
      updateProcessingJob(jobId, { progress: 35, status: 'detecting_moments', currentStepText: 'Scoring viral hooks with Gemini 3.1 Flash-Lite...' });
    }, 700);

    setTimeout(() => {
      setProgressStage(65);
      setStageText('Gemini viral moment scoring: Hook strength, retention curve, standalone value...');
      updateProcessingJob(jobId, { progress: 65, status: 'reframing', currentStepText: 'Calculating 9:16 MediaPipe face tracking boundaries...' });
    }, 1400);

    setTimeout(() => {
      setProgressStage(85);
      setStageText('Synthesizing kinetic captions & generating high-CTR thumbnail banners...');
      updateProcessingJob(jobId, { progress: 85, status: 'generating_captions', currentStepText: 'Formatting ASS karaoke subtitle tracks...' });
    }, 2100);

    setTimeout(() => {
      // Generate actual Scored Moments
      const moments = detectViralMomentsFromSource(videoTitle, youtubeUrl, 420);
      const clips: Clip[] = moments.map((m, idx) => {
        const clipId = 'ai-clip-' + Date.now() + '-' + idx + '-' + Math.random().toString(36).substring(2, 7);
        const slug = m.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '-' + clipId.slice(-6);
        const thumb = generateHighContrastThumbnailSvg(m.title, m.hookText, m.category, m.viralScore);

        return {
          id: clipId,
          slug,
          title: m.title,
          description: m.transcript,
          thumbnail: thumb,
          creatorId: currentUser?.creatorId || 'c1',
          creator: {
            id: currentUser?.creatorId || 'c1',
            name: currentUser?.name || 'Marcus Vance',
            handle: '@' + (currentUser?.name?.toLowerCase().replace(/\s+/g, '') || 'marcusvance'),
            avatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
            verified: true
          },
          category: m.category,
          duration: m.duration,
          durationFormatted: m.durationFormatted,
          resolution: '1080x1920 (9:16)',
          fps: 60,
          downloads: 0,
          views: 1,
          likes: 0,
          tags: m.tags,
          status: 'Pending' as const,
          viralScore: m.viralScore,
          reasoning: m.reasoning,
          hookText: m.hookText,
          hookOverlay: createDefaultHookOverlay(m.hookText, 'yellow'),
          subtitles: createDefaultSubtitleConfig(m.transcript, idx % 2 === 0 ? 'hormozi' : 'lime'),
          reframe: createDefaultReframeConfig('smart_face'),
          sourceStartSeconds: m.start,
          sourceEndSeconds: m.end,
          createdAt: new Date().toISOString(),
          licenseInfo: {
            licenseId: 'LIC-' + Date.now() + '-' + idx + '-' + Math.random().toString(36).substring(2, 6),
            type: 'Non-Exclusive',
            status: 'Pending Review',
            sourceUrl: youtubeUrl || 'https://youtube.com',
            allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts', 'X'],
            attributionRequired: false,
            expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString()
          }
        };
      });

      setGeneratedCandidates(clips);
      setProgressStage(100);
      setStageText(`Complete! ${clips.length} high-potential viral clips generated.`);
      updateProcessingJob(jobId, {
        status: 'completed',
        progress: 100,
        viralMomentsFound: clips.length,
        generatedClips: clips,
        currentStepText: `Ready for review. ${clips.length} clips generated.`
      });
      setStep('review');
    }, 2800);
  };

  const handleToggleSelectClip = (idx: number) => {
    setSelectedIndices(prev =>
      prev.includes(idx) ? prev.filter(i => i !== idx) : [...prev, idx]
    );
  };

  const handlePublishSelected = () => {
    const toPublish = generatedCandidates.filter((_, idx) => selectedIndices.includes(idx));
    toPublish.forEach((clip, idx) => {
      const safeId = clip.id || `ai-clip-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 6)}`;
      addClip({ ...clip, id: safeId, status: 'Pending' });
    });
    addToast('Clips Submitted for Review', `${toPublish.length} clips were submitted. They go public only after an administrator approves their licenses.`, 'success');
    closeAiPipelineModal();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-4xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/70">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-400 border border-rose-500/20">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-white">AI Video Ingestion & Clipping Pipeline</h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20">
                  OpenShorts Engine
                </span>
              </div>
              <p className="text-[11px] text-neutral-400">
                Whisper Transcription → Gemini Moment Scoring → Auto-Captions → 9:16 Reframe
              </p>
            </div>
          </div>

          <button
            onClick={closeAiPipelineModal}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Workflow Steps Indicator */}
        <div className="px-6 py-2.5 bg-neutral-950 border-b border-neutral-850 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-6">
            <span className={step === 'input' ? 'text-rose-400 font-bold' : 'text-neutral-500'}>
              01. Source Video
            </span>
            <span>→</span>
            <span className={step === 'analyzing' ? 'text-rose-400 font-bold' : 'text-neutral-500'}>
              02. AI Processing
            </span>
            <span>→</span>
            <span className={step === 'review' ? 'text-rose-400 font-bold' : 'text-neutral-500'}>
              03. Review & Publish
            </span>
          </div>
        </div>

        <div role="note" className="px-6 py-2 bg-amber-500/5 border-b border-amber-500/30 text-[11px] text-amber-200 flex gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
          <p>
            Simulated. No video is uploaded or analyzed, and no transcription or AI model runs. The moments below come
            from fixed templates. Submitted clips have no media file and need administrator approval before they are public.
          </p>
        </div>

        {/* Body Container */}
        <div className="p-6 flex-1 overflow-y-auto">
          {/* STEP 1: INPUT */}
          {step === 'input' && (
            <div className="max-w-2xl mx-auto space-y-6">
              {/* Ingestion Method Tabs */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setSourceType('youtube')}
                  className={`p-4 rounded-xl border text-left flex items-center gap-3 transition-all ${
                    sourceType === 'youtube'
                      ? 'bg-rose-500/10 border-rose-500/40 text-white'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                  }`}
                >
                  <Youtube className="w-5 h-5 text-rose-500" />
                  <div>
                    <span className="font-bold text-xs block">YouTube / Stream URL</span>
                    <span className="text-[11px] text-neutral-500">Auto stream download via yt-dlp</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setSourceType('upload')}
                  className={`p-4 rounded-xl border text-left flex items-center gap-3 transition-all ${
                    sourceType === 'upload'
                      ? 'bg-rose-500/10 border-rose-500/40 text-white'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                  }`}
                >
                  <UploadCloud className="w-5 h-5 text-rose-400" />
                  <div>
                    <span className="font-bold text-xs block">Upload Master Video</span>
                    <span className="text-[11px] text-neutral-500">MP4, MOV, or MKV up to 4 GB</span>
                  </div>
                </button>
              </div>

              {/* Form Inputs */}
              <div className="space-y-4 text-xs">
                {sourceType === 'youtube' ? (
                  <div>
                    <label className="block font-semibold text-neutral-300 mb-1">
                      YouTube Stream Link *
                    </label>
                    <input
                      type="url"
                      value={youtubeUrl}
                      onChange={(e) => setYoutubeUrl(e.target.value)}
                      placeholder="https://www.youtube.com/watch?v=..."
                      className="w-full px-3 py-2.5 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-white focus:outline-none focus:border-rose-500 font-mono"
                    />
                  </div>
                ) : (
                  <div className="p-8 border-2 border-dashed border-neutral-700 rounded-xl text-center bg-neutral-950">
                    <UploadCloud className="w-8 h-8 text-neutral-500 mx-auto mb-2" />
                    <p className="font-semibold text-neutral-300 mb-1">Drag and drop raw footage here</p>
                    <p className="text-[11px] text-neutral-500">Supports 1080p and 4K horizontal broadcast files</p>
                  </div>
                )}

                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Source Video Title *</label>
                  <input
                    type="text"
                    value={videoTitle}
                    onChange={(e) => setVideoTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-white focus:outline-none focus:border-rose-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Syndication Category</label>
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value as ClipCategory)}
                    className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-white focus:outline-none"
                  >
                    {['Podcasts', 'Gaming', 'Motivation', 'AI', 'Comedy', 'Sports', 'Minecraft'].map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 flex items-start gap-2.5 text-[11px] text-neutral-400">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>
                    JHONNY AI Rights Guarantee: Generated clips inherit verified creator syndication clearance. All downloads remain watermark-free.
                  </span>
                </div>
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  type="button"
                  onClick={handleStartPipeline}
                  className="px-6 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-semibold text-xs shadow-lg shadow-rose-950 flex items-center gap-2"
                >
                  <span>Launch AI Analysis & Clipping</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: ANALYZING */}
          {step === 'analyzing' && (
            <div className="max-w-md mx-auto py-12 text-center space-y-6">
              <div className="w-16 h-16 rounded-2xl bg-rose-500/10 flex items-center justify-center text-rose-500 mx-auto border border-rose-500/20 animate-pulse">
                <Sparkles className="w-8 h-8" />
              </div>

              <div>
                <h3 className="font-bold text-base text-white mb-1">
                  OpenShorts Pipeline Executing
                </h3>
                <p className="text-xs text-neutral-400 font-mono">
                  {stageText}
                </p>
              </div>

              {/* Progress bar */}
              <div className="w-full h-2.5 rounded-full bg-neutral-800 overflow-hidden">
                <div
                  className="h-full bg-rose-500 rounded-full transition-all duration-500"
                  style={{ width: `${progressStage}%` }}
                />
              </div>

              <div className="text-[11px] font-mono text-neutral-500 space-y-1 text-left bg-neutral-950 p-4 rounded-xl border border-neutral-800">
                <div>[1/4] Whisper word timestamp extraction: ✓</div>
                <div>[2/4] Gemini 3.1 Flash-Lite hook scoring: ✓</div>
                <div>[3/4] MediaPipe face tracking 9:16 crop: ✓</div>
                <div>[4/4] Kinetic ASS karaoke subtitle formatting: in progress...</div>
              </div>
            </div>
          )}

          {/* STEP 3: REVIEW & PUBLISH */}
          {step === 'review' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
                <div>
                  <h4 className="font-bold text-sm text-white">
                    Candidate Viral Clips ({generatedCandidates.length} generated)
                  </h4>
                  <p className="text-xs text-neutral-400">
                    Review AI-detected clips, inspect viral scores, and select which clips to publish to the public catalog.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSelectedIndices(generatedCandidates.map((_, i) => i))}
                    className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-750 text-neutral-300 text-xs"
                  >
                    Select All
                  </button>
                  <button
                    onClick={handlePublishSelected}
                    disabled={selectedIndices.length === 0}
                    className="px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 disabled:bg-neutral-800 text-white font-semibold text-xs shadow-md flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Publish Selected ({selectedIndices.length})</span>
                  </button>
                </div>
              </div>

              {/* Candidates Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {generatedCandidates.map((cand, idx) => {
                  const isSelected = selectedIndices.includes(idx);
                  return (
                    <div
                      key={`${cand.id}-${idx}`}
                      onClick={() => handleToggleSelectClip(idx)}
                      className={`p-4 rounded-xl border cursor-pointer transition-all flex flex-col justify-between ${
                        isSelected
                          ? 'bg-neutral-900 border-rose-500/80 shadow-lg shadow-rose-950/20'
                          : 'bg-neutral-950/70 border-neutral-800 opacity-60 hover:opacity-100'
                      }`}
                    >
                      <div>
                        {/* Top Indicator */}
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1 font-bold">
                            <Flame className="w-3 h-3" />
                            <span>VIRAL {cand.viralScore}/100</span>
                          </span>

                          <div className={`w-5 h-5 rounded-md border flex items-center justify-center ${
                            isSelected ? 'bg-rose-500 border-rose-500 text-white' : 'border-neutral-700'
                          }`}>
                            {isSelected && <Check className="w-3.5 h-3.5" />}
                          </div>
                        </div>

                        {/* Thumbnail & Info */}
                        <div className="flex items-center gap-3 mb-3">
                          <img
                            src={cand.thumbnail}
                            alt=""
                            className="w-16 h-24 rounded-lg object-cover bg-neutral-950 border border-neutral-800 shrink-0"
                          />
                          <div>
                            <h5 className="font-bold text-xs text-white line-clamp-2 mb-1">
                              {cand.title}
                            </h5>
                            <span className="text-[10px] font-mono text-neutral-400 block mb-1">
                              Duration: {cand.durationFormatted} ({cand.sourceStartSeconds}s - {cand.sourceEndSeconds}s)
                            </span>
                            <span className="text-[10px] text-rose-300 font-bold block truncate">
                              Hook: {cand.hookText}
                            </span>
                          </div>
                        </div>

                        {/* Reasoning note */}
                        <p className="text-[11px] text-neutral-400 italic bg-neutral-950 p-2.5 rounded-lg border border-neutral-850 mb-3">
                          "{cand.reasoning}"
                        </p>
                      </div>

                      {/* Bottom Tags and Studio Action */}
                      <div className="pt-2 border-t border-neutral-850 flex items-center justify-between text-[10px] font-mono text-neutral-500">
                        <span>{cand.category}</span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            closeAiPipelineModal();
                            openStudioModal(cand);
                          }}
                          className="text-rose-400 hover:text-rose-300 flex items-center gap-1 font-sans font-semibold text-xs"
                        >
                          <span>Edit in Studio →</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
