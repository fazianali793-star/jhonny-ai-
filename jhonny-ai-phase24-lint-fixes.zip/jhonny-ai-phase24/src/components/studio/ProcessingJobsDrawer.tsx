import React from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const ProcessingJobsDrawer: React.FC = () => {
  const { processingJobs, openAiPipelineModal, publishJobClips } = useApp();

  if (processingJobs.length === 0) return null;

  return (
    <div className="bg-neutral-900/60 rounded-xl border border-neutral-800 p-5 mb-8">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-500 border border-rose-500/20">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-white">AI Processing Jobs & Ingestion</h3>
            <p className="text-xs text-neutral-400">OpenShorts background clipping & transcription tasks</p>
          </div>
        </div>

        <button
          onClick={openAiPipelineModal}
          className="text-xs font-semibold text-rose-400 hover:text-rose-300 flex items-center gap-1"
        >
          <span>New AI Ingestion Job</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="space-y-3">
        {processingJobs.slice(0, 3).map((job, idx) => {
          const isComplete = job.status === 'completed';

          return (
            <div
              key={`${job.id}-${idx}`}
              className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-850 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-mono text-[10px] text-neutral-400">{job.id}</span>
                  <span className="font-bold text-neutral-200 truncate max-w-sm">{job.sourceTitle}</span>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                    isComplete
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                  }`}>
                    {job.status.toUpperCase()}
                  </span>
                </div>
                <p className="text-[11px] text-neutral-400 font-mono">
                  {job.currentStepText}
                </p>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                {!isComplete && (
                  <div className="w-28 text-right font-mono text-[11px] text-neutral-400">
                    <span>{job.progress}%</span>
                    <div className="w-full h-1.5 rounded-full bg-neutral-800 overflow-hidden mt-1">
                      <div className="h-full bg-rose-500 rounded-full" style={{ width: `${job.progress}%` }} />
                    </div>
                  </div>
                )}

                {isComplete && job.generatedClips && job.generatedClips.length > 0 && (
                  <button
                    onClick={() => publishJobClips(job.id)}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs"
                  >
                    Publish {job.generatedClips.length} Clips
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
