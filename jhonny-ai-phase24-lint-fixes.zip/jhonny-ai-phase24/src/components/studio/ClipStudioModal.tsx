import React, { useState, useEffect, useRef } from 'react';
import { X, Play, Pause, RotateCcw, Volume2, VolumeX, Scissors, Type, Sparkles, Download, AlertTriangle, Image as ImageIcon, Flame, Code2 } from 'lucide-react';
import { SubtitleConfig, HookOverlay, ReframeConfig, SubtitleStylePreset, HookStyle } from '../../types';
import { useApp } from '../../context/AppContext';
import {
  SUBTITLE_PRESETS,
  HOOK_STYLES,
  createDefaultSubtitleConfig,
  createDefaultHookOverlay,
  createDefaultReframeConfig,
  buildFFmpegRenderCommand,
  generateHighContrastThumbnailSvg,
  generateAiTitlesAndDescriptions,
  getSimulatedFaceBox,
  generateWordTimestamps,
  ThumbnailTheme,
  AiTitleOption
} from '../../services/aiClipEngine';

export const ClipStudioModal: React.FC = () => {
  const { activeStudioClip, closeStudioModal, updateClipCustomization, addToast } = useApp();

  // Local editor states initialized from active clip or OpenShorts defaults
  const [activeTab, setActiveTab] = useState<'captions' | 'hook' | 'reframe' | 'thumbnail' | 'ai_copy' | 'export'>('captions');
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isLooping, setIsLooping] = useState(true);

  // Studio custom parameters
  const [subtitles, setSubtitles] = useState<SubtitleConfig | null>(null);
  const [hookOverlay, setHookOverlay] = useState<HookOverlay | null>(null);
  const [reframe, setReframe] = useState<ReframeConfig | null>(null);
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(30);
  const [customTitle, setCustomTitle] = useState('');
  const [customThumbnail, setCustomThumbnail] = useState('');
  const [thumbnailTheme, setThumbnailTheme] = useState<ThumbnailTheme>('category');
  const [showSafeZone, setShowSafeZone] = useState(false);
  const [transcriptEditorText, setTranscriptEditorText] = useState('');
  const [aiTitleOptions, setAiTitleOptions] = useState<AiTitleOption[]>([]);

  const animRef = useRef<number | null>(null);

  useEffect(() => {
    if (!activeStudioClip) return;

    setCustomTitle(activeStudioClip.title);
    setCustomThumbnail(activeStudioClip.thumbnail);
    setTrimStart(0);
    setTrimEnd(activeStudioClip.duration || 30);
    setCurrentTime(0);
    setIsPlaying(true);

    // Initialize or load OpenShorts configurations
    const initSubs = activeStudioClip.subtitles || createDefaultSubtitleConfig(
      activeStudioClip.description || activeStudioClip.title,
      'hormozi'
    );
    setSubtitles(initSubs);
    setTranscriptEditorText(initSubs.words.map(w => w.word).join(' '));

    const initHook = activeStudioClip.hookOverlay || createDefaultHookOverlay(
      activeStudioClip.hookText || activeStudioClip.title.slice(0, 32),
      'yellow'
    );
    setHookOverlay(initHook);

    const initReframe = activeStudioClip.reframe || createDefaultReframeConfig('smart_face');
    setReframe(initReframe);

    // Generate OpenShorts AI title and description candidates
    const aiOpts = generateAiTitlesAndDescriptions(
      initSubs.words.map(w => w.word).join(' ') || activeStudioClip.title,
      activeStudioClip.category
    );
    setAiTitleOptions(aiOpts);
  }, [activeStudioClip]);

  // Live video simulation timeline playback
  useEffect(() => {
    if (!activeStudioClip || !isPlaying) return;

    const tick = () => {
      setCurrentTime(prev => {
        const next = prev + 0.05;
        if (next >= trimEnd) {
          if (isLooping) return trimStart;
          setIsPlaying(false);
          return trimEnd;
        }
        return next;
      });
      animRef.current = requestAnimationFrame(tick);
    };

    animRef.current = requestAnimationFrame(tick);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [isPlaying, isLooping, trimStart, trimEnd, activeStudioClip]);

  if (!activeStudioClip) return null;

  // Active Word Detection for Karaoke / Word highlighting
  const currentWord = subtitles?.words.find(w => currentTime >= w.start && currentTime <= w.end);
  const faceBox = getSimulatedFaceBox(currentTime, reframe?.horizontalOffset || 0);

  const handleSaveCustomization = () => {
    if (!activeStudioClip) return;
    updateClipCustomization(activeStudioClip.id, {
      title: customTitle,
      thumbnail: customThumbnail,
      duration: Math.max(5, Math.round(trimEnd - trimStart)),
      durationFormatted: `0:${Math.round(trimEnd - trimStart).toString().padStart(2, '0')}`,
      subtitles: subtitles || undefined,
      hookOverlay: hookOverlay || undefined,
      reframe: reframe || undefined
    });
  };

  const handlePresetSelect = (presetKey: SubtitleStylePreset) => {
    if (!subtitles) return;
    const base = SUBTITLE_PRESETS[presetKey];
    setSubtitles({
      ...subtitles,
      preset: presetKey,
      font: base.font,
      fontSize: base.fontSize,
      primaryColor: base.primaryColor,
      highlightColor: base.highlightColor,
      uppercase: base.uppercase,
      animation: base.animation,
      position: base.position
    });
  };

  const handleRecalculateCaptions = (newText: string) => {
    setTranscriptEditorText(newText);
    if (!subtitles) return;
    const duration = Math.max(5, trimEnd - trimStart);
    const newWords = generateWordTimestamps(newText, trimStart, duration);
    setSubtitles({
      ...subtitles,
      words: newWords
    });
    addToast('Captions Aligned', `Updated word-level timestamps (${newWords.length} tokens).`, 'success');
  };

  const handleApplyAiTitle = (opt: AiTitleOption) => {
    setCustomTitle(opt.title);
    if (hookOverlay) {
      setHookOverlay({ ...hookOverlay, text: opt.hook });
    }
    const newThumb = generateHighContrastThumbnailSvg(
      opt.title,
      opt.hook,
      activeStudioClip.category,
      activeStudioClip.viralScore || 94,
      thumbnailTheme
    );
    setCustomThumbnail(newThumb);
    addToast('AI Title & Hook Applied', `Configured "${opt.title}" with estimated ${opt.estimatedCtr}.`, 'success');
  };

  const handleRegenerateThumbnail = (themeToUse?: ThumbnailTheme) => {
    const targetTheme = themeToUse || thumbnailTheme;
    const newThumb = generateHighContrastThumbnailSvg(
      customTitle,
      hookOverlay?.text || 'MUST WATCH MOMENT',
      activeStudioClip.category,
      activeStudioClip.viralScore || 92,
      targetTheme
    );
    setCustomThumbnail(newThumb);
    if (themeToUse) setThumbnailTheme(themeToUse);
    addToast('Thumbnail Updated', 'Generated high-CTR title banner thumbnail.', 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-5xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl flex flex-col max-h-[95vh] overflow-hidden">
        {/* Top Studio Bar */}
        <div className="px-5 py-3 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/70">
          <div className="flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-white">Clip Studio</h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20">
                  OpenShorts Engine
                </span>
                {activeStudioClip.viralScore && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                    <Flame className="w-3 h-3" />
                    <span>Viral {activeStudioClip.viralScore}/100</span>
                  </span>
                )}
              </div>
              <p className="text-[11px] text-neutral-400 truncate max-w-sm sm:max-w-md">
                {customTitle}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveCustomization}
              className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-neutral-200 border border-neutral-700 transition-colors"
            >
              Save Edits
            </button>
            <button
              onClick={closeStudioModal}
              className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Main Work Area: 2 Columns */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden min-h-0">
          {/* Left: 9:16 Interactive Video Preview Canvas (5 cols) */}
          <div className="lg:col-span-5 bg-black p-4 flex flex-col items-center justify-center relative overflow-hidden border-r border-neutral-800">
            {/* Background ambient glow */}
            <img
              src={customThumbnail}
              alt=""
              className="absolute inset-0 w-full h-full object-cover blur-3xl opacity-20 scale-125"
            />

            {/* Vertical 9:16 Canvas Mockup */}
            <div className="relative w-full max-w-[280px] sm:max-w-[320px] aspect-[9/16] bg-neutral-950 rounded-2xl overflow-hidden shadow-2xl border border-neutral-800 flex flex-col justify-between">
              {/* Media image / simulated video */}
              <img
                src={customThumbnail}
                alt=""
                className="absolute inset-0 w-full h-full object-cover transition-transform"
                style={{
                  transform: reframe?.mode === 'smart_face'
                    ? `scale(1.08) translateX(${reframe.horizontalOffset * 0.8}%)`
                    : 'scale(1)'
                }}
              />

              {/* MediaPipe Face Tracking Bounding Box */}
              {reframe?.mode === 'smart_face' && (
                <div
                  className="absolute z-10 pointer-events-none transition-all duration-75 border-2 border-dashed border-cyan-400/80 rounded-xl bg-cyan-500/10"
                  style={{
                    left: `${faceBox.x}%`,
                    top: `${faceBox.y}%`,
                    width: `${faceBox.width}%`,
                    height: `${faceBox.height}%`
                  }}
                >
                  <div className="absolute -top-4 left-0 px-1 py-0.2 rounded bg-cyan-950/90 text-cyan-300 font-mono text-[8px] border border-cyan-500/30 whitespace-nowrap">
                    MediaPipe 96%
                  </div>
                </div>
              )}

              {/* 9:16 Social Safe Zone Overlay Guide */}
              {showSafeZone && (
                <div className="absolute inset-0 z-15 pointer-events-none border border-emerald-500/40">
                  <div className="absolute top-2 left-2 text-[8px] font-mono text-emerald-400 bg-black/70 px-1 rounded border border-emerald-500/30">
                    SAFE ZONE (TIKTOK / REELS)
                  </div>
                  <div className="absolute right-1 bottom-16 w-8 h-32 border border-rose-500/40 bg-rose-500/10 rounded text-[8px] font-mono text-rose-300 p-0.5 flex items-center justify-center text-center">
                    UI Icons
                  </div>
                  <div className="absolute bottom-1 left-2 right-12 h-10 border border-rose-500/40 bg-rose-500/10 rounded text-[8px] font-mono text-rose-300 p-0.5 flex items-center justify-center">
                    Caption Block
                  </div>
                </div>
              )}

              {/* 1. Hook Overlay (Rendered at top or selected position) */}
              {hookOverlay && (
                <div
                  className={`absolute left-3 right-3 z-20 transition-all ${
                    hookOverlay.position === 'top'
                      ? 'top-4'
                      : hookOverlay.position === 'middle'
                      ? 'top-1/2 -translate-y-1/2'
                      : 'bottom-16'
                  }`}
                >
                  <div
                    className="p-2 text-center rounded-lg shadow-lg font-bold text-xs tracking-wide uppercase transition-all"
                    style={{
                      background: HOOK_STYLES[hookOverlay.style]?.box,
                      color: HOOK_STYLES[hookOverlay.style]?.textColor,
                      border: HOOK_STYLES[hookOverlay.style]?.border,
                      fontFamily: hookOverlay.font === 'anton' ? 'Impact, sans-serif' : 'Montserrat, sans-serif'
                    }}
                  >
                    {hookOverlay.text}
                  </div>
                </div>
              )}

              {/* 2. Kinetic Captions Layer */}
              {subtitles && (
                <div
                  className={`absolute left-3 right-3 z-20 text-center transition-all ${
                    subtitles.position === 'top'
                      ? 'top-20'
                      : subtitles.position === 'middle'
                      ? 'top-1/2 -translate-y-1/2'
                      : 'bottom-16'
                  }`}
                >
                  <div
                    className="inline-block px-3 py-1.5 rounded-xl font-extrabold tracking-tight transition-all"
                    style={{
                      fontFamily: subtitles.font === 'Anton' ? 'Impact, sans-serif' : 'Montserrat, sans-serif',
                      fontSize: `${subtitles.fontSize - 6}px`,
                      color: subtitles.primaryColor,
                      textTransform: subtitles.uppercase ? 'uppercase' : 'none',
                      textShadow: '0 2px 8px rgba(0,0,0,0.9), 0 0 2px #000'
                    }}
                  >
                    {currentWord ? (
                      <span
                        className="px-2 py-0.5 rounded-md inline-block transform scale-110 transition-transform"
                        style={{
                          backgroundColor: subtitles.preset === 'pill' ? '#ffffff' : 'transparent',
                          color: subtitles.preset === 'pill' ? '#000000' : subtitles.highlightColor,
                          textShadow: subtitles.preset === 'pill' ? 'none' : `0 0 10px ${subtitles.highlightColor}`
                        }}
                      >
                        {currentWord.word}
                      </span>
                    ) : (
                      <span>{subtitles.words.slice(0, 4).map(w => w.word).join(' ')}</span>
                    )}
                  </div>
                </div>
              )}

              {/* Tap to Play overlay button */}
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="absolute inset-0 flex items-center justify-center focus:outline-none"
              >
                {!isPlaying && (
                  <div className="w-12 h-12 rounded-full bg-white/90 text-neutral-950 flex items-center justify-center shadow-2xl">
                    <Play className="w-6 h-6 ml-0.5 fill-current" />
                  </div>
                )}
              </button>

              {/* Bottom Scrim & Player Controls */}
              <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-neutral-950 via-neutral-950/80 to-transparent z-20">
                <div className="flex items-center gap-2 mb-1.5">
                  <input
                    type="range"
                    min={trimStart}
                    max={trimEnd}
                    step="0.1"
                    value={currentTime}
                    onChange={(e) => setCurrentTime(Number(e.target.value))}
                    className="w-full h-1 bg-neutral-700 accent-rose-500 rounded cursor-pointer"
                  />
                  <span className="text-[10px] font-mono text-neutral-300 tabular-nums shrink-0">
                    {currentTime.toFixed(1)}s / {trimEnd.toFixed(1)}s
                  </span>
                </div>

                <div className="flex items-center justify-between text-neutral-300">
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setIsPlaying(!isPlaying)}
                      className="p-1 hover:text-white"
                    >
                      {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                    </button>
                    <button
                      onClick={() => setIsMuted(!isMuted)}
                      className="p-1 hover:text-white"
                    >
                      {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      onClick={() => setIsLooping(!isLooping)}
                      className={`p-1 ${isLooping ? 'text-rose-400' : 'text-neutral-500'}`}
                    >
                      <RotateCcw className="w-3 h-3" />
                    </button>
                  </div>
                  <span className="text-[10px] font-mono text-neutral-400">1080×1920 60FPS</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Studio Control Tabs (7 cols) */}
          <div className="lg:col-span-7 flex flex-col bg-neutral-900 overflow-y-auto">
            {/* Tabs Header */}
            <div className="flex items-center gap-1 p-2 bg-neutral-950 border-b border-neutral-800 text-xs overflow-x-auto">
              <button
                onClick={() => setActiveTab('captions')}
                className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                  activeTab === 'captions'
                    ? 'bg-neutral-800 text-white'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Type className="w-3.5 h-3.5 text-rose-400" />
                <span>Captions</span>
              </button>

              <button
                onClick={() => setActiveTab('hook')}
                className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                  activeTab === 'hook'
                    ? 'bg-neutral-800 text-white'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Hook Overlay</span>
              </button>

              <button
                onClick={() => setActiveTab('reframe')}
                className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                  activeTab === 'reframe'
                    ? 'bg-neutral-800 text-white'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Scissors className="w-3.5 h-3.5 text-sky-400" />
                <span>Trim & Reframe</span>
              </button>

              <button
                onClick={() => setActiveTab('thumbnail')}
                className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                  activeTab === 'thumbnail'
                    ? 'bg-neutral-800 text-white'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <ImageIcon className="w-3.5 h-3.5 text-emerald-400" />
                <span>Thumbnail</span>
              </button>

              <button
                onClick={() => setActiveTab('ai_copy')}
                className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                  activeTab === 'ai_copy'
                    ? 'bg-neutral-800 text-white'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Flame className="w-3.5 h-3.5 text-rose-400" />
                <span>AI Copy</span>
              </button>

              <button
                onClick={() => setActiveTab('export')}
                className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                  activeTab === 'export'
                    ? 'bg-rose-500 text-white shadow-sm'
                    : 'text-neutral-300 hover:text-white'
                }`}
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export</span>
              </button>
            </div>

            {/* Tab Contents */}
            <div className="p-6 flex-1 overflow-y-auto space-y-6">
              {/* TAB 1: CAPTIONS */}
              {activeTab === 'captions' && subtitles && (
                <div className="space-y-5 text-xs">
                  <div>
                    <h4 className="font-semibold text-neutral-200 mb-1">OpenShorts Caption Presets</h4>
                    <p className="text-neutral-400 mb-3">
                      Select proven high-retention caption styles with active word synchronization.
                    </p>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                      {(Object.keys(SUBTITLE_PRESETS) as SubtitleStylePreset[]).map(key => {
                        const pr = SUBTITLE_PRESETS[key];
                        const isSelected = subtitles.preset === key;
                        return (
                          <button
                            key={key}
                            onClick={() => handlePresetSelect(key)}
                            className={`p-3 rounded-xl border text-left transition-all ${
                              isSelected
                                ? 'bg-rose-500/10 border-rose-500/40 text-white'
                                : 'bg-neutral-950 border-neutral-800 text-neutral-300 hover:border-neutral-700'
                            }`}
                          >
                            <span className="font-bold text-xs block mb-0.5">{pr.name}</span>
                            <span className="text-[10px] text-neutral-400 line-clamp-2 leading-tight">
                              {pr.description}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-neutral-800">
                    <div>
                      <label className="block text-neutral-300 font-medium mb-1.5">Highlight Color</label>
                      <div className="flex items-center gap-2">
                        {['#FFE500', '#A3FF12', '#00FFFF', '#FF3366', '#FFFFFF', '#60A5FA'].map(c => (
                          <button
                            key={c}
                            onClick={() => setSubtitles({ ...subtitles, highlightColor: c })}
                            className={`w-6 h-6 rounded-full border-2 transition-transform ${
                              subtitles.highlightColor === c ? 'scale-110 border-white' : 'border-transparent'
                            }`}
                            style={{ backgroundColor: c }}
                          />
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-neutral-300 font-medium mb-1.5">Position</label>
                      <div className="grid grid-cols-3 gap-1">
                        {(['top', 'middle', 'bottom'] as const).map(pos => (
                          <button
                            key={pos}
                            onClick={() => setSubtitles({ ...subtitles, position: pos })}
                            className={`py-1.5 rounded-lg capitalize text-xs font-medium border ${
                              subtitles.position === pos
                                ? 'bg-neutral-800 text-white border-neutral-600'
                                : 'bg-neutral-950 text-neutral-400 border-neutral-800'
                            }`}
                          >
                            {pos}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Editable Transcript Textarea */}
                  <div className="pt-4 border-t border-neutral-800">
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="font-semibold text-neutral-200">Modify Spoken Transcript Text</label>
                      <button
                        onClick={() => handleRecalculateCaptions(transcriptEditorText)}
                        className="text-[11px] font-semibold text-rose-400 hover:text-rose-300 flex items-center gap-1"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>Re-align Word Timestamps</span>
                      </button>
                    </div>
                    <textarea
                      rows={2}
                      value={transcriptEditorText}
                      onChange={(e) => setTranscriptEditorText(e.target.value)}
                      placeholder="Type or edit spoken words here..."
                      className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-200 text-xs font-mono focus:outline-none focus:border-rose-500"
                    />
                  </div>

                  {/* Word-level Timing Preview */}
                  <div className="pt-4 border-t border-neutral-800">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-neutral-200">
                        Word-Level Timestamps ({subtitles.words.length} tokens)
                      </span>
                      <span className="text-[10px] text-neutral-400 font-mono">
                        Active: {currentWord ? currentWord.word : 'None'}
                      </span>
                    </div>
                    <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 max-h-32 overflow-y-auto flex flex-wrap gap-1.5 font-mono text-[11px]">
                      {subtitles.words.map((w, i) => (
                        <span
                          key={i}
                          className={`px-1.5 py-0.5 rounded cursor-pointer transition-colors ${
                            currentTime >= w.start && currentTime <= w.end
                              ? 'bg-rose-500 text-white font-bold'
                              : 'bg-neutral-900 text-neutral-400 hover:text-neutral-200'
                          }`}
                          onClick={() => setCurrentTime(w.start)}
                          title={`Click to seek to ${w.start}s`}
                        >
                          {w.word}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: HOOK OVERLAY */}
              {activeTab === 'hook' && hookOverlay && (
                <div className="space-y-5 text-xs">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block font-semibold text-neutral-200">Viral Hook Headline Text</label>
                      <span className="text-[11px] text-amber-400 font-mono">Seconds 0 to {hookOverlay.durationSeconds}s</span>
                    </div>
                    <input
                      type="text"
                      value={hookOverlay.text}
                      onChange={(e) => setHookOverlay({ ...hookOverlay, text: e.target.value.toUpperCase() })}
                      placeholder="e.g. THIS 1 HABIT DESTROYS YOUR SLEEP"
                      className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-white focus:outline-none focus:border-rose-500 font-bold"
                    />

                    {/* Quick AI Hook Chips */}
                    <div className="mt-2 flex flex-wrap items-center gap-1.5">
                      <span className="text-[10px] text-neutral-500 font-mono">Suggested:</span>
                      {[
                        'DO THIS BEFORE YOUR BRAIN GIVES UP',
                        'THIS 1 HABIT DESTROYS FOCUS',
                        'NOBODY WANTS TO ADMIT THIS',
                        'WATCH TILL THE VERY END'
                      ].map(h => (
                        <button
                          key={h}
                          type="button"
                          onClick={() => setHookOverlay({ ...hookOverlay, text: h })}
                          className="px-2 py-0.5 rounded bg-neutral-950 hover:bg-neutral-800 text-neutral-400 hover:text-rose-300 border border-neutral-800 text-[10px] font-mono transition-colors"
                        >
                          {h}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block font-semibold text-neutral-200 mb-2">Hook Visual Style</label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {(Object.keys(HOOK_STYLES) as HookStyle[]).map(st => {
                        const styleConfig = HOOK_STYLES[st];
                        const isSelected = hookOverlay.style === st;
                        return (
                          <button
                            key={st}
                            onClick={() => setHookOverlay({ ...hookOverlay, style: st })}
                            className={`p-2.5 rounded-lg border text-center transition-all ${
                              isSelected
                                ? 'bg-rose-500/10 border-rose-500/40 text-white font-bold'
                                : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                            }`}
                          >
                            <span>{styleConfig.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-neutral-800">
                    <div>
                      <label className="block font-semibold text-neutral-200 mb-1">Display Duration</label>
                      <input
                        type="range"
                        min="2"
                        max="8"
                        step="0.5"
                        value={hookOverlay.durationSeconds}
                        onChange={(e) => setHookOverlay({ ...hookOverlay, durationSeconds: Number(e.target.value) })}
                        className="w-full h-1 bg-neutral-700 accent-rose-500 rounded cursor-pointer"
                      />
                      <span className="text-[11px] font-mono text-neutral-400 mt-1 block">
                        {hookOverlay.durationSeconds} seconds
                      </span>
                    </div>

                    <div>
                      <label className="block font-semibold text-neutral-200 mb-1">Entrance Animation</label>
                      <select
                        value={hookOverlay.entrance}
                        onChange={(e) => {
                          const entrance = (['spring', 'fade', 'slide-up', 'none'] as const)
                            .find((option) => option === e.target.value);
                          if (entrance) setHookOverlay({ ...hookOverlay, entrance });
                        }}
                        className="w-full px-3 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-200 text-xs focus:outline-none"
                      >
                        <option value="spring">Spring / Bounce</option>
                        <option value="fade">Smooth Fade</option>
                        <option value="slide-up">Slide Up</option>
                        <option value="none">Instant</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: TRIM & REFRAME */}
              {activeTab === 'reframe' && reframe && (
                <div className="space-y-5 text-xs">
                  <div>
                    <h4 className="font-semibold text-neutral-200 mb-1">Smart 9:16 Cropping & Face Tracking</h4>
                    <p className="text-neutral-400 mb-3">
                      Automatically pans and centers subjects from 16:9 widescreen footage into vertical mobile format.
                    </p>

                    <div className="grid grid-cols-3 gap-2">
                      <button
                        onClick={() => setReframe({ ...reframe, mode: 'smart_face' })}
                        className={`p-3 rounded-xl border text-center transition-all ${
                          reframe.mode === 'smart_face'
                            ? 'bg-rose-500/10 border-rose-500/40 text-white font-bold'
                            : 'bg-neutral-950 border-neutral-800 text-neutral-400'
                        }`}
                      >
                        <span className="block font-bold text-xs mb-0.5">Smart Face</span>
                        <span className="text-[10px] text-neutral-500">Auto Face Tracking</span>
                      </button>

                      <button
                        onClick={() => setReframe({ ...reframe, mode: 'center' })}
                        className={`p-3 rounded-xl border text-center transition-all ${
                          reframe.mode === 'center'
                            ? 'bg-rose-500/10 border-rose-500/40 text-white font-bold'
                            : 'bg-neutral-950 border-neutral-800 text-neutral-400'
                        }`}
                      >
                        <span className="block font-bold text-xs mb-0.5">Center Crop</span>
                        <span className="text-[10px] text-neutral-500">Fixed 9:16 Center</span>
                      </button>

                      <button
                        onClick={() => setReframe({ ...reframe, mode: 'split_stacked' })}
                        className={`p-3 rounded-xl border text-center transition-all ${
                          reframe.mode === 'split_stacked'
                            ? 'bg-rose-500/10 border-rose-500/40 text-white font-bold'
                            : 'bg-neutral-950 border-neutral-800 text-neutral-400'
                        }`}
                      >
                        <span className="block font-bold text-xs mb-0.5">Stacked Split</span>
                        <span className="text-[10px] text-neutral-500">2-Speaker Podcast</span>
                      </button>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-neutral-800">
                    <label className="block font-semibold text-neutral-200 mb-1">
                      Horizontal Crop Offset: {reframe.horizontalOffset}%
                    </label>
                    <input
                      type="range"
                      min="-40"
                      max="40"
                      value={reframe.horizontalOffset}
                      onChange={(e) => setReframe({ ...reframe, horizontalOffset: Number(e.target.value) })}
                      className="w-full h-1 bg-neutral-700 accent-rose-500 rounded cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] font-mono text-neutral-500 mt-1">
                      <span>Pan Left (-40%)</span>
                      <span>Center (0%)</span>
                      <span>Pan Right (+40%)</span>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-neutral-800">
                    <h4 className="font-semibold text-neutral-200 mb-2">Trim Boundaries</h4>
                    <div className="grid grid-cols-2 gap-4 font-mono">
                      <div>
                        <label className="text-[11px] text-neutral-400 block mb-1">Start Time (sec)</label>
                        <input
                          type="number"
                          min="0"
                          max={trimEnd - 3}
                          value={trimStart}
                          onChange={(e) => setTrimStart(Number(e.target.value))}
                          className="w-full px-3 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-200 text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-neutral-400 block mb-1">End Time (sec)</label>
                        <input
                          type="number"
                          min={trimStart + 3}
                          max={activeStudioClip.duration}
                          value={trimEnd}
                          onChange={(e) => setTrimEnd(Number(e.target.value))}
                          className="w-full px-3 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-200 text-xs"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Safe Zone Toggle */}
                  <div className="pt-4 border-t border-neutral-800 flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-neutral-200 block">TikTok / Reels Safe Zone Overlay</span>
                      <span className="text-[11px] text-neutral-400">Preview UI dead zones where captions might be blocked</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowSafeZone(!showSafeZone)}
                      className={`px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors ${
                        showSafeZone
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                          : 'bg-neutral-950 text-neutral-400 border-neutral-800'
                      }`}
                    >
                      {showSafeZone ? 'Guide Enabled' : 'Show Guide'}
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 4: THUMBNAIL */}
              {activeTab === 'thumbnail' && (
                <div className="space-y-5 text-xs">
                  <div>
                    <h4 className="font-semibold text-neutral-200 mb-1">OpenShorts Thumbnail Studio</h4>
                    <p className="text-neutral-400 mb-4">
                      High-contrast visual title banners engineered for YouTube Shorts & TikTok click-through rate.
                    </p>

                    <div className="flex items-center gap-4 p-4 rounded-xl bg-neutral-950 border border-neutral-800">
                      <img
                        src={customThumbnail}
                        alt=""
                        className="w-20 h-32 rounded-lg object-cover border border-neutral-800 shrink-0 shadow-lg"
                      />
                      <div className="space-y-3 flex-1 min-w-0">
                        <div>
                          <label className="block text-[11px] text-neutral-400 mb-1">Custom Title Banner Text</label>
                          <input
                            type="text"
                            value={customTitle}
                            onChange={(e) => setCustomTitle(e.target.value)}
                            className="w-full px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 text-xs text-white"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] text-neutral-400 mb-1.5">High-CTR Theme Presets</label>
                          <div className="grid grid-cols-3 gap-1.5">
                            {[
                              { id: 'category', label: 'Default' },
                              { id: 'gold_rush', label: 'Gold Rush (+16% CTR)' },
                              { id: 'cyber_neon', label: 'Cyber Neon' },
                              { id: 'crimson_flame', label: 'Crimson Flame' },
                              { id: 'emerald_pulse', label: 'Emerald' },
                              { id: 'clean_minimal', label: 'Monochrome' }
                            ].map(t => (
                              <button
                                key={t.id}
                                type="button"
                                onClick={() => handleRegenerateThumbnail(t.id as ThumbnailTheme)}
                                className={`px-2 py-1.5 rounded-lg border text-left text-[10px] font-mono transition-colors ${
                                  thumbnailTheme === t.id
                                    ? 'bg-rose-500/15 border-rose-500/40 text-white font-bold'
                                    : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                                }`}
                              >
                                {t.label}
                              </button>
                            ))}
                          </div>
                        </div>

                        <button
                          onClick={() => handleRegenerateThumbnail()}
                          className="px-3.5 py-1.5 rounded-lg bg-rose-500 hover:bg-rose-600 text-xs font-semibold text-white shadow-md flex items-center gap-1.5 transition-all"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Regenerate Banner SVG</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: AI VIRAL COPY */}
              {activeTab === 'ai_copy' && (
                <div className="space-y-4 text-xs">
                  <div>
                    <h4 className="font-semibold text-neutral-200 mb-1">OpenShorts AI Viral Hook & Title Engine</h4>
                    <p className="text-neutral-400 mb-3">
                      High-retention title variations, psychological hook lines, and SEO captions optimized for algorithms.
                    </p>
                  </div>

                  <div className="space-y-3">
                    {aiTitleOptions.map((opt, i) => (
                      <div key={i} className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2.5">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <span className="font-bold text-xs text-white block">{opt.title}</span>
                            <span className="text-[11px] text-amber-400 font-mono">Hook: "{opt.hook}"</span>
                          </div>
                          <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shrink-0">
                            {opt.estimatedCtr}
                          </span>
                        </div>

                        <p className="text-[11px] text-neutral-400">
                          <strong>Retention Rationale:</strong> {opt.rationale}
                        </p>

                        <div className="p-2.5 rounded-lg bg-neutral-900 border border-neutral-850 text-[11px] text-neutral-300 font-mono">
                          {opt.description}
                        </div>

                        <div className="pt-1 flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleApplyAiTitle(opt)}
                            className="px-3 py-1.5 rounded-lg bg-rose-500 hover:bg-rose-600 text-white font-semibold text-xs flex items-center gap-1.5"
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>Apply Title & Hook to Clip</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard?.writeText(opt.description);
                              addToast('Copied to Clipboard', 'Social description copied.', 'success');
                            }}
                            className="px-3 py-1.5 rounded-lg bg-neutral-850 hover:bg-neutral-800 text-neutral-300 border border-neutral-700 text-xs"
                          >
                            Copy Description
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 5: EXPORT & DOWNLOAD */}
              {activeTab === 'export' && (
                <div className="space-y-5 text-xs">
                  <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold text-neutral-200">Target Specifications</h4>
                      <span className="font-mono text-amber-400 text-[11px]">Not rendered in this build</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 font-mono text-[11px] text-neutral-400">
                      <div>Format: 1080×1920 (9:16) MP4</div>
                      <div>Framerate: 60 FPS</div>
                      <div>Captions: {subtitles?.preset.toUpperCase()} ({subtitles?.font})</div>
                      <div>Duration: {Math.round(trimEnd - trimStart)}s</div>
                    </div>
                  </div>

                  {/* FFmpeg Command Preview */}
                  <div>
                    <span className="text-[11px] font-mono text-neutral-500 uppercase block mb-1 flex items-center gap-1">
                      <Code2 className="w-3.5 h-3.5" />
                      <span>Render command preview (not executed here)</span>
                    </span>
                    <pre className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 text-[10px] font-mono text-neutral-400 overflow-x-auto whitespace-pre-wrap">
                      {buildFFmpegRenderCommand(
                        activeStudioClip,
                        subtitles || undefined,
                        hookOverlay || undefined,
                        reframe || undefined
                      )}
                    </pre>
                  </div>

                  {/* Render status: no media rendering exists in this build */}
                  <div className="pt-2 space-y-3">
                    <div
                      role="status"
                      className="p-3 rounded-xl bg-amber-500/5 border border-amber-500/30 text-amber-200 flex gap-2"
                    >
                      <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
                      <p>
                        MP4 export is not available in this build. Rendering requires the production media service
                        (for example FFmpeg running on a server). No file is produced here, and your edits are kept in
                        the clip's customization data.
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled
                      className="w-full py-3 rounded-xl bg-neutral-800 text-neutral-500 font-semibold text-xs flex items-center justify-center gap-2 cursor-not-allowed"
                    >
                      <Download className="w-4 h-4" />
                      <span>Render MP4 (requires render service)</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
