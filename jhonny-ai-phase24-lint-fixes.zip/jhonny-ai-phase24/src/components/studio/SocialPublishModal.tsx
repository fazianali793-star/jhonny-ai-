import React, { useState } from 'react';
import { X, Copy, Check, Share2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const SocialPublishModal: React.FC = () => {
  const { activeSocialClip, closeSocialModal, addToast } = useApp();
  const [activePlatform, setActivePlatform] = useState<'tiktok' | 'youtube' | 'reels'>('tiktok');
  const [copied, setCopied] = useState(false);

  if (!activeSocialClip) return null;

  const hashtags = (activeSocialClip.tags || ['shorts', 'viral', 'fyp'])
    .map(t => `#${t}`)
    .join(' ');

  const postCopy = {
    tiktok: `${activeSocialClip.title}\n\n${activeSocialClip.hookText || 'Wait till the end...'} 🔥\n\n${hashtags} #fyp #viral #foryou #jhonnyai`,
    youtube: `${activeSocialClip.title} #Shorts\n\n${activeSocialClip.description}\n\nLicensed via JHONNY AI Creator Syndication\n${hashtags}`,
    reels: `${activeSocialClip.title}\n\n${activeSocialClip.description}\n.\n.\n.\n${hashtags} #reels #viralvideos #reelsinstagram`
  };

  const currentCopy = postCopy[activePlatform];

  const handleCopy = () => {
    navigator.clipboard?.writeText(currentCopy);
    setCopied(true);
    addToast('Post Draft Copied', `Optimized caption and tags copied for ${activePlatform.toUpperCase()}!`, 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl p-6">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <Share2 className="w-4 h-4 text-rose-500" />
            <h3 className="font-bold text-sm text-white">1-Click Social Publishing Draft</h3>
          </div>
          <button
            onClick={closeSocialModal}
            className="p-1 rounded text-neutral-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-4 space-y-4 text-xs">
          {/* Platform Tabs */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => setActivePlatform('tiktok')}
              className={`py-2 px-3 rounded-lg border font-semibold text-center transition-colors ${
                activePlatform === 'tiktok'
                  ? 'bg-rose-500/10 border-rose-500 text-rose-300'
                  : 'bg-neutral-950 border-neutral-800 text-neutral-400'
              }`}
            >
              TikTok
            </button>
            <button
              onClick={() => setActivePlatform('youtube')}
              className={`py-2 px-3 rounded-lg border font-semibold text-center transition-colors ${
                activePlatform === 'youtube'
                  ? 'bg-rose-500/10 border-rose-500 text-rose-300'
                  : 'bg-neutral-950 border-neutral-800 text-neutral-400'
              }`}
            >
              YouTube Shorts
            </button>
            <button
              onClick={() => setActivePlatform('reels')}
              className={`py-2 px-3 rounded-lg border font-semibold text-center transition-colors ${
                activePlatform === 'reels'
                  ? 'bg-rose-500/10 border-rose-500 text-rose-300'
                  : 'bg-neutral-950 border-neutral-800 text-neutral-400'
              }`}
            >
              Instagram Reels
            </button>
          </div>

          {/* Formatted Copy Box */}
          <div>
            <label className="block text-neutral-400 font-medium mb-1">
              Optimized Caption & Tags
            </label>
            <textarea
              readOnly
              rows={6}
              value={currentCopy}
              className="w-full p-3 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-200 text-xs font-mono focus:outline-none"
            />
          </div>

          <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-850 text-[11px] text-neutral-400">
            Permission status: <strong className="text-emerald-400">100% Cleared</strong> for {activePlatform.toUpperCase()}. Watermark-free master clip.
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              onClick={handleCopy}
              className="w-full py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-md transition-all active:scale-95"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Copied to Clipboard!' : 'Copy Caption & Hashtags'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
