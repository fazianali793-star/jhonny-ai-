import type { Clip, Creator, LicenseRecord, CopyrightReport, ClipCategory } from '../types';

export const CATEGORIES: ClipCategory[] = [
  'Gaming',
  'Minecraft',
  'Podcasts',
  'Motivation',
  'Comedy',
  'Reactions',
  'Sports',
  'AI',
  'Entertainment'
];

export const INITIAL_CREATORS: Creator[] = [
  {
    id: 'c1',
    name: 'Marcus Vance',
    handle: '@marcusvance',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    bio: 'Tech entrepreneur & deep-dive podcaster sharing high-impact conversations with founders.',
    verified: true,
    totalClips: 48,
    totalDownloads: 142500,
    channels: {
      youtube: 'https://youtube.com/@marcusvance',
      tiktok: 'https://tiktok.com/@marcusvance',
      twitch: 'https://twitch.tv/marcusvance'
    },
    joinedDate: '2025-08-14',
    status: 'Active'
  },
  {
    id: 'c2',
    name: 'Aiden Craft',
    handle: '@aidencraft',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    bio: 'High-octane Minecraft builder, speedrunner & redstone engineer.',
    verified: true,
    totalClips: 82,
    totalDownloads: 289100,
    channels: {
      youtube: 'https://youtube.com/@aidencraft',
      twitch: 'https://twitch.tv/aidencraft'
    },
    joinedDate: '2025-06-20',
    status: 'Active'
  },
  {
    id: 'c3',
    name: 'Elena Rostova',
    handle: '@elenamindset',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    bio: 'Peak performance coach and speaker. Powerful daily discipline reflections.',
    verified: true,
    totalClips: 36,
    totalDownloads: 95400,
    channels: {
      youtube: 'https://youtube.com/@elenamindset',
      tiktok: 'https://tiktok.com/@elenamindset',
      instagram: 'https://instagram.com/elenamindset'
    },
    joinedDate: '2025-09-02',
    status: 'Active'
  },
  {
    id: 'c4',
    name: 'PixelForge Studios',
    handle: '@pixelforge',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    bio: 'Esports commentary group and tournament highlight studio. Official syndication partner.',
    verified: true,
    totalClips: 114,
    totalDownloads: 412000,
    channels: {
      youtube: 'https://youtube.com/@pixelforge',
      twitch: 'https://twitch.tv/pixelforge'
    },
    joinedDate: '2025-04-11',
    status: 'Active'
  },
  {
    id: 'c5',
    name: 'Devin K.',
    handle: '@devincomedy',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    bio: 'Stand-up comedian & improv creator. Clean relatable observational comedy.',
    verified: true,
    totalClips: 29,
    totalDownloads: 74200,
    channels: {
      tiktok: 'https://tiktok.com/@devincomedy',
      instagram: 'https://instagram.com/devincomedy'
    },
    joinedDate: '2025-11-10',
    status: 'Active'
  }
];

// High-fidelity fallback / styled thumbnails encoded cleanly
const makeThumb = (bg: string, label: string, accent: string) =>
  `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="540" height="960" viewBox="0 0 540 960"><defs><linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="${bg}"/><stop offset="100%" stop-color="%2309090b"/></linearGradient></defs><rect width="100%" height="100%" fill="url(%23g)"/><circle cx="270" cy="400" r="160" fill="${accent}" opacity="0.12"/><path d="M240 350 L330 400 L240 450 Z" fill="${accent}" opacity="0.9"/><rect x="50" y="740" width="440" height="3" rx="1.5" fill="${accent}" opacity="0.4"/><text x="270" y="650" fill="%23ffffff" font-family="system-ui,sans-serif" font-weight="700" font-size="28" text-anchor="middle">${encodeURIComponent(label)}</text><text x="270" y="690" fill="%23a1a1aa" font-family="system-ui,sans-serif" font-size="16" text-anchor="middle">LICENSED FOR REELS %26 SHORTS</text></svg>`;

export const INITIAL_CLIPS: Clip[] = [
  {
    id: 'clip-1',
    slug: 'the-secret-to-extreme-focus-marcus-vance',
    title: 'The Hard Truth About Flow State and Dopamine Resets',
    description: 'Marcus Vance breaks down how eliminating high-frequency context switching quadrupled his creative output. Permission-cleared from The Vanguard Podcast Ep. 88.',
    thumbnail: makeThumb('%231e1b4b', 'Flow State & Focus', '%23818cf8'),
    creatorId: 'c1',
    creator: {
      id: 'c1',
      name: 'Marcus Vance',
      handle: '@marcusvance',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      verified: true
    },
    category: 'Podcasts',
    duration: 38,
    durationFormatted: '0:38',
    resolution: '1080x1920 (9:16)',
    fps: 60,
    downloads: 14200,
    views: 89400,
    likes: 3820,
    tags: ['dopamine', 'focus', 'productivity', 'habits', 'podcast'],
    status: 'Published',
    featured: true,
    trending: true,
    viralScore: 94,
    reasoning: 'Immediate scientific hook questioning daily dopamine routines. High retention in first 5s.',
    hookText: 'THIS 1 HABIT DESTROYS YOUR FOCUS',
    hookOverlay: {
      text: 'THIS 1 HABIT DESTROYS YOUR FOCUS',
      style: 'yellow',
      font: 'montserrat',
      position: 'top',
      entrance: 'spring',
      durationSeconds: 4.5
    },
    subtitles: {
      preset: 'hormozi',
      font: 'Anton',
      fontSize: 28,
      primaryColor: '#FFFFFF',
      highlightColor: '#FFE500',
      uppercase: true,
      animation: 'pop',
      position: 'middle',
      words: [
        { word: 'THE', start: 0.2, end: 0.5 },
        { word: 'MOMENT', start: 0.6, end: 1.1 },
        { word: 'YOU', start: 1.2, end: 1.4 },
        { word: 'CHECK', start: 1.5, end: 1.9 },
        { word: 'YOUR', start: 2.0, end: 2.2 },
        { word: 'PHONE,', start: 2.3, end: 2.8 },
        { word: 'YOUR', start: 3.0, end: 3.3 },
        { word: 'BRAIN', start: 3.4, end: 3.8 },
        { word: 'LOSES', start: 3.9, end: 4.3 },
        { word: 'TWENTY', start: 4.5, end: 4.9 },
        { word: 'MINUTES', start: 5.0, end: 5.5 },
        { word: 'OF', start: 5.6, end: 5.8 },
        { word: 'DEEP', start: 5.9, end: 6.3 },
        { word: 'FOCUS.', start: 6.4, end: 7.2 }
      ]
    },
    reframe: {
      mode: 'smart_face',
      horizontalOffset: 0,
      splitRatio: 50,
      safeZoneRadius: 15
    },
    sourceStartSeconds: 412,
    sourceEndSeconds: 450,
    createdAt: '2026-03-28T14:22:00Z',
    licenseInfo: {
      licenseId: 'LIC-2026-001',
      type: 'Non-Exclusive',
      status: 'Active',
      sourceUrl: 'https://youtube.com/watch?v=mock-vanguard-88',
      allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts', 'X'],
      attributionRequired: false,
      expiresAt: '2027-03-28T00:00:00Z'
    }
  },
  {
    id: 'clip-2',
    slug: 'insane-clutch-nether-water-bucket-trick',
    title: 'Impossible 1-Heart Nether Portal Clutch',
    description: 'Aiden Craft executes a frame-perfect calculated save during a hardcore speedrun. Licensed directly from Twitch highlight reel with creator syndication grant.',
    thumbnail: makeThumb('%23064e3b', '1-Heart Nether Clutch', '%2334d399'),
    creatorId: 'c2',
    creator: {
      id: 'c2',
      name: 'Aiden Craft',
      handle: '@aidencraft',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      verified: true
    },
    category: 'Minecraft',
    duration: 24,
    durationFormatted: '0:24',
    resolution: '1080x1920 (9:16)',
    fps: 60,
    downloads: 38500,
    views: 241000,
    likes: 11200,
    tags: ['minecraft', 'speedrun', 'hardcore', 'clutch', 'gaming'],
    status: 'Published',
    featured: true,
    trending: true,
    viralScore: 92,
    reasoning: 'High-stakes suspense in hardcore mode. Sudden clutch action holds viewer to the last frame.',
    hookText: 'ONE HEART LEFT IN HARDCORE MODE',
    hookOverlay: {
      text: 'ONE HEART LEFT IN HARDCORE MODE',
      style: 'red',
      font: 'montserrat',
      position: 'top',
      entrance: 'spring',
      durationSeconds: 4.0
    },
    subtitles: {
      preset: 'lime',
      font: 'Montserrat',
      fontSize: 26,
      primaryColor: '#F3F4F6',
      highlightColor: '#A3FF12',
      uppercase: true,
      animation: 'glow',
      position: 'bottom',
      words: [
        { word: 'WATCH', start: 0.1, end: 0.4 },
        { word: 'THE', start: 0.5, end: 0.7 },
        { word: 'HEALTH', start: 0.8, end: 1.2 },
        { word: 'BAR.', start: 1.3, end: 1.7 },
        { word: 'HALF', start: 2.0, end: 2.3 },
        { word: 'A', start: 2.4, end: 2.5 },
        { word: 'HEART', start: 2.6, end: 3.0 },
        { word: 'REMAINING.', start: 3.1, end: 3.9 }
      ]
    },
    reframe: {
      mode: 'center',
      horizontalOffset: 0,
      splitRatio: 50,
      safeZoneRadius: 15
    },
    sourceStartSeconds: 120,
    sourceEndSeconds: 144,
    createdAt: '2026-03-29T19:40:00Z',
    licenseInfo: {
      licenseId: 'LIC-2026-002',
      type: 'Syndicate Partner',
      status: 'Active',
      sourceUrl: 'https://twitch.tv/videos/mock-craft-921',
      allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts'],
      attributionRequired: false,
      expiresAt: '2027-06-15T00:00:00Z'
    }
  },
  {
    id: 'clip-3',
    slug: 'the-3-second-rule-before-giving-up',
    title: 'The 3-Second Rule When You Feel Like Quitting',
    description: 'Elena Rostova on interrupting neural resistance before your mind invents an excuse. Powerful motivation speech with high retention pacing.',
    thumbnail: makeThumb('%23701a75', 'The 3-Second Rule', '%23f472b6'),
    creatorId: 'c3',
    creator: {
      id: 'c3',
      name: 'Elena Rostova',
      handle: '@elenamindset',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
      verified: true
    },
    category: 'Motivation',
    duration: 44,
    durationFormatted: '0:44',
    resolution: '1080x1920 (9:16)',
    fps: 60,
    downloads: 21900,
    views: 115000,
    likes: 6700,
    tags: ['mindset', 'discipline', 'workout', 'motivation', 'grit'],
    status: 'Published',
    featured: true,
    trending: false,
    createdAt: '2026-03-27T09:12:00Z',
    licenseInfo: {
      licenseId: 'LIC-2026-003',
      type: 'Non-Exclusive',
      status: 'Active',
      sourceUrl: 'https://youtube.com/watch?v=mock-elena-mindset-12',
      allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts', 'X'],
      attributionRequired: false,
      expiresAt: '2027-01-20T00:00:00Z'
    }
  },
  {
    id: 'clip-4',
    slug: 'esports-grand-finals-overtime-ace',
    title: 'Grand Finals 1v4 Overtime Ace Reaction',
    description: 'The definitive broadcast play from the Seoul Invitational Finals. Official broadcast rights cleared for social republishing.',
    thumbnail: makeThumb('%23831843', '1v4 Overtime Ace', '%23fb7185'),
    creatorId: 'c4',
    creator: {
      id: 'c4',
      name: 'PixelForge Studios',
      handle: '@pixelforge',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      verified: true
    },
    category: 'Gaming',
    duration: 31,
    durationFormatted: '0:31',
    resolution: '1080x1920 (9:16)',
    fps: 60,
    downloads: 34100,
    views: 189000,
    likes: 9800,
    tags: ['esports', 'ace', 'fps', 'tournament', 'highlights'],
    status: 'Published',
    featured: false,
    trending: true,
    createdAt: '2026-03-30T11:05:00Z',
    licenseInfo: {
      licenseId: 'LIC-2026-004',
      type: 'Syndicate Partner',
      status: 'Active',
      sourceUrl: 'https://youtube.com/watch?v=mock-seoul-finals',
      allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts', 'X'],
      attributionRequired: false,
      expiresAt: '2027-09-01T00:00:00Z'
    }
  },
  {
    id: 'clip-5',
    slug: 'software-engineers-explaining-legacy-code',
    title: 'When the Senior Dev Leaves Zero Documentation',
    description: 'Devin K. satirical comedy sketch about inheriting 10-year-old codebase with comments saying "do not touch or everything breaks".',
    thumbnail: makeThumb('%2314532d', 'Zero Documentation Dev', '%234ade80'),
    creatorId: 'c5',
    creator: {
      id: 'c5',
      name: 'Devin K.',
      handle: '@devincomedy',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
      verified: true
    },
    category: 'Comedy',
    duration: 29,
    durationFormatted: '0:29',
    resolution: '1080x1920 (9:16)',
    fps: 60,
    downloads: 18200,
    views: 92000,
    likes: 4900,
    tags: ['comedy', 'programming', 'humor', 'skit', 'relatable'],
    status: 'Published',
    featured: false,
    trending: true,
    createdAt: '2026-03-26T16:48:00Z',
    licenseInfo: {
      licenseId: 'LIC-2026-005',
      type: 'Non-Exclusive',
      status: 'Active',
      sourceUrl: 'https://tiktok.com/@devincomedy/video/7192847',
      allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts'],
      attributionRequired: false,
      expiresAt: '2026-12-31T00:00:00Z'
    }
  },
  {
    id: 'clip-6',
    slug: 'autonomous-robot-warehouse-speedrun',
    title: 'Humanoid Bipedal Robot Sorts 500 Packages in 3 Minutes',
    description: 'Captivating demonstration of spatial AI pathing in logistics. Licensed from TechLab Next showcases.',
    thumbnail: makeThumb('%230f172a', 'Humanoid Robotics AI', '%2338bdf8'),
    creatorId: 'c1',
    creator: {
      id: 'c1',
      name: 'Marcus Vance',
      handle: '@marcusvance',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      verified: true
    },
    category: 'AI',
    duration: 48,
    durationFormatted: '0:48',
    resolution: '1080x1920 (9:16)',
    fps: 60,
    downloads: 27800,
    views: 164000,
    likes: 8300,
    tags: ['ai', 'robotics', 'engineering', 'future', 'automation'],
    status: 'Published',
    featured: true,
    trending: false,
    createdAt: '2026-03-25T10:15:00Z',
    licenseInfo: {
      licenseId: 'LIC-2026-006',
      type: 'Non-Exclusive',
      status: 'Active',
      sourceUrl: 'https://youtube.com/watch?v=mock-biped-sorter',
      allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts', 'X'],
      attributionRequired: false,
      expiresAt: '2027-04-10T00:00:00Z'
    }
  },
  {
    id: 'clip-7',
    slug: 'buzzer-beater-half-court-shot-celebration',
    title: 'Game 7 Miracle: 0.2s Buzzer-Beater from Half Court',
    description: 'Electrifying basketball moment with crowd explosion. Fully cleared social syndication clip.',
    thumbnail: makeThumb('%237c2d12', 'Half Court Miracle', '%23fb923c'),
    creatorId: 'c4',
    creator: {
      id: 'c4',
      name: 'PixelForge Studios',
      handle: '@pixelforge',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      verified: true
    },
    category: 'Sports',
    duration: 19,
    durationFormatted: '0:19',
    resolution: '1080x1920 (9:16)',
    fps: 60,
    downloads: 41200,
    views: 310000,
    likes: 19400,
    tags: ['sports', 'basketball', 'buzzerbeater', 'clutch', 'highlights'],
    status: 'Published',
    featured: false,
    trending: true,
    createdAt: '2026-03-24T21:30:00Z',
    licenseInfo: {
      licenseId: 'LIC-2026-007',
      type: 'Syndicate Partner',
      status: 'Active',
      sourceUrl: 'https://youtube.com/watch?v=mock-buzzer-championship',
      allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts'],
      attributionRequired: false,
      expiresAt: '2027-05-20T00:00:00Z'
    }
  },
  {
    id: 'clip-8',
    slug: 'streamer-reacts-to-unreal-engine-6-demo',
    title: 'Streamer Loses Mind Over Photorealistic Physics Engine',
    description: 'Raw unedited reaction to next-gen lighting demo. High viral retention rate on TikTok and Reels.',
    thumbnail: makeThumb('%233b0764', 'Realism Engine Reaction', '%23c084fc'),
    creatorId: 'c2',
    creator: {
      id: 'c2',
      name: 'Aiden Craft',
      handle: '@aidencraft',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      verified: true
    },
    category: 'Reactions',
    duration: 36,
    durationFormatted: '0:36',
    resolution: '1080x1920 (9:16)',
    fps: 60,
    downloads: 15600,
    views: 78000,
    likes: 3100,
    tags: ['reaction', 'gaming', 'unreal', 'streamer', 'tech'],
    status: 'Published',
    featured: false,
    trending: false,
    createdAt: '2026-03-23T18:00:00Z',
    licenseInfo: {
      licenseId: 'LIC-2026-008',
      type: 'Non-Exclusive',
      status: 'Active',
      sourceUrl: 'https://twitch.tv/videos/mock-unreal-reaction',
      allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts', 'X'],
      attributionRequired: false,
      expiresAt: '2027-02-14T00:00:00Z'
    }
  },
  {
    id: 'clip-9',
    slug: 'secret-underground-minecraft-vault-entrance',
    title: 'Hidden 3x3 Seamless Redstone Vault Entrance',
    description: 'Tutorial clip demonstrating compact flush piston door. Highly shared on Minecraft TikTok channels.',
    thumbnail: makeThumb('%231e3a8a', '3x3 Redstone Vault', '%2360a5fa'),
    creatorId: 'c2',
    creator: {
      id: 'c2',
      name: 'Aiden Craft',
      handle: '@aidencraft',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      verified: true
    },
    category: 'Minecraft',
    duration: 52,
    durationFormatted: '0:52',
    resolution: '1080x1920 (9:16)',
    fps: 60,
    downloads: 29800,
    views: 147000,
    likes: 7200,
    tags: ['minecraft', 'redstone', 'tutorial', 'build', 'gaming'],
    status: 'Published',
    featured: false,
    trending: false,
    createdAt: '2026-03-22T13:40:00Z',
    licenseInfo: {
      licenseId: 'LIC-2026-009',
      type: 'Non-Exclusive',
      status: 'Expiring',
      sourceUrl: 'https://youtube.com/watch?v=mock-minecraft-vault',
      allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts'],
      attributionRequired: false,
      expiresAt: '2026-04-18T00:00:00Z'
    }
  },
  {
    id: 'clip-10',
    slug: 'why-you-must-embrace-discomfort-elena',
    title: 'Stop Waiting For Inspiration: Build The System',
    description: 'Elena Rostova on emotional regulation during difficult projects. Direct creator partnership grant.',
    thumbnail: makeThumb('%234c0519', 'Build The System', '%23f43f5e'),
    creatorId: 'c3',
    creator: {
      id: 'c3',
      name: 'Elena Rostova',
      handle: '@elenamindset',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
      verified: true
    },
    category: 'Motivation',
    duration: 41,
    durationFormatted: '0:41',
    resolution: '1080x1920 (9:16)',
    fps: 60,
    downloads: 16700,
    views: 82000,
    likes: 4100,
    tags: ['discipline', 'habits', 'inspiration', 'motivation', 'mindset'],
    status: 'Published',
    featured: false,
    trending: false,
    createdAt: '2026-03-20T08:15:00Z',
    licenseInfo: {
      licenseId: 'LIC-2026-010',
      type: 'Non-Exclusive',
      status: 'Active',
      sourceUrl: 'https://youtube.com/watch?v=mock-elena-systems',
      allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts', 'X'],
      attributionRequired: false,
      expiresAt: '2027-01-10T00:00:00Z'
    }
  },
  {
    id: 'clip-11',
    slug: 'celebrity-interview-unscripted-moment',
    title: 'When an A-List Actor Broke Character On-Air',
    description: 'Hilarious unscripted banter from behind the scenes. Licensed broadcast clip under syndicate distribution.',
    thumbnail: makeThumb('%23172554', 'Unscripted Banter', '%2338bdf8'),
    creatorId: 'c1',
    creator: {
      id: 'c1',
      name: 'Marcus Vance',
      handle: '@marcusvance',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      verified: true
    },
    category: 'Entertainment',
    duration: 27,
    durationFormatted: '0:27',
    resolution: '1080x1920 (9:16)',
    fps: 60,
    downloads: 23400,
    views: 120000,
    likes: 5600,
    tags: ['celebrity', 'interview', 'entertainment', 'funny', 'podcast'],
    status: 'Published',
    featured: false,
    trending: false,
    createdAt: '2026-03-18T16:20:00Z',
    licenseInfo: {
      licenseId: 'LIC-2026-011',
      type: 'Syndicate Partner',
      status: 'Active',
      sourceUrl: 'https://youtube.com/watch?v=mock-vance-actor',
      allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts', 'X'],
      attributionRequired: false,
      expiresAt: '2027-03-15T00:00:00Z'
    }
  },
  {
    id: 'clip-12',
    slug: 'cyberpunk-city-render-walkthrough-ai',
    title: 'Generative 3D City Simulation Rendered in Real-Time',
    description: 'Neural radiance field walkthrough of a procedural neo-tokyo metropolis. High visual engagement.',
    thumbnail: makeThumb('%23311042', 'Neural Radiance City', '%23a855f7'),
    creatorId: 'c4',
    creator: {
      id: 'c4',
      name: 'PixelForge Studios',
      handle: '@pixelforge',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      verified: true
    },
    category: 'AI',
    duration: 33,
    durationFormatted: '0:33',
    resolution: '1080x1920 (9:16)',
    fps: 60,
    downloads: 19500,
    views: 94000,
    likes: 4700,
    tags: ['ai', '3d', 'render', 'vfx', 'future'],
    status: 'Published',
    featured: false,
    trending: false,
    createdAt: '2026-03-15T12:00:00Z',
    licenseInfo: {
      licenseId: 'LIC-2026-012',
      type: 'Creative Commons (CC-BY)',
      status: 'Active',
      sourceUrl: 'https://youtube.com/watch?v=mock-nerf-city',
      allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts', 'X'],
      attributionRequired: true,
      expiresAt: '2028-01-01T00:00:00Z'
    }
  }
];

export const INITIAL_LICENSES: LicenseRecord[] = [
  {
    id: 'LIC-2026-001',
    clipId: 'clip-1',
    clipTitle: 'The Hard Truth About Flow State and Dopamine Resets',
    creatorId: 'c1',
    creatorName: 'Marcus Vance',
    sourceUrl: 'https://youtube.com/watch?v=mock-vanguard-88',
    licenseType: 'Non-Exclusive',
    status: 'Active',
    startDate: '2026-03-28',
    expiryDate: '2027-03-28',
    allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts', 'X'],
    notes: 'Direct podcast syndication contract. Verified master audio clearance.'
  },
  {
    id: 'LIC-2026-002',
    clipId: 'clip-2',
    clipTitle: 'Impossible 1-Heart Nether Portal Clutch',
    creatorId: 'c2',
    creatorName: 'Aiden Craft',
    sourceUrl: 'https://twitch.tv/videos/mock-craft-921',
    licenseType: 'Syndicate Partner',
    status: 'Active',
    startDate: '2026-03-29',
    expiryDate: '2027-06-15',
    allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts'],
    notes: 'Standard gaming stream highlight grant.'
  },
  {
    id: 'LIC-2026-003',
    clipId: 'clip-3',
    clipTitle: 'The 3-Second Rule When You Feel Like Quitting',
    creatorId: 'c3',
    creatorName: 'Elena Rostova',
    sourceUrl: 'https://youtube.com/watch?v=mock-elena-mindset-12',
    licenseType: 'Non-Exclusive',
    status: 'Active',
    startDate: '2026-03-27',
    expiryDate: '2027-01-20',
    allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts', 'X'],
    notes: 'Speech excerpt rights cleared with speaker management.'
  },
  {
    id: 'LIC-2026-009',
    clipId: 'clip-9',
    clipTitle: 'Hidden 3x3 Seamless Redstone Vault Entrance',
    creatorId: 'c2',
    creatorName: 'Aiden Craft',
    sourceUrl: 'https://youtube.com/watch?v=mock-minecraft-vault',
    licenseType: 'Non-Exclusive',
    status: 'Expiring',
    startDate: '2025-04-18',
    expiryDate: '2026-04-18',
    allowedPlatforms: ['TikTok', 'Instagram Reels', 'YouTube Shorts'],
    notes: 'Renewal notice dispatched to creator on March 25, 2026.'
  },
  {
    id: 'LIC-2025-088',
    clipId: 'clip-legacy-1',
    clipTitle: 'Legacy Tournament Grand Finals VOD snippet',
    creatorId: 'c4',
    creatorName: 'PixelForge Studios',
    sourceUrl: 'https://twitch.tv/videos/legacy-finals-2024',
    licenseType: 'Non-Exclusive',
    status: 'Expired',
    startDate: '2024-03-01',
    expiryDate: '2025-03-01',
    allowedPlatforms: ['TikTok', 'YouTube Shorts'],
    notes: 'Term lapsed. Clip removed from public browse.'
  }
];

export const INITIAL_REPORTS: CopyrightReport[] = [
  {
    id: 'REP-1042',
    clipId: 'clip-4',
    clipTitle: 'Grand Finals 1v4 Overtime Ace Reaction',
    creatorName: 'PixelForge Studios',
    reporterName: 'David Zhang',
    reporterEmail: 'rights@vanguardgaming.gg',
    reporterOrg: 'Vanguard Media Rights Ltd',
    reason: 'Misattribution',
    details: 'The caster audio commentary in the clip includes regional broadcaster audio track that requires secondary syndication credit in description.',
    status: 'Under Review',
    submittedAt: '2026-04-01T15:20:00Z'
  },
  {
    id: 'REP-1039',
    clipId: 'clip-9',
    clipTitle: 'Hidden 3x3 Seamless Redstone Vault Entrance',
    creatorName: 'Aiden Craft',
    reporterName: 'Simon K.',
    reporterEmail: 'contact@simonredstone.net',
    reason: 'Unauthorized Re-upload',
    details: 'Original redstone wiring schematic was designed on my private server. Requesting clarification on syndication permission scope.',
    status: 'Open',
    submittedAt: '2026-04-03T09:14:00Z'
  },
  {
    id: 'REP-1025',
    clipId: 'clip-1',
    clipTitle: 'The Hard Truth About Flow State and Dopamine Resets',
    creatorName: 'Marcus Vance',
    reporterName: 'Legal Desk',
    reporterEmail: 'dmca@apexnetwork.tv',
    reason: 'Copyright Infringement',
    details: 'Claimed overlap with syndicated television broadcast segment.',
    status: 'Resolved',
    submittedAt: '2026-03-12T11:00:00Z',
    resolvedAt: '2026-03-14T16:30:00Z',
    actionTaken: 'Verified direct author release; valid syndication agreement confirmed with Marcus Vance directly.'
  }
];
