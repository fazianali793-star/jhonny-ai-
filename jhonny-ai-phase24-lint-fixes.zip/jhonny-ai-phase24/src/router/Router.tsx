import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

interface RouteContextType {
  path: string;
  query: Record<string, string>;
  params: Record<string, string>;
  navigate: (to: string) => void;
}

const RouteContext = createContext<RouteContextType | undefined>(undefined);

export const RouterProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const getInitialPath = () => {
    // Check if hash is used or pathname
    const hash = window.location.hash.replace(/^#/, '');
    if (hash) {
      return hash.startsWith('/') ? hash : '/' + hash;
    }
    // Keep the query string so shared links such as /clips?page=3 keep their filters.
    return (window.location.pathname || '/') + (window.location.search || '');
  };

  const [currentPath, setCurrentPath] = useState<string>(getInitialPath);

  useEffect(() => {
    const handlePopState = () => {
      const hash = window.location.hash.replace(/^#/, '');
      if (hash) {
        setCurrentPath(hash.startsWith('/') ? hash : '/' + hash);
      } else {
        setCurrentPath((window.location.pathname || '/') + (window.location.search || ''));
      }
    };

    window.addEventListener('popstate', handlePopState);
    window.addEventListener('hashchange', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('hashchange', handlePopState);
    };
  }, []);

  const navigate = useCallback((to: string) => {
    // Standardize path
    const target = to.startsWith('/') ? to : '/' + to;
    if (window.location.hash) {
      window.location.hash = target;
    } else {
      window.history.pushState({}, '', target);
    }
    setCurrentPath(target);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  // Parse path and query
  const [pathname, search] = currentPath.split('?');
  const query: Record<string, string> = {};
  if (search) {
    const searchParams = new URLSearchParams(search);
    searchParams.forEach((val, key) => {
      query[key] = val;
    });
  }

  // Parse route parameters, e.g. /clips/:slug
  const params: Record<string, string> = {};
  const clipMatch = pathname.match(/^\/clips\/([^/?#]+)$/);
  if (clipMatch) {
    params.slug = clipMatch[1];
  }
  // e.g. /studio/projects/:id
  const projectMatch = pathname.match(/^\/studio\/projects\/([^/?#]+)$/);
  if (projectMatch) {
    params.id = projectMatch[1];
  }

  return (
    <RouteContext.Provider value={{ path: pathname, query, params, navigate }}>
      {children}
    </RouteContext.Provider>
  );
};

export const useRouter = () => {
  const context = useContext(RouteContext);
  if (!context) {
    throw new Error('useRouter must be used within a RouterProvider');
  }
  return context;
};

export const Link: React.FC<{
  href: string;
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  title?: string;
}> = ({ href, children, className = '', onClick, title }) => {
  const { navigate } = useRouter();

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    if (onClick) onClick();
    navigate(href);
  };

  return (
    <a href={href} onClick={handleClick} className={className} title={title}>
      {children}
    </a>
  );
};
