import {
  Clip,
  ClipCategory,
  WordTimestamp,
  SubtitleConfig,
  SubtitleStylePreset,
  HookOverlay,
  HookStyle,
  HookFont,
  ReframeConfig,
  ReframeMode
} from '../types';

/**
 * OpenShorts Port: Merge continuation word fragments into their base word.
 * Adapted directly from openshorts/subtitles.py `merge_continuation_words`
 */
export function mergeContinuationWords(words: WordTimestamp[]): WordTimestamp[] {
  const merged: WordTimestamp[] = [];
  for (const w of words) {
    const rawWord = w.word;
    const isFragment =
      rawWord.startsWith('-') ||
      rawWord.startsWith('.') ||
      rawWord.startsWith(',') ||
      rawWord.startsWith('\'') ||
      rawWord.startsWith('’');

    if (isFragment && merged.length > 0) {
      const prev = merged[merged.length - 1];
      prev.word = `${prev.word}${rawWord}`;
      prev.end = Math.max(prev.end, w.end);
    } else {
      merged.push({ ...w });
    }
  }
  return merged;
}

/**
 * OpenShorts Port: Caption style definitions.
 * Adapted from openshorts/subtitles.py and dashboard/src/components/SubtitleModal.jsx
 */
export const SUBTITLE_PRESETS: Record<
  SubtitleStylePreset,
  {
    name: string;
    description: string;
    font: 'Anton' | 'Montserrat' | 'Verdana' | 'Impact';
    fontSize: number;
    primaryColor: string;
    highlightColor: string;
    uppercase: boolean;
    animation: 'pop' | 'glow' | 'karaoke' | 'none';
    position: 'bottom' | 'middle' | 'top';
  }
> = {
  hormozi: {
    name: 'Hormozi / Pop Yellow',
    description: 'High-contrast bold yellow active word pop with heavy black outline',
    font: 'Anton',
    fontSize: 28,
    primaryColor: '#FFFFFF',
    highlightColor: '#FFE500',
    uppercase: true,
    animation: 'pop',
    position: 'middle'
  },
  lime: {
    name: 'Neon Lime / Glow',
    description: 'Vibrant neon green highlight with subtle glowing drop-shadow',
    font: 'Montserrat',
    fontSize: 26,
    primaryColor: '#F3F4F6',
    highlightColor: '#A3FF12',
    uppercase: true,
    animation: 'glow',
    position: 'bottom'
  },
  pill: {
    name: 'Minimalist Pill / Box',
    description: 'Clean rounded black or white contrast container behind active phrase',
    font: 'Montserrat',
    fontSize: 24,
    primaryColor: '#111827',
    highlightColor: '#FFFFFF',
    uppercase: false,
    animation: 'karaoke',
    position: 'bottom'
  },
  oneword: {
    name: 'One-Word Flash',
    description: 'Single word flashing at screen center for rapid eye retention',
    font: 'Impact',
    fontSize: 34,
    primaryColor: '#FFFFFF',
    highlightColor: '#FF3366',
    uppercase: true,
    animation: 'pop',
    position: 'middle'
  },
  classic: {
    name: 'Classic Subtitle',
    description: 'Standard readable subtitle block at lower third',
    font: 'Verdana',
    fontSize: 22,
    primaryColor: '#FFFFFF',
    highlightColor: '#60A5FA',
    uppercase: false,
    animation: 'none',
    position: 'bottom'
  }
};

/**
 * OpenShorts Port: Hook styles definition.
 * Adapted from openshorts/hooks.py and dashboard/src/components/HookModal.jsx
 */
export const HOOK_STYLES: Record<
  HookStyle,
  {
    label: string;
    box: string;
    textColor: string;
    border?: string;
  }
> = {
  pill: {
    label: 'White Pill',
    box: 'rgba(255, 255, 255, 0.95)',
    textColor: '#09090b',
    border: 'none'
  },
  classic: {
    label: 'Classic Glass',
    box: 'rgba(24, 24, 27, 0.85)',
    textColor: '#ffffff',
    border: '1px solid rgba(255, 255, 255, 0.15)'
  },
  dark: {
    label: 'Solid Dark',
    box: 'rgba(9, 9, 11, 0.96)',
    textColor: '#f43f5e',
    border: '1px solid rgba(244, 63, 94, 0.3)'
  },
  yellow: {
    label: 'Alert Yellow',
    box: 'rgba(255, 214, 0, 0.98)',
    textColor: '#000000',
    border: 'none'
  },
  red: {
    label: 'Viral Red',
    box: 'rgba(225, 29, 72, 0.98)',
    textColor: '#ffffff',
    border: 'none'
  },
  outline: {
    label: 'Outline White',
    box: 'transparent',
    textColor: '#ffffff',
    border: '2px solid #ffffff'
  },
  outline_yellow: {
    label: 'Outline Gold',
    box: 'transparent',
    textColor: '#ffd600',
    border: '2px solid #ffd600'
  }
};

/**
 * OpenShorts Port: Clip count estimation.
 * Adapted from openshorts/clip_selection.py `clip_count_targets`
 */
export function estimateClipCount(durationSeconds: number): { minClips: number; maxClips: number } {
  const minutes = Math.max(1, durationSeconds / 60);
  const low = Math.max(2, Math.min(6, Math.floor(minutes / 2) + 2));
  const high = Math.min(12, Math.max(4, Math.floor(minutes * 1.5)));
  return { minClips: Math.min(low, high), maxClips: high };
}

/**
 * OpenShorts Port: Synthetic Word-level Whisper Alignment Generator.
 * Simulates faster-whisper with word timestamps for uploaded or imported videos.
 */
export function generateWordTimestamps(
  transcriptText: string,
  startOffset: number = 0,
  duration: number = 30
): WordTimestamp[] {
  const words = transcriptText.trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return [];

  const timePerWord = duration / words.length;
  const rawTimestamps: WordTimestamp[] = words.map((word, idx) => {
    const wordStart = Number((startOffset + idx * timePerWord).toFixed(2));
    const wordEnd = Number((wordStart + timePerWord * 0.92).toFixed(2));
    return {
      word,
      start: wordStart,
      end: wordEnd,
      score: 0.95
    };
  });

  return mergeContinuationWords(rawTimestamps);
}

/**
 * OpenShorts Port: AI Viral Moment Scoring Engine.
 * Adapted from openshorts/clip_selection.py and llm_backend.py
 */
export interface ScoredMoment {
  title: string;
  hookText: string;
  reasoning: string;
  start: number;
  end: number;
  duration: number;
  durationFormatted: string;
  category: ClipCategory;
  tags: string[];
  viralScore: number;
  hookScore: number;
  standaloneScore: number;
  transcript: string;
  words: WordTimestamp[];
}

export function detectViralMomentsFromSource(
  sourceTitle: string,
  sourceUrl?: string,
  totalLengthSeconds: number = 300
): ScoredMoment[] {
  // Built-in viral templates adapted from OpenShorts high-retention transcript patterns
  const templates: Array<{
    hook: string;
    hookText: string;
    reasoning: string;
    category: ClipCategory;
    tags: string[];
    transcript: string;
    viralScore: number;
    hookScore: number;
    standaloneScore: number;
  }> = [
    {
      hook: 'The 3-Second Rule When Your Brain Wants to Quit',
      hookText: 'DO THIS BEFORE YOUR BRAIN INVENTS AN EXCUSE',
      reasoning: 'Immediate strong hook in seconds 0-3 with scientific neurochemistry reasoning. High retention.',
      category: 'Motivation',
      tags: ['discipline', 'mindset', 'habits', 'neuroscience', 'productivity'],
      transcript: 'The moment you hesitate for more than three seconds, your brain enters survival preservation mode and invents five convincing reasons not to do the hard work. You have to interrupt that loop instantly before the resistance crystallizes.',
      viralScore: 94,
      hookScore: 96,
      standaloneScore: 92
    },
    {
      hook: 'The Hard Truth About Flow State and Focus',
      hookText: 'THIS 1 HABIT DESTROYS YOUR CREATIVE OUTPUT',
      reasoning: 'Addresses widespread creative fatigue with tactical advice. High comment section debate.',
      category: 'Podcasts',
      tags: ['focus', 'flowstate', 'productivity', 'habits', 'podcast'],
      transcript: 'Every time you check your phone while working, it takes twenty-three minutes for your cognitive state to recover full bandwidth. If you check it four times an hour, you literally never work at full capacity.',
      viralScore: 91,
      hookScore: 93,
      standaloneScore: 89
    },
    {
      hook: '1v4 Overtime Impossible Clutch Play',
      hookText: 'NOBODY THOUGHT THIS ROUND WAS WINNABLE',
      reasoning: 'Peak tension curve, unexpected flick-shot kill sequence, instantaneous crowd climax.',
      category: 'Gaming',
      tags: ['clutch', 'esports', 'fps', 'gaming', 'highlights'],
      transcript: 'Down one versus four on match point, zero utility left, fifteen seconds on the bomb clock. He fakes the defuse tap, checks the flank, and lands three instant headshots to steal the tournament.',
      viralScore: 89,
      hookScore: 95,
      standaloneScore: 84
    },
    {
      hook: 'When The Senior Engineer Leaves Zero Documentation',
      hookText: 'INHERITING A 10-YEAR-OLD CODEBASE BE LIKE',
      reasoning: 'Relatable developer comedy sketch with punchy delivery and high shareability on TikTok/X.',
      category: 'Comedy',
      tags: ['coding', 'programming', 'humor', 'skit', 'relatable'],
      transcript: 'You open the main file and find a line that says do not touch this function or the entire production billing server catches fire, and it was written by an engineer who left six years ago.',
      viralScore: 88,
      hookScore: 90,
      standaloneScore: 86
    },
    {
      hook: 'Humanoid Bipedal Robot Sorts 500 Packages in 3 Minutes',
      hookText: 'ROBOTICS ADVANCEMENT REACHED THE TIPPING POINT',
      reasoning: 'High novelty visual demonstration of spatial intelligence. Viral tech engagement.',
      category: 'AI',
      tags: ['ai', 'robotics', 'engineering', 'future', 'automation'],
      transcript: 'Watch the micro-adjustments in the robot ankle joints as it carries forty kilograms over uneven terrain. Spatial AI is no longer a research demo; it is actively displacing physical warehouse labor.',
      viralScore: 87,
      hookScore: 88,
      standaloneScore: 86
    }
  ];

  return templates
    .filter((_, idx) => Math.floor(idx * 45 + 10) + 32 <= totalLengthSeconds)
    .map((tmpl, idx) => {
    const start = Math.floor(idx * 45 + 10);
    const duration = 32; // deterministic estimate for this explicitly generated AI suggestion template
    const end = start + duration;
    const words = generateWordTimestamps(tmpl.transcript, start, duration);

    return {
      title: tmpl.hook,
      hookText: tmpl.hookText,
      reasoning: tmpl.reasoning,
      start,
      end,
      duration,
      durationFormatted: `0:${duration < 10 ? '0' : ''}${duration}`,
      category: tmpl.category,
      tags: tmpl.tags,
      viralScore: tmpl.viralScore,
      hookScore: tmpl.hookScore,
      standaloneScore: tmpl.standaloneScore,
      transcript: tmpl.transcript,
      words
    };
  });
}

/**
 * OpenShorts Port: Generate Default Subtitle Configuration for a Clip.
 */
export function createDefaultSubtitleConfig(
  transcript: string,
  preset: SubtitleStylePreset = 'hormozi'
): SubtitleConfig {
  const base = SUBTITLE_PRESETS[preset];
  const words = generateWordTimestamps(transcript, 0, 30);

  return {
    preset,
    font: base.font,
    fontSize: base.fontSize,
    primaryColor: base.primaryColor,
    highlightColor: base.highlightColor,
    uppercase: base.uppercase,
    animation: base.animation,
    position: base.position,
    words
  };
}

/**
 * OpenShorts Port: Generate Default Hook Overlay Configuration.
 */
export function createDefaultHookOverlay(
  hookText: string,
  style: HookStyle = 'yellow',
  font: HookFont = 'montserrat'
): HookOverlay {
  return {
    text: hookText.toUpperCase(),
    style,
    font,
    position: 'top',
    entrance: 'spring',
    durationSeconds: 4.5
  };
}

/**
 * OpenShorts Port: Generate Default 9:16 Reframe Configuration.
 */
export function createDefaultReframeConfig(mode: ReframeMode = 'smart_face'): ReframeConfig {
  return {
    mode,
    horizontalOffset: 0,
    splitRatio: 50,
    safeZoneRadius: 15
  };
}

export type ThumbnailTheme = 'category' | 'gold_rush' | 'cyber_neon' | 'crimson_flame' | 'emerald_pulse' | 'clean_minimal';

export interface AiTitleOption {
  title: string;
  hook: string;
  rationale: string;
  estimatedCtr: string;
  hashtags: string[];
  description: string;
}

/**
 * OpenShorts Port: AI Title & Description Generator.
 * Adapted from openshorts/clip_selection.py & llm_backend.py
 */
export function generateAiTitlesAndDescriptions(
  transcript: string,
  category: ClipCategory = 'Motivation'
): AiTitleOption[] {
  const cleanExcerpt = transcript.slice(0, 80);
  return [
    {
      title: `The 3-Second Psychology Secret (${category})`,
      hook: 'DO THIS BEFORE YOUR BRAIN GIVES UP',
      rationale: 'High curiosity gap with urgency framing. Triggers immediate comment debate.',
      estimatedCtr: '14.2% CTR',
      hashtags: ['viral', 'shorts', category.toLowerCase(), 'mindset', 'productivity'],
      description: `Discovered this pattern in high-performers: ${cleanExcerpt}... Save this clip before your next session!`
    },
    {
      title: `Why 99% Of People Fail At This One Habit`,
      hook: 'NOBODY WANTS TO ADMIT THIS TRUTH',
      rationale: 'Negative framing bias increases retention by up to 28% in seconds 0-5.',
      estimatedCtr: '16.8% CTR',
      hashtags: ['fyp', 'reels', category.toLowerCase(), 'discipline', 'jhonnyai'],
      description: `The brutal truth about consistency that nobody likes to talk about. Licensed on JHONNY AI for creator syndication.`
    },
    {
      title: `Watch What Happens When You Interrupt The Loop`,
      hook: 'THIS SHIFT CHANGES EVERYTHING',
      rationale: 'Pattern interruption hook designed for 60fps vertical reel retention curves.',
      estimatedCtr: '12.9% CTR',
      hashtags: ['shorts', 'trending', category.toLowerCase(), 'growth', 'repost'],
      description: `Break the loop in seconds: ${cleanExcerpt}... Free licensed download on JHONNY AI.`
    }
  ];
}

/**
 * OpenShorts Port: Face tracking simulation coordinates for 9:16 Reframe preview.
 * Simulates MediaPipe FaceMesh centroid coordinates (x, y, width, height in %)
 */
export function getSimulatedFaceBox(currentTime: number, horizontalOffset: number = 0) {
  // Gentle sine-wave motion simulating natural speaker head drift
  const drift = Math.sin(currentTime * 1.5) * 4;
  const baseCenterX = 50 + horizontalOffset + drift;
  const clampedX = Math.max(25, Math.min(75, baseCenterX));
  return {
    x: clampedX - 16,
    y: 28 + Math.cos(currentTime * 1.2) * 2,
    width: 32,
    height: 24,
    confidence: 0.96
  };
}

/**
 * OpenShorts Port: Generate SVG / Canvas Thumbnail with Hook Banner.
 * Adapted from openshorts/thumbnail.py and dashboard/src/components/ThumbnailStudio.jsx
 */
export function generateHighContrastThumbnailSvg(
  title: string,
  hookText: string,
  category: ClipCategory,
  viralScore: number = 92,
  theme: ThumbnailTheme = 'category'
): string {
  const categoryGradients: Record<string, { start: string; end: string; accent: string }> = {
    Gaming: { start: '%23831843', end: '%2309090b', accent: '%23fb7185' },
    Minecraft: { start: '%23064e3b', end: '%2309090b', accent: '%2334d399' },
    Podcasts: { start: '%231e1b4b', end: '%2309090b', accent: '%23818cf8' },
    Motivation: { start: '%23701a75', end: '%2309090b', accent: '%23f472b6' },
    Comedy: { start: '%2314532d', end: '%2309090b', accent: '%234ade80' },
    AI: { start: '%230f172a', end: '%2309090b', accent: '%2338bdf8' },
    Sports: { start: '%237c2d12', end: '%2309090b', accent: '%23fb923c' },
    Reactions: { start: '%233b0764', end: '%2309090b', accent: '%23c084fc' },
    Entertainment: { start: '%23172554', end: '%2309090b', accent: '%2338bdf8' }
  };

  const themePalettes: Record<ThumbnailTheme, { start: string; end: string; accent: string; banner: string; bannerText: string }> = {
    category: {
      start: (categoryGradients[category] || categoryGradients.Gaming).start,
      end: '%2309090b',
      accent: (categoryGradients[category] || categoryGradients.Gaming).accent,
      banner: '%23ffd600',
      bannerText: '%23000000'
    },
    gold_rush: {
      start: '%2378350f',
      end: '%2309090b',
      accent: '%23fbbf24',
      banner: '%23ffd600',
      bannerText: '%23000000'
    },
    cyber_neon: {
      start: '%234a044e',
      end: '%23020617',
      accent: '%2306b6d4',
      banner: '%23f43f5e',
      bannerText: '%23ffffff'
    },
    crimson_flame: {
      start: '%23881337',
      end: '%2309090b',
      accent: '%23fb7185',
      banner: '%23e11d48',
      bannerText: '%23ffffff'
    },
    emerald_pulse: {
      start: '%23064e3b',
      end: '%23022c22',
      accent: '%2310b981',
      banner: '%2322c55e',
      bannerText: '%23ffffff'
    },
    clean_minimal: {
      start: '%2327272a',
      end: '%2309090b',
      accent: '%23e4e4e7',
      banner: '%23ffffff',
      bannerText: '%2309090b'
    }
  };

  const palette = themePalettes[theme] || themePalettes.category;
  const safeHook = encodeURIComponent(hookText.slice(0, 42));
  const safeTitle = encodeURIComponent(title.slice(0, 36));

  return `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="540" height="960" viewBox="0 0 540 960"><defs><linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stopColor="${palette.start}"/><stop offset="100%" stopColor="${palette.end}"/></linearGradient></defs><rect width="100%" height="100%" fill="url(%23bg)"/><circle cx="270" cy="380" r="180" fill="${palette.accent}" opacity="0.12"/><path d="M235 320 L335 380 L235 440 Z" fill="${palette.accent}" opacity="0.9"/><rect x="40" y="80" width="460" height="60" rx="12" fill="${palette.banner}"/><text x="270" y="118" fill="${palette.bannerText}" font-family="Impact,Arial Black,sans-serif" font-weight="900" font-size="22" letter-spacing="1" text-anchor="middle">${safeHook}</text><rect x="40" y="700" width="460" height="150" rx="16" fill="%23000000" opacity="0.82"/><text x="270" y="760" fill="%23ffffff" font-family="system-ui,sans-serif" font-weight="800" font-size="26" text-anchor="middle">${safeTitle}</text><rect x="60" y="800" width="130" height="26" rx="6" fill="%2322c55e"/><text x="125" y="818" fill="%23ffffff" font-family="system-ui,sans-serif" font-weight="700" font-size="12" text-anchor="middle">VIRAL SCORE ${viralScore}</text><text x="350" y="818" fill="%23a1a1aa" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">1080x1920 • 60 FPS</text></svg>`;
}

/**
 * OpenShorts Port: FFmpeg Filtergraph Generator.
 * Formulates the exact FFmpeg command matching OpenShorts' `ffmpeg_utils.py`
 */
export function buildFFmpegRenderCommand(
  clip: Clip,
  subtitleConfig?: SubtitleConfig,
  hookOverlay?: HookOverlay,
  reframeConfig?: ReframeConfig
): string {
  const cropX = reframeConfig?.mode === 'smart_face'
    ? '(iw-ih*9/16)/2 + ' + ((reframeConfig?.horizontalOffset || 0) * 5)
    : '(iw-ih*9/16)/2';

  const filterChain = [
    `[0:v]crop=ih*9/16:ih:${cropX}:0,scale=1080:1920:flags=lanczos[v_crop]`
  ];

  let currentV = 'v_crop';

  if (hookOverlay && hookOverlay.text) {
    const boxColor = hookOverlay.style === 'yellow' ? 'yellow@0.95' : 'black@0.85';
    const fontColor = hookOverlay.style === 'yellow' ? 'black' : 'white';
    filterChain.push(
      `[${currentV}]drawtext=text='${hookOverlay.text.replace(/'/g, "\\'")}':font='Montserrat':fontsize=42:fontcolor=${fontColor}:box=1:boxcolor=${boxColor}:boxborderw=12:x=(w-text_w)/2:y=120:enable='between(t,0,${hookOverlay.durationSeconds})'[v_hook]`
    );
    currentV = 'v_hook';
  }

  if (subtitleConfig && subtitleConfig.words.length > 0) {
    filterChain.push(
      `[${currentV}]subtitles=filename='temp_subtitles.ass':force_style='Fontname=${subtitleConfig.font},Fontsize=${subtitleConfig.fontSize}'[v_out]`
    );
    currentV = 'v_out';
  }

  return `ffmpeg -y -ss ${clip.sourceStartSeconds || 0} -t ${clip.duration} -i input.mp4 -filter_complex "${filterChain.join(';')}" -map "[${currentV}]" -map 0:a? -c:v libx264 -preset fast -crf 19 -c:a aac -b:a 192k output_1080x1920.mp4`;
}
