export type ClipCategory =
  | 'Gaming'
  | 'Minecraft'
  | 'Podcasts'
  | 'Motivation'
  | 'Comedy'
  | 'Reactions'
  | 'Sports'
  | 'AI'
  | 'Entertainment';

export type ClipStatus = 'Published' | 'Pending' | 'Processing' | 'Disabled' | 'Takedown';

export type LicenseType = 'Exclusive' | 'Non-Exclusive' | 'Syndicate Partner' | 'Creative Commons (CC-BY)';

export type LicenseStatus = 'Active' | 'Expiring' | 'Expired' | 'Revoked' | 'Pending Review';

export type ReportStatus = 'Open' | 'Under Review' | 'Resolved' | 'Rejected';

// OpenShorts Subtitle & Caption Presets
export type SubtitleStylePreset = 'hormozi' | 'lime' | 'pill' | 'oneword' | 'classic';

export interface WordTimestamp {
  word: string;
  start: number; // in seconds
  end: number;   // in seconds
  score?: number;
}

export interface SubtitleConfig {
  preset: SubtitleStylePreset;
  font: 'Anton' | 'Montserrat' | 'Verdana' | 'Impact';
  fontSize: number;
  primaryColor: string;
  highlightColor: string;
  uppercase: boolean;
  animation: 'pop' | 'glow' | 'karaoke' | 'none';
  position: 'bottom' | 'middle' | 'top';
  words: WordTimestamp[];
}

export type HookStyle = 'pill' | 'classic' | 'dark' | 'yellow' | 'red' | 'outline' | 'outline_yellow';
export type HookFont = 'montserrat' | 'anton' | 'serif';

export interface HookOverlay {
  text: string;
  style: HookStyle;
  font: HookFont;
  position: 'top' | 'middle' | 'bottom';
  entrance: 'spring' | 'fade' | 'slide-up' | 'none';
  durationSeconds: number;
}

export type ReframeMode = 'smart_face' | 'center' | 'split_stacked' | 'manual';

export interface ReframeConfig {
  mode: ReframeMode;
  horizontalOffset: number; // -50 to +50 percent
  splitRatio?: number;      // 50/50 for stacked split
  safeZoneRadius?: number;
}

export interface ProcessingJob {
  id: string;
  sourceTitle: string;
  sourceUrl?: string;
  fileSize?: string;
  status:
    | 'queued'
    | 'transcribing'
    | 'detecting_moments'
    | 'reframing'
    | 'generating_captions'
    | 'generating_thumbnails'
    | 'completed'
    | 'failed';
  progress: number; // 0 to 100
  currentStepText: string;
  viralMomentsFound: number;
  generatedClips: Clip[];
  createdAt: string;
  creatorId: string;
}

export interface Creator {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  bio: string;
  verified: boolean;
  totalClips: number;
  totalDownloads: number;
  channels: {
    youtube?: string;
    tiktok?: string;
    instagram?: string;
    twitch?: string;
  };
  joinedDate: string;
  status: 'Active' | 'Under Review' | 'Suspended';
}

export interface Clip {
  id: string;
  slug: string;
  title: string;
  description: string;
  thumbnail: string;
  previewVideoUrl?: string; // Optional video asset or canvas fallback
  mediaUrl?: string;        // Server-issued, short-lived signed URL for the licensed file. Absent = not downloadable.
  creatorId: string;
  creator: {
    id: string;
    name: string;
    handle: string;
    avatar: string;
    verified: boolean;
  };
  category: ClipCategory;
  duration: number; // in seconds
  durationFormatted: string; // e.g. "0:42"
  resolution: string; // e.g. "1080x1920 (9:16)"
  fps: number;
  downloads: number;
  views: number;
  likes: number;
  tags: string[];
  status: ClipStatus;
  featured?: boolean;
  trending?: boolean;
  createdAt: string;

  // OpenShorts Enhanced Metadata
  viralScore?: number;        // 0-100 viral hook prediction
  reasoning?: string;         // AI explanation for clip selection
  hookText?: string;          // Viral hook line
  hookOverlay?: HookOverlay;  // Rendered visual hook banner
  subtitles?: SubtitleConfig; // Synced word-level captions
  reframe?: ReframeConfig;    // 9:16 crop & face tracking configuration
  sourceStartSeconds?: number;
  sourceEndSeconds?: number;
  youtubeSourceUrl?: string;

  licenseInfo: {
    licenseId: string;
    type: LicenseType;
    status: LicenseStatus;
    sourceUrl: string;
    allowedPlatforms: string[];
    attributionRequired: boolean;
    expiresAt: string;
  };
}

export interface LicenseRecord {
  id: string;
  clipId: string;
  clipTitle: string;
  creatorId: string;
  creatorName: string;
  sourceUrl: string;
  licenseType: LicenseType;
  status: LicenseStatus;
  startDate: string;
  expiryDate: string;
  allowedPlatforms: string[];
  notes?: string;
}

export interface CopyrightReport {
  id: string;
  clipId: string;
  clipTitle: string;
  creatorName: string;
  reporterName: string;
  reporterEmail: string;
  reporterOrg?: string;
  reason: 'Copyright Infringement' | 'Unauthorized Re-upload' | 'Misattribution' | 'Defamation' | 'Other';
  details: string;
  status: ReportStatus;
  submittedAt: string;
  resolvedAt?: string;
  actionTaken?: string;
}

export interface UserDownloadRecord {
  id: string;
  clipId: string;
  clipTitle: string;
  thumbnail: string;
  category: ClipCategory;
  downloadedAt: string;
  durationFormatted: string;
  fileSize: string;
}

export interface UserAccount {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'creator' | 'admin';
  avatar: string;
  creatorId?: string;
  socialLinks?: {
    youtube?: string;
    tiktok?: string;
    instagram?: string;
  };
}

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  type?: 'success' | 'info' | 'warning' | 'error';
}
