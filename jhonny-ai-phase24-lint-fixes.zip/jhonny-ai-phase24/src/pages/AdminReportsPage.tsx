import React from 'react';
import { AdminLiveDataPage } from './AdminLiveDataPage';
export const AdminReportsPage: React.FC = () => <AdminLiveDataPage section="reports" />;
