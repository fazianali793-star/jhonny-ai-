import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { useRouter, Link } from '../router/Router';
import { StatCard } from '../components/common/StatCard';
import { StatusBadge } from '../components/common/StatusBadge';
import { UploadModal } from '../components/creator/UploadModal';
import { CreatorSubmissionsPanel } from '../components/common/Phase4BackendPanels';
import { Video, Download, DollarSign, ShieldCheck, Plus, Sparkles } from 'lucide-react';

const LegacyCreatorDashboardPage: React.FC = () => {
  const { clips, currentUser, licenses, openAiPipelineModal } = useApp();
  const { path } = useRouter();
  const [uploadModalOpen, setUploadModalOpen] = useState(false);

  // Filter clips belonging to current creator (or default to Marcus Vance c1)
  const creatorId = currentUser?.creatorId || 'c1';
  const creatorClips = clips.filter(c => c.creatorId === creatorId || c.creator.name === currentUser?.name);
  const totalDownloads = creatorClips.reduce((acc, c) => acc + c.downloads, 0);
  const activeLicenses = licenses.filter(l => l.creatorId === creatorId || l.creatorName === currentUser?.name);

  // Mock earnings: ~$12.50 per 1000 downloads through platform advertising pool
  const estimatedEarnings = ((totalDownloads * 11.8) / 1000).toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD'
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Creator Portal Sub-Navigation Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-4 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Creator Portal</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20">
              Verified Partner
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-1">
            Manage your syndicated short-form clips, license agreements, and ad revenue share
          </p>
        </div>

        {/* Actions: AI Pipeline and Upload Video */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={openAiPipelineModal}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-rose-400 hover:text-rose-300 border border-neutral-800 hover:border-neutral-700 text-xs font-semibold shadow-md transition-all active:scale-95"
          >
            <Sparkles className="w-4 h-4" />
            <span>AI Auto-Clip Pipeline</span>
          </button>
          <button
            onClick={() => setUploadModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-semibold shadow-md transition-all active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Upload Licensed Clip</span>
          </button>
        </div>
      </div>

      {/* Creator Navigation Tabs */}
      <div className="flex items-center gap-2 mb-8 border-b border-neutral-800/80 pb-3 text-xs font-semibold">
        <Link
          href="/creator"
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            path === '/creator'
              ? 'bg-neutral-800 text-white'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
          }`}
        >
          Overview
        </Link>
        <Link
          href="/creator/content"
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            path === '/creator/content'
              ? 'bg-neutral-800 text-white'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
          }`}
        >
          Content Library ({creatorClips.length})
        </Link>
        <Link
          href="/creator/licenses"
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            path === '/creator/licenses'
              ? 'bg-neutral-800 text-white'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
          }`}
        >
          Rights & Licenses
        </Link>
        <Link
          href="/creator/earnings"
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            path === '/creator/earnings'
              ? 'bg-neutral-800 text-white'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
          }`}
        >
          Ad Revenue Share
        </Link>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard
          label="Total Published Clips"
          value={creatorClips.length}
          change="+1 this week"
          trend="up"
          icon={Video}
          description="9:16 vertical short format"
        />
        <StatCard
          label="Total Downloads"
          value={totalDownloads.toLocaleString()}
          change="+14.2% velocity"
          trend="up"
          icon={Download}
          description="Downloader social syndication"
        />
        <StatCard
          label="Estimated Ad Share"
          value={estimatedEarnings}
          change="+8.4% this month"
          trend="up"
          icon={DollarSign}
          description="Phase 1 sponsor ad pool"
        />
        <StatCard
          label="Active Licenses"
          value={activeLicenses.length}
          trend="neutral"
          icon={ShieldCheck}
          description="100% compliant contracts"
        />
      </div>

      {/* Performance Chart & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-8">
        {/* SVG Performance Chart (8 cols) */}
        <div className="lg:col-span-8 bg-neutral-900/60 rounded-xl border border-neutral-800 p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-semibold text-sm text-neutral-100">
                Daily Syndication Downloads & Traffic
              </h3>
              <p className="text-xs text-neutral-400">
                Track how third-party publishers are downloading your clips
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs font-mono text-neutral-400">
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500" /> Downloads
              </span>
            </div>
          </div>

          {/* SVG Smooth Line / Bar Chart */}
          <div className="h-56 w-full pt-4 relative">
            <svg className="w-full h-full" viewBox="0 0 700 200" preserveAspectRatio="none">
              <defs>
                <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#f43f5e" stopOpacity="0.0" />
                </linearGradient>
              </defs>
              {/* Grid lines */}
              <line x1="0" y1="40" x2="700" y2="40" stroke="#262626" strokeDasharray="3 3" />
              <line x1="0" y1="90" x2="700" y2="90" stroke="#262626" strokeDasharray="3 3" />
              <line x1="0" y1="140" x2="700" y2="140" stroke="#262626" strokeDasharray="3 3" />
              <line x1="0" y1="190" x2="700" y2="190" stroke="#262626" />

              {/* Area */}
              <polygon
                points="0,180 50,160 110,135 170,145 230,110 290,95 350,115 410,75 470,85 530,55 590,65 650,35 700,20 700,190 0,190"
                fill="url(#chartGrad)"
              />
              {/* Line */}
              <polyline
                points="0,180 50,160 110,135 170,145 230,110 290,95 350,115 410,75 470,85 530,55 590,65 650,35 700,20"
                fill="none"
                stroke="#f43f5e"
                strokeWidth="3"
                strokeLinecap="round"
              />
              {/* Highlight point */}
              <circle cx="700" cy="20" r="5" fill="#f43f5e" stroke="#ffffff" strokeWidth="2" />
            </svg>
          </div>

          <div className="flex items-center justify-between text-[11px] text-neutral-500 font-mono pt-2">
            <span>Mar 22</span>
            <span>Mar 25</span>
            <span>Mar 28</span>
            <span>Mar 31</span>
            <span>Apr 03</span>
            <span>Today (Peak 4.8k dls)</span>
          </div>
        </div>

        {/* Quick Upload / Guidelines Box (4 cols) */}
        <div className="lg:col-span-4 bg-neutral-900/60 rounded-xl border border-neutral-800 p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-rose-400" />
              <h3 className="font-semibold text-sm text-neutral-100">
                Licensing Standards
              </h3>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed mb-4">
              JHONNY AI only accepts authorized content. Make sure:
            </p>
            <ul className="space-y-2 text-xs text-neutral-300">
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">✓</span>
                <span>You own or hold explicit written syndication rights.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">✓</span>
                <span>Background music is royalty-free or master cleared.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">✓</span>
                <span>Allowed platforms specify Reels, Shorts, and TikTok.</span>
              </li>
            </ul>
          </div>

          <div className="pt-6 border-t border-neutral-800">
            <button
              onClick={() => setUploadModalOpen(true)}
              className="w-full py-2.5 rounded-lg bg-neutral-800 hover:bg-neutral-750 text-xs font-semibold text-neutral-200 border border-neutral-700 flex items-center justify-center gap-2 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Submit New Video Clip</span>
            </button>
          </div>
        </div>
      </div>

      {/* Recent Clips Table */}
      <div className="bg-neutral-900/60 rounded-xl border border-neutral-800 overflow-hidden">
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between">
          <h3 className="font-semibold text-sm text-neutral-100">Your Recent Content</h3>
          <Link
            href="/creator/content"
            className="text-xs font-medium text-rose-400 hover:text-rose-300 transition-colors"
          >
            Manage all content →
          </Link>
        </div>

        <div className="divide-y divide-neutral-800">
          {creatorClips.slice(0, 4).map((clip, idx) => (
            <div
              key={`${clip.id}-${idx}`}
              className="p-4 sm:px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-neutral-900/40 transition-colors"
            >
              <div className="flex items-center gap-4">
                <img
                  src={clip.thumbnail}
                  alt=""
                  className="w-12 h-16 rounded-lg object-cover bg-neutral-950 shrink-0 border border-neutral-800"
                />
                <div>
                  <h4 className="font-medium text-xs sm:text-sm text-neutral-100 line-clamp-1 mb-1">
                    {clip.title}
                  </h4>
                  <div className="flex items-center gap-2 text-[11px] text-neutral-400 font-mono">
                    <span>{clip.category}</span>
                    <span>·</span>
                    <span>{clip.durationFormatted}</span>
                    <span>·</span>
                    <span>{clip.downloads.toLocaleString()} downloads</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3 self-end sm:self-center">
                <StatusBadge status={clip.status} />
                <Link
                  href={`/clips/${clip.slug}`}
                  className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-neutral-200 border border-neutral-700"
                >
                  Preview
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Upload Modal Component */}
      <UploadModal
        isOpen={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
      />
    </div>
  );
};


export const CreatorDashboardPage: React.FC = () => import.meta.env.DEV ? <LegacyCreatorDashboardPage /> : <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-white"><div className="flex flex-wrap items-center justify-between gap-3 mb-6"><div><h1 className="text-2xl font-bold">Creator Portal</h1><p className="text-sm text-neutral-400 mt-1">Live server submissions; financial and advanced editing features are not represented as connected.</p></div><nav className="flex gap-2 text-xs"><Link href="/creator/content" className="rounded-lg border border-neutral-700 px-3 py-2">Content</Link><Link href="/creator/licenses" className="rounded-lg border border-neutral-700 px-3 py-2">Licenses</Link><Link href="/creator/earnings" className="rounded-lg border border-neutral-700 px-3 py-2">Earnings status</Link></nav></div><CreatorSubmissionsPanel /><div role="note" className="mt-4 rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 text-sm text-amber-200">Creator earnings, payment preferences, and payout scheduling are not backed by a financial service in this build. No financial figures are shown here as real account data.</div></main>;
