import React from 'react';
import { Lock } from 'lucide-react';

export const PrivacyPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <div className="inline-flex items-center gap-1.5 text-xs font-mono text-neutral-400 mb-2">
          <Lock className="w-4 h-4 text-emerald-400" />
          <span>Privacy & Data Protection · Updated April 2026</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white tracking-tight">Privacy Policy</h1>
        <p className="text-xs text-neutral-400 mt-1">
          How JHONNY AI collects, uses, and safeguards publisher and creator information
        </p>
      </div>

      <div className="bg-neutral-900/40 rounded-2xl border border-neutral-800 p-6 sm:p-8 space-y-6 text-xs text-neutral-300 leading-relaxed">
        <section>
          <h2 className="text-sm font-bold text-white mb-2">1. Information We Collect</h2>
          <p>
            We collect account registration data (name, email address, connected public channel handles), usage data (clips viewed, previews played, packages downloaded), and creator licensing submission information (source broadcast URLs, legal contact info).
          </p>
        </section>

        <section>
          <h2 className="text-sm font-bold text-white mb-2">2. How We Use Information</h2>
          <p>
            Your information is used exclusively to facilitate clip syndication, maintain license verification records, distribute ad-supported creator revenue shares, and administer copyright compliance inquiries.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-bold text-white mb-2">3. Website Advertising & Analytics</h2>
          <p>
            JHONNY AI relies on website advertising to keep all clip downloads free and watermark-free for publishers. We do not sell your personal identifying data to third-party data brokers.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-bold text-white mb-2">4. Rights Audit Ledger</h2>
          <p>
            To provide continuous legal clearance assurance for downloaders, licensing agreements and creator grants are maintained in our permanent audit registry.
          </p>
        </section>
      </div>
    </div>
  );
};
