import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { isPublicClip } from '../lib/rights';
import { useRouter, Link } from '../router/Router';
import { ClipCard } from '../components/common/ClipCard';
import { CreatorCard } from '../components/common/CreatorCard';
import { EmptyState } from '../components/common/EmptyState';
import { Search, Video, Users, Tag, ArrowRight } from 'lucide-react';
import { CATEGORIES } from '../data/mockData';
import { BackendLibraryPanel } from '../components/common/Phase4BackendPanels';

export const SearchPage: React.FC = () => {
  const { clips, creators } = useApp();
  const { query } = useRouter();

  const [searchTerm, setSearchTerm] = useState(query.q || '');
  const [activeTab, setActiveTab] = useState<'all' | 'clips' | 'creators' | 'categories'>('all');

  const publishedClips = useMemo(() => clips.filter(c => isPublicClip(c)), [clips]);

  const searchResults = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) {
      return {
        clips: publishedClips.slice(0, 6),
        creators: creators.slice(0, 3),
        categories: CATEGORIES.slice(0, 4)
      };
    }

    const matchedClips = publishedClips.filter(c => {
      return (
        c.title.toLowerCase().includes(q) ||
        c.creator.name.toLowerCase().includes(q) ||
        c.category.toLowerCase().includes(q) ||
        c.tags.some(t => t.toLowerCase().includes(q))
      );
    });

    const matchedCreators = creators.filter(cr => {
      return (
        cr.name.toLowerCase().includes(q) ||
        cr.handle.toLowerCase().includes(q) ||
        cr.bio.toLowerCase().includes(q)
      );
    });

    const matchedCategories = CATEGORIES.filter(cat =>
      cat.toLowerCase().includes(q)
    );

    return {
      clips: matchedClips,
      creators: matchedCreators,
      categories: matchedCategories
    };
  }, [searchTerm, publishedClips, creators]);

  const totalResults =
    searchResults.clips.length + searchResults.creators.length + searchResults.categories.length;

  // The legacy search indexes browser-local demo creators and clips. Never present it as production data.
  if (!import.meta.env.DEV) {
    return <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8"><h1 className="text-2xl font-extrabold text-white mb-2">Search JHONNY AI</h1><p className="text-sm text-neutral-400 mb-6">Search published server-backed clips. Creator/category directory search is not yet connected.</p><BackendLibraryPanel /></main>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Search Header */}
      <div className="max-w-3xl mx-auto mb-8 text-center">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mb-2">
          Search JHONNY AI
        </h1>
        <p className="text-xs sm:text-sm text-neutral-400 mb-6">
          Find permission-cleared clips, creator channels, and category channels
        </p>

        {/* Large Search Input */}
        <div className="relative">
          <Search className="w-5 h-5 text-neutral-400 absolute left-4 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search keywords, e.g. Minecraft clutch, Podcast focus, Gaming..."
            className="w-full pl-12 pr-4 py-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-rose-500 shadow-xl transition-all"
            autoFocus
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-neutral-400 hover:text-white"
            >
              Clear
            </button>
          )}
        </div>

        {/* Suggested Quick Searches */}
        <div className="flex flex-wrap items-center justify-center gap-2 mt-3 text-xs text-neutral-400">
          <span className="text-neutral-500">Popular:</span>
          {['Minecraft', 'Flow State', 'Buzzer Beater', 'Dev Humor', 'Overtime Ace'].map((s) => (
            <button
              key={s}
              onClick={() => setSearchTerm(s)}
              className="px-2.5 py-1 rounded-full bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-800 text-xs transition-colors"
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center justify-center border-b border-neutral-800 mb-8">
        <div className="flex gap-4 sm:gap-8 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('all')}
            className={`pb-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'all'
                ? 'border-rose-500 text-white'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <span>All Results</span>
            <span className="font-mono text-[10px] text-neutral-500">({totalResults})</span>
          </button>
          <button
            onClick={() => setActiveTab('clips')}
            className={`pb-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'clips'
                ? 'border-rose-500 text-white'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Video className="w-3.5 h-3.5" />
            <span>Clips</span>
            <span className="font-mono text-[10px] text-neutral-500">
              ({searchResults.clips.length})
            </span>
          </button>
          <button
            onClick={() => setActiveTab('creators')}
            className={`pb-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'creators'
                ? 'border-rose-500 text-white'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Creators</span>
            <span className="font-mono text-[10px] text-neutral-500">
              ({searchResults.creators.length})
            </span>
          </button>
          <button
            onClick={() => setActiveTab('categories')}
            className={`pb-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'categories'
                ? 'border-rose-500 text-white'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Tag className="w-3.5 h-3.5" />
            <span>Categories</span>
            <span className="font-mono text-[10px] text-neutral-500">
              ({searchResults.categories.length})
            </span>
          </button>
        </div>
      </div>

      {/* Empty State */}
      {totalResults === 0 ? (
        <EmptyState
          icon={Search}
          title={`No results found for "${searchTerm}"`}
          description="Try searching for another topic like 'Podcast', 'Minecraft', or 'Motivation', or clear your search query."
          actionLabel="Clear Search"
          onAction={() => setSearchTerm('')}
        />
      ) : (
        <div className="space-y-12">
          {/* Categories matches */}
          {(activeTab === 'all' || activeTab === 'categories') && searchResults.categories.length > 0 && (
            <section>
              <h2 className="text-sm font-semibold text-neutral-300 uppercase tracking-wider font-mono mb-3">
                Matched Categories
              </h2>
              <div className="flex flex-wrap gap-2">
                {searchResults.categories.map(cat => (
                  <Link
                    key={cat}
                    href={`/clips?category=${encodeURIComponent(cat)}`}
                    className="px-4 py-2 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-xs font-medium text-neutral-200 hover:text-rose-400 flex items-center gap-2 transition-colors"
                  >
                    <span>{cat}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-neutral-500" />
                  </Link>
                ))}
              </div>
            </section>
          )}

          {/* Creators matches */}
          {(activeTab === 'all' || activeTab === 'creators') && searchResults.creators.length > 0 && (
            <section>
              <h2 className="text-sm font-semibold text-neutral-300 uppercase tracking-wider font-mono mb-4">
                Creators ({searchResults.creators.length})
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {searchResults.creators.map(cr => (
                  <CreatorCard key={cr.id} creator={cr} />
                ))}
              </div>
            </section>
          )}

          {/* Clips matches */}
          {(activeTab === 'all' || activeTab === 'clips') && searchResults.clips.length > 0 && (
            <section>
              <h2 className="text-sm font-semibold text-neutral-300 uppercase tracking-wider font-mono mb-4">
                Video Clips ({searchResults.clips.length})
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
                {searchResults.clips.map((c, idx) => (
                  <ClipCard key={`${c.id}-${idx}`} clip={c} />
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
};
