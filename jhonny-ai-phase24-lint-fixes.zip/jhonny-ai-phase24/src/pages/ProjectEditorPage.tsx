import React, { useMemo, useState } from 'react';
import { ArrowLeft, Save, Lock, Scissors, FileText } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useRouter, Link } from '../router/Router';
import { EmptyState } from '../components/common/EmptyState';
import { findOwnedProject, HOOK_TEXT_MAX, PROJECT_NAME_MAX, type Project, type ProjectInput } from '../lib/projects';
import { canViewClipDetail } from '../lib/rights';

export const ProjectEditorPage: React.FC = () => {
  const { params, navigate } = useRouter();
  const { currentUser, projects } = useApp();
  const project = findOwnedProject(projects, params.id || '', currentUser?.id);

  if (!project) {
    // Same message for missing and other-owner projects, so ids cannot be probed.
    return (
      <div className="max-w-4xl mx-auto px-4 py-20">
        <EmptyState
          icon={FileText}
          title="Project not found"
          description="It may have been deleted, or it belongs to a different account."
          actionLabel="Back to studio"
          onAction={() => navigate('/studio')}
        />
      </div>
    );
  }

  return <ProjectEditorForm project={project} />;
};

const ProjectEditorForm: React.FC<{ project: Project }> = ({ project }) => {
  const { currentUser, clips, saveProjectEdits } = useApp();
  const { navigate } = useRouter();

  const [name, setName] = useState(project.name);
  const [sourceClipId, setSourceClipId] = useState<string>(project.sourceClipId ?? '');
  const [trimStart, setTrimStart] = useState<string>(String(project.trimStart));
  const [trimEnd, setTrimEnd] = useState<string>(String(project.trimEnd));
  const [hookText, setHookText] = useState(project.hookText);
  const [error, setError] = useState<string | null>(null);
  const [savedNotice, setSavedNotice] = useState(false);

  // Only clips this user may view can be used as sources.
  const sourceOptions = useMemo(
    () => clips.filter(c => canViewClipDetail(c, currentUser?.role)),
    [clips, currentUser?.role]
  );

  const isDirty =
    name !== project.name ||
    (sourceClipId || null) !== project.sourceClipId ||
    trimStart !== String(project.trimStart) ||
    trimEnd !== String(project.trimEnd) ||
    hookText !== project.hookText;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSavedNotice(false);
    const input: ProjectInput = {
      name,
      sourceClipId: sourceClipId || null,
      trimStart: Number(trimStart),
      trimEnd: Number(trimEnd),
      hookText
    };
    const result = saveProjectEdits(project.id, input);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setSavedNotice(true);
  };

  const missingSource = !!project.sourceClipId && !clips.some(c => c.id === project.sourceClipId);
  const inputClass =
    'w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-100 focus:outline-none focus:border-rose-500';

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center gap-2 text-xs text-neutral-400 mb-6">
        <Link href="/studio" className="inline-flex items-center gap-1 hover:text-white">
          <ArrowLeft className="w-3.5 h-3.5" />
          Studio
        </Link>
        <span>/</span>
        <span className="text-neutral-200 truncate max-w-xs">{project.name}</span>
      </div>

      <div className="mb-6 min-w-0">
        <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight truncate">{project.name}</h1>
        <p className="text-[11px] text-neutral-400 mt-1">
          Status: {project.status === 'saved' ? 'Saved' : 'Draft'} · Last saved{' '}
          {new Date(project.updatedAt).toLocaleString()}
          {isDirty && <span className="text-amber-400"> · Unsaved changes</span>}
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-5 bg-neutral-900/80 border border-neutral-800 rounded-xl p-5">
        <div>
          <label htmlFor="project-name" className="block text-xs font-medium text-neutral-300 mb-1.5">
            Project name
          </label>
          <input
            id="project-name"
            className={inputClass}
            value={name}
            maxLength={PROJECT_NAME_MAX}
            onChange={e => setName(e.target.value)}
          />
        </div>

        <div>
          <label htmlFor="source-clip" className="block text-xs font-medium text-neutral-300 mb-1.5">
            Source clip
          </label>
          <select
            id="source-clip"
            className={inputClass}
            value={sourceClipId}
            onChange={e => setSourceClipId(e.target.value)}
          >
            <option value="">No source clip</option>
            {sourceOptions.map(c => (
              <option key={c.id} value={c.id}>
                {c.title} ({c.durationFormatted})
              </option>
            ))}
          </select>
          {missingSource && (
            <p className="mt-1 text-[11px] text-amber-400">
              The previously selected clip is no longer available. Choose another source or none to save changes.
            </p>
          )}
        </div>

        <fieldset className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <legend className="sr-only">Trim window in seconds</legend>
          <div>
            <label htmlFor="trim-start" className="block text-xs font-medium text-neutral-300 mb-1.5">
              Start (seconds)
            </label>
            <input
              id="trim-start"
              type="number"
              min={0}
              step={0.5}
              className={inputClass}
              value={trimStart}
              onChange={e => setTrimStart(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="trim-end" className="block text-xs font-medium text-neutral-300 mb-1.5">
              End (seconds)
            </label>
            <input
              id="trim-end"
              type="number"
              min={0}
              step={0.5}
              className={inputClass}
              value={trimEnd}
              onChange={e => setTrimEnd(e.target.value)}
            />
          </div>
        </fieldset>

        <div>
          <label htmlFor="hook-text" className="block text-xs font-medium text-neutral-300 mb-1.5">
            Hook text <span className="text-neutral-500">({hookText.length}/{HOOK_TEXT_MAX})</span>
          </label>
          <input
            id="hook-text"
            className={inputClass}
            value={hookText}
            maxLength={HOOK_TEXT_MAX}
            onChange={e => setHookText(e.target.value)}
          />
        </div>

        {error && (
          <p role="alert" className="text-[11px] text-rose-400">
            {error}
          </p>
        )}
        {savedNotice && !error && !isDirty && (
          <p role="status" className="text-[11px] text-emerald-400">
            Project saved.
          </p>
        )}

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            type="submit"
            disabled={!isDirty}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
              isDirty
                ? 'bg-rose-500 hover:bg-rose-600 text-white'
                : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
            }`}
          >
            <Save className="w-3.5 h-3.5" />
            Save project
          </button>
          <button
            type="button"
            onClick={() => navigate('/studio')}
            className="px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs"
          >
            Back to studio
          </button>
        </div>
      </form>

      <section className="mt-6 bg-neutral-900/60 border border-neutral-800 rounded-xl p-5" aria-labelledby="export-heading">
        <h2 id="export-heading" className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
          <Lock className="w-4 h-4 text-neutral-400" />
          Export
        </h2>
        <p className="text-xs text-neutral-400 mt-2">
          Video export is not available in this build. Rendering a 1080×1920 MP4 requires the production media service
          (for example an FFmpeg worker). The trim window and hook text are saved with the project so they can be
          rendered once that service is connected.
        </p>
        <button
          type="button"
          disabled
          className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-neutral-800 text-neutral-500 text-xs font-semibold cursor-not-allowed"
        >
          <Scissors className="w-3.5 h-3.5" />
          Export MP4 (requires render service)
        </button>
      </section>
    </div>
  );
};
