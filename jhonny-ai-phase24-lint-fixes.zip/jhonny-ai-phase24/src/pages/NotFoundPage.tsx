import React from 'react';
import { useRouter } from '../router/Router';

export const NotFoundPage: React.FC = () => {
  const { navigate, path } = useRouter();
  return (
    <div className="max-w-3xl mx-auto px-4 py-24 text-center">
      <p className="text-xs font-mono text-rose-400 mb-3">404</p>
      <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mb-3">Page not found</h1>
      <p className="text-sm text-neutral-400 max-w-md mx-auto">
        Nothing exists at <code className="font-mono text-neutral-300 break-all">{path}</code>. The link may be
        outdated or mistyped.
      </p>
      <div className="flex flex-wrap items-center justify-center gap-3 mt-8">
        <button
          type="button"
          onClick={() => navigate('/clips')}
          className="px-4 py-2 rounded-lg bg-rose-500 hover:bg-rose-600 text-white text-xs font-semibold transition-colors"
        >
          Browse licensed clips
        </button>
        <button
          type="button"
          onClick={() => navigate('/')}
          className="px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium border border-neutral-700 transition-colors"
        >
          Go to home
        </button>
      </div>
    </div>
  );
};
