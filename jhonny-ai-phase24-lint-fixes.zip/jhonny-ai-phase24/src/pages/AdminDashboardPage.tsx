import React from 'react';
import { Link } from '../router/Router';
import { AdminAnalyticsPage } from './AdminAnalyticsPage';
export const AdminDashboardPage: React.FC = () => <div className="text-white"><nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 flex flex-wrap gap-3 text-xs">{[['Users','/admin/users'],['Creators','/admin/creators'],['Rights registry','/admin/rights'],['Reports','/admin/reports'],['Clip moderation','/admin/clips'],['Moderation history','/admin/moderation']].map(([label,path])=><Link key={path} href={path} className="rounded-lg border border-neutral-700 px-3 py-2 hover:bg-neutral-900">{label}</Link>)}</nav><AdminAnalyticsPage /></div>;
