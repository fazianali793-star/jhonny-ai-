import React from 'react';
import { Sparkles, AlertTriangle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Link } from '../router/Router';

export const AdminAiPage: React.FC = () => {
  const { processingJobs, openAiPipelineModal } = useApp();

  if (!import.meta.env.DEV) {
    return <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-white"><h1 className="text-2xl font-bold mb-3">AI Clip Studio</h1><div role="status" className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 text-sm text-amber-200">Automated clip detection is a development prototype only. No production ingestion job was started because a real video-analysis backend is not configured.</div></main>;
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center gap-2 text-xs text-neutral-400 mb-1">
        <Link href="/admin" className="hover:text-white">Admin Console</Link>
        <span>/</span>
        <span className="text-neutral-200">AI Clip Studio</span>
      </div>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">AI Clip Studio</h1>
          <p className="text-xs text-neutral-400">Track ingestion jobs. Generated clips are submitted for license review.</p>
        </div>
        <button
          type="button"
          onClick={openAiPipelineModal}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-semibold"
        >
          <Sparkles className="w-4 h-4" />
          New ingestion job
        </button>
      </div>

      <div className="mb-6 p-3 rounded-xl bg-amber-500/5 border border-amber-500/30 text-[11px] text-amber-200 flex gap-2">
        <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
        <p>
          Clip detection in this build is simulated. It uses templates and does not analyze the source video, and no AI
          model is connected. Clips produced here must be approved by an administrator before they are public.
        </p>
      </div>

      {processingJobs.length === 0 ? (
        <p className="text-xs text-neutral-400">No ingestion jobs yet.</p>
      ) : (
        <ul className="space-y-3" aria-label="Ingestion jobs">
          {processingJobs.map(job => (
            <li key={job.id} className="bg-neutral-900/80 border border-neutral-800 rounded-xl p-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="min-w-0">
                  <h2 className="text-sm font-semibold text-neutral-100 truncate">{job.sourceTitle}</h2>
                  <p className="text-[11px] text-neutral-400 mt-1">{job.currentStepText}</p>
                </div>
                <div className="text-[11px] text-neutral-400 font-mono shrink-0">
                  {job.status} · {job.progress}% · {job.viralMomentsFound} moments
                </div>
              </div>
              <div className="mt-3 h-1.5 rounded-full bg-neutral-800 overflow-hidden" aria-hidden="true">
                <div className="h-full bg-rose-500" style={{ width: `${Math.min(100, Math.max(0, job.progress))}%` }} />
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};
