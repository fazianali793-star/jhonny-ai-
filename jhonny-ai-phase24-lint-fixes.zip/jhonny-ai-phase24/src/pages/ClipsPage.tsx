import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useApp } from '../context/AppContext';
import { useRouter } from '../router/Router';
import { ClipCard } from '../components/common/ClipCard';
import { BackendLibraryPanel } from '../components/common/Phase4BackendPanels';
import { EmptyState } from '../components/common/EmptyState';
import { AdPlacement } from '../components/common/AdPlacement';
import { CATEGORIES } from '../data/mockData';
import { Search, RotateCcw, Video, ChevronLeft, ChevronRight } from 'lucide-react';
import { isPublicClip } from '../lib/rights';
import {
  paginate,
  queryClips,
  isLibrarySort,
  isDurationFilter,
  LIBRARY_PAGE_SIZE,
  type LibrarySort,
  type DurationFilter
} from '../lib/library';

export const ClipsPage: React.FC = () => {
  const { clips } = useApp();
  const { query, navigate } = useRouter();

  // Filters start from the URL so shared links reproduce the same view.
  const [searchTerm, setSearchTerm] = useState(query.q || '');
  const [selectedCategory, setSelectedCategory] = useState<string>(query.category || 'All');
  const [selectedSort, setSelectedSort] = useState<LibrarySort>(
    isLibrarySort(query.sort) ? query.sort : 'trending'
  );
  const [selectedDuration, setSelectedDuration] = useState<DurationFilter>(
    isDurationFilter(query.duration) ? query.duration : 'all'
  );
  const [selectedCreatorId, setSelectedCreatorId] = useState<string>(query.creator || 'all');
  const [page, setPage] = useState<number>(Number(query.page) || 1);

  // Only clips that are published with a valid license are ever listed publicly.
  const publicClips = useMemo(() => clips.filter(c => isPublicClip(c)), [clips]);

  const filteredClips = useMemo(
    () =>
      queryClips(publicClips, {
        search: searchTerm,
        category: selectedCategory,
        creatorId: selectedCreatorId,
        duration: selectedDuration,
        sort: selectedSort
      }),
    [publicClips, searchTerm, selectedCategory, selectedCreatorId, selectedDuration, selectedSort]
  );

  // Changing any filter returns to the first page. The first run is skipped so a
  // deep link such as ?page=3 is honored on load.
  const filtersMounted = useRef(false);
  useEffect(() => {
    if (!filtersMounted.current) {
      filtersMounted.current = true;
      return;
    }
    setPage(1);
  }, [searchTerm, selectedCategory, selectedCreatorId, selectedDuration, selectedSort]);

  const pageData = useMemo(() => paginate(filteredClips, page, LIBRARY_PAGE_SIZE), [filteredClips, page]);

  const resetFilters = () => {
    setSearchTerm('');
    setSelectedCategory('All');
    setSelectedSort('trending');
    setSelectedDuration('all');
    setSelectedCreatorId('all');
  };

  const isFiltered =
    searchTerm !== '' ||
    selectedCategory !== 'All' ||
    selectedDuration !== 'all' ||
    selectedCreatorId !== 'all';

  const goToPage = (next: number) => {
    setPage(next);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Legacy local catalog is development-only. Production uses only server-backed records.
  if (!import.meta.env.DEV) {
    return <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8"><h1 className="text-2xl font-extrabold text-white mb-2">Licensed Clip Library</h1><p className="text-sm text-neutral-400 mb-6">Published clips and license status are loaded from the JHONNY AI backend.</p><BackendLibraryPanel /></div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Licensed Clip Library</h1>
        <p className="text-xs sm:text-sm text-neutral-400 mt-1">
          Browse verified, permission-cleared vertical clips. Download availability is shown on each clip.
        </p>
      </div>

      <div className="mb-6"><BackendLibraryPanel /></div>

      {/* Filter & Search Bar — Phase 2 local catalog retained for existing demo workflows */}
      <div className="bg-neutral-900/80 border border-neutral-800 rounded-xl p-4 mb-6 space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <label htmlFor="clip-search" className="sr-only">Search clips</label>
            <input
              id="clip-search"
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search by keywords, games, podcasts, creator..."
              className="w-full pl-9 pr-16 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-rose-500 transition-colors"
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-neutral-400 hover:text-white"
              >
                Clear
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <label htmlFor="clip-sort" className="text-xs text-neutral-400 whitespace-nowrap">Sort by:</label>
            <select
              id="clip-sort"
              value={selectedSort}
              onChange={e => setSelectedSort(e.target.value as LibrarySort)}
              className="px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 focus:outline-none focus:border-rose-500"
            >
              <option value="trending">Trending Velocity</option>
              <option value="newest">Newest First</option>
              <option value="downloads">Most Downloaded</option>
              <option value="title">Title A–Z</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <label htmlFor="clip-duration" className="text-xs text-neutral-400 whitespace-nowrap">Duration:</label>
            <select
              id="clip-duration"
              value={selectedDuration}
              onChange={e => setSelectedDuration(e.target.value as DurationFilter)}
              className="px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 focus:outline-none focus:border-rose-500"
            >
              <option value="all">All Lengths</option>
              <option value="short">Under 30s</option>
              <option value="medium">30s – 60s</option>
              <option value="long">Over 60s</option>
            </select>
          </div>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs" role="group" aria-label="Filter by category">
          <button
            type="button"
            onClick={() => setSelectedCategory('All')}
            aria-pressed={selectedCategory === 'All'}
            className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition-colors ${
              selectedCategory === 'All'
                ? 'bg-rose-500 text-white shadow-sm'
                : 'bg-neutral-800/80 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
            }`}
          >
            All Categories
          </button>
          {CATEGORIES.map(cat => (
            <button
              type="button"
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              aria-pressed={selectedCategory === cat}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition-colors ${
                selectedCategory === cat
                  ? 'bg-rose-500 text-white shadow-sm'
                  : 'bg-neutral-800/80 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Meta Stats & Reset Filter Bar */}
      <div className="flex items-center justify-between text-xs text-neutral-400 mb-6">
        <div className="flex items-center gap-2" aria-live="polite">
          <span>Showing</span>
          <strong className="text-neutral-200 font-mono tabular-nums">{pageData.totalItems}</strong>
          <span>licensed clips</span>
        </div>

        {isFiltered && (
          <button
            type="button"
            onClick={resetFilters}
            className="flex items-center gap-1 text-rose-400 hover:text-rose-300 font-medium transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset filters</span>
          </button>
        )}
      </div>

      {pageData.totalItems === 0 ? (
        <EmptyState
          icon={Video}
          title={publicClips.length === 0 ? 'No licensed clips are available yet' : 'No clips match your current filters'}
          description={
            publicClips.length === 0
              ? 'Clips appear here after they are approved and their license is active.'
              : "Try broadening your search term or switching to 'All Categories' to explore available clips."
          }
          actionLabel={isFiltered ? 'Reset all filters' : undefined}
          onAction={isFiltered ? resetFilters : undefined}
        />
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
            {pageData.items.map((clip, idx) => (
              <React.Fragment key={clip.id}>
                <ClipCard clip={clip} />
                {idx === 3 && pageData.page === 1 && (
                  <div className="sm:col-span-2 lg:col-span-4">
                    <AdPlacement type="leaderboard" />
                  </div>
                )}
              </React.Fragment>
            ))}
          </div>

          {pageData.totalPages > 1 && (
            <nav className="flex items-center justify-center gap-3 mt-8" aria-label="Pagination">
              <button
                type="button"
                onClick={() => goToPage(pageData.page - 1)}
                disabled={pageData.page <= 1}
                className="inline-flex items-center gap-1 px-3 py-2 rounded-lg bg-neutral-800 text-xs text-neutral-200 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                Previous
              </button>
              <span className="text-xs text-neutral-400 font-mono">
                Page {pageData.page} of {pageData.totalPages}
              </span>
              <button
                type="button"
                onClick={() => goToPage(pageData.page + 1)}
                disabled={pageData.page >= pageData.totalPages}
                className="inline-flex items-center gap-1 px-3 py-2 rounded-lg bg-neutral-800 text-xs text-neutral-200 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Next
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </nav>
          )}
        </>
      )}
    </div>
  );
};
