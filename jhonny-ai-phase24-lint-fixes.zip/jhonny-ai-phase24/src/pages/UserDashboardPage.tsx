import React, { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { ApiDownloadRecord, fetchMyDownloads } from '../lib/api';
import { useRouter, Link } from '../router/Router';
import { ClipCard } from '../components/common/ClipCard';
import { StatCard } from '../components/common/StatCard';
import { EmptyState } from '../components/common/EmptyState';
import {
  Download,
  Bookmark,
  Activity,
  Settings,
  ShieldCheck,
  Video,
  ExternalLink,
  RotateCcw
} from 'lucide-react';

const LegacyUserDashboardPage: React.FC = () => {
  const {
    currentUser,
    downloadHistory,
    savedClipIds,
    clips,
    openDownloadModal,
    addToast
  } = useApp();
  const { navigate } = useRouter();

  const [activeTab, setActiveTab] = useState<'overview' | 'downloads' | 'saved' | 'account'>('overview');

  // Account form states
  const [displayName, setDisplayName] = useState(currentUser?.name || 'Jordan Miller');
  const [tiktokHandle, setTiktokHandle] = useState(currentUser?.socialLinks?.tiktok || '@jordanclips');
  const [youtubeHandle, setYoutubeHandle] = useState(currentUser?.socialLinks?.youtube || '@jordaneditor');
  const [notifyNewDrops, setNotifyNewDrops] = useState(true);

  const savedClips = clips.filter(c => savedClipIds.includes(c.id));

  const handleSaveAccount = (e: React.FormEvent) => {
    e.preventDefault();
    addToast('Profile Updated', 'Your publisher account preferences have been saved.', 'success');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div className="flex items-center gap-3">
          <img
            src={currentUser?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'}
            alt=""
            className="w-12 h-12 rounded-xl object-cover border border-neutral-700 shadow-md"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                {currentUser?.name || 'Publisher Dashboard'}
              </h1>
              <span className="font-mono text-[10px] uppercase px-2 py-0.5 rounded bg-neutral-800 text-neutral-400 border border-neutral-700">
                {currentUser?.role || 'User'}
              </span>
            </div>
            <p className="text-xs text-neutral-400">
              Manage your downloaded media packages, saved clips, and syndicate syndication links
            </p>
          </div>
        </div>

        <Link
          href="/clips"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-semibold shadow-md transition-all self-start sm:self-auto"
        >
          <Video className="w-3.5 h-3.5" />
          <span>Browse More Clips</span>
        </Link>
      </div>

      {/* Tabs */}
      <div className="border-b border-neutral-800 mb-8">
        <div className="flex gap-2 sm:gap-6 text-xs font-semibold overflow-x-auto pb-1">
          <button
            onClick={() => setActiveTab('overview')}
            className={`pb-3 px-2 border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'overview'
                ? 'border-rose-500 text-white'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Overview</span>
          </button>
          <button
            onClick={() => setActiveTab('downloads')}
            className={`pb-3 px-2 border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'downloads'
                ? 'border-rose-500 text-white'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Recent Downloads</span>
            <span className="font-mono text-[10px] text-neutral-500">
              ({downloadHistory.length})
            </span>
          </button>
          <button
            onClick={() => setActiveTab('saved')}
            className={`pb-3 px-2 border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'saved'
                ? 'border-rose-500 text-white'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5" />
            <span>Saved Clips</span>
            <span className="font-mono text-[10px] text-neutral-500">
              ({savedClips.length})
            </span>
          </button>
          <button
            onClick={() => setActiveTab('account')}
            className={`pb-3 px-2 border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'account'
                ? 'border-rose-500 text-white'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Account Settings</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Stat Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <StatCard
              label="Total Downloads"
              value={downloadHistory.length}
              change="+2 this week"
              trend="up"
              icon={Download}
              description="Watermark-free exports"
            />
            <StatCard
              label="Saved Favorites"
              value={savedClips.length}
              icon={Bookmark}
              description="Bookmarked for publishing"
            />
            <StatCard
              label="License Clearance"
              value="100% Active"
              trend="up"
              icon={ShieldCheck}
              description="Zero strikes reported"
            />
          </div>

          {/* Recent Activity Feed */}
          <div className="bg-neutral-900/60 rounded-xl border border-neutral-800 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-sm text-neutral-100">Recent Platform Activity</h3>
              <span className="text-xs text-neutral-500 font-mono">Live Activity Stream</span>
            </div>

            <div className="space-y-4">
              {downloadHistory.slice(0, 3).map((dl, idx) => (
                <div
                  key={`${dl.id}-${idx}`}
                  className="flex items-center justify-between p-3 rounded-lg bg-neutral-950/40 border border-neutral-850 text-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-7 h-7 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-400">
                      <Download className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <span className="font-medium text-neutral-200 block truncate max-w-sm">
                        Downloaded "{dl.clipTitle}"
                      </span>
                      <span className="text-[11px] text-neutral-500 font-mono">
                        {new Date(dl.downloadedAt).toLocaleDateString()} · {dl.fileSize}
                      </span>
                    </div>
                  </div>
                  <span className="text-emerald-400 text-[11px] font-medium">Licensed</span>
                </div>
              ))}

              <div className="flex items-center justify-between p-3 rounded-lg bg-neutral-950/40 border border-neutral-850 text-xs">
                <div className="flex items-center gap-3">
                  <div className="w-7 h-7 rounded-lg bg-sky-500/10 flex items-center justify-center text-sky-400">
                    <ShieldCheck className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <span className="font-medium text-neutral-200 block">
                      Account Registered & Syndication Terms Accepted
                    </span>
                    <span className="text-[11px] text-neutral-500 font-mono">
                      Phase 1 Ad-Supported Model
                    </span>
                  </div>
                </div>
                <span className="text-neutral-400 text-[11px]">Active</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Recent Downloads */}
      {activeTab === 'downloads' && (
        <div>
          {downloadHistory.length === 0 ? (
            <EmptyState
              icon={Download}
              title="No downloads recorded yet"
              description="Browse the library to download permission-cleared clips for your social media channels."
              actionLabel="Discover Clips"
              onAction={() => navigate('/clips')}
            />
          ) : (
            <div className="bg-neutral-900/60 rounded-xl border border-neutral-800 overflow-hidden">
              <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between">
                <h3 className="font-semibold text-sm text-neutral-100">Your Downloaded Clips</h3>
                <span className="text-xs text-neutral-400 font-mono">
                  {downloadHistory.length} Total Packages
                </span>
              </div>

              <div className="divide-y divide-neutral-800">
                {downloadHistory.map((item, idx) => {
                  const clip = clips.find(c => c.id === item.clipId);
                  return (
                    <div
                      key={`${item.id}-${idx}`}
                      className="p-4 sm:px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-neutral-900/40 transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <img
                          src={item.thumbnail}
                          alt=""
                          className="w-12 h-16 rounded-lg object-cover bg-neutral-950 shrink-0 border border-neutral-800"
                        />
                        <div>
                          <h4 className="font-medium text-xs sm:text-sm text-neutral-100 line-clamp-1 mb-1">
                            {item.clipTitle}
                          </h4>
                          <div className="flex items-center gap-2 text-[11px] text-neutral-400 font-mono">
                            <span>{item.category}</span>
                            <span>·</span>
                            <span>{item.durationFormatted}</span>
                            <span>·</span>
                            <span>{item.fileSize}</span>
                            <span>·</span>
                            <span>{new Date(item.downloadedAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-center">
                        {clip && (
                          <button
                            onClick={() => openDownloadModal(clip)}
                            className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-neutral-200 border border-neutral-700 flex items-center gap-1.5 transition-colors"
                          >
                            <RotateCcw className="w-3 h-3 text-neutral-400" />
                            <span>Re-download</span>
                          </button>
                        )}
                        {clip && (
                          <Link
                            href={`/clips/${clip.slug}`}
                            className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-neutral-200 border border-neutral-700 flex items-center gap-1.5 transition-colors"
                          >
                            <span>View</span>
                            <ExternalLink className="w-3 h-3 text-neutral-400" />
                          </Link>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Saved / Favorites */}
      {activeTab === 'saved' && (
        <div>
          {savedClips.length === 0 ? (
            <EmptyState
              icon={Bookmark}
              title="No saved clips yet"
              description="Click the bookmark icon on any clip while browsing to save it to your queue for later."
              actionLabel="Browse Clips"
              onAction={() => navigate('/clips')}
            />
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {savedClips.map((clip, idx) => (
                <ClipCard key={`${clip.id}-${idx}`} clip={clip} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Account Settings */}
      {activeTab === 'account' && (
        <div className="max-w-xl bg-neutral-900/60 rounded-xl border border-neutral-800 p-6">
          <h3 className="font-semibold text-sm text-neutral-100 mb-1">Publisher Profile Settings</h3>
          <p className="text-xs text-neutral-400 mb-6">
            Configure your publisher channel handles and notifications.
          </p>

          <form onSubmit={handleSaveAccount} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">Display Name</label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 focus:outline-none focus:border-rose-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">TikTok Channel Link / Handle</label>
              <input
                type="text"
                value={tiktokHandle}
                onChange={(e) => setTiktokHandle(e.target.value)}
                placeholder="@mychannelclips"
                className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 focus:outline-none focus:border-rose-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">YouTube Shorts Handle</label>
              <input
                type="text"
                value={youtubeHandle}
                onChange={(e) => setYoutubeHandle(e.target.value)}
                placeholder="@mychannelshorts"
                className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 focus:outline-none focus:border-rose-500"
              />
            </div>

            <div className="pt-2 border-t border-neutral-800">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifyNewDrops}
                  onChange={(e) => setNotifyNewDrops(e.target.checked)}
                  className="rounded border-neutral-700 text-rose-500 focus:ring-0"
                />
                <span className="text-xs text-neutral-300">
                  Email me alerts when new licensed clips are added in my favorite categories
                </span>
              </label>
            </div>

            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-rose-500 hover:bg-rose-600 text-white font-semibold text-xs transition-colors"
            >
              Save Profile Changes
            </button>
          </form>
        </div>
      )}
    </div>
  );
};


const LiveUserDashboardPage: React.FC = () => {
  const { currentUser } = useApp();
  const [items, setItems] = useState<ApiDownloadRecord[]>([]);
  const [total, setTotal] = useState(0);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState('');
  const [unsupportedTab, setUnsupportedTab] = useState<'saved'|'account'|null>(null);
  const load = async () => {
    setBusy(true); setError('');
    try { const result = await fetchMyDownloads(); setItems(result.items); setTotal(result.total); }
    catch (e) { setItems([]); setTotal(0); setError(e instanceof Error ? e.message : 'Download history could not be loaded.'); }
    finally { setBusy(false); }
  };
  useEffect(() => { void load(); }, []);
  return <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-white">
    <div className="mb-6"><h1 className="text-2xl font-bold">Account Dashboard</h1><p className="text-sm text-neutral-400 mt-1">{currentUser?.name || 'Signed-in user'} · Server-verified account</p></div>
    <div className="flex flex-wrap gap-2 mb-5"><button className="rounded-lg border border-neutral-700 px-3 py-2 text-xs" onClick={() => { setUnsupportedTab(null); void load(); }}>Download history</button><button className="rounded-lg border border-neutral-700 px-3 py-2 text-xs" onClick={() => setUnsupportedTab('saved')}>Saved clips</button><button className="rounded-lg border border-neutral-700 px-3 py-2 text-xs" onClick={() => setUnsupportedTab('account')}>Account preferences</button></div>
    {unsupportedTab && <div role="status" className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 text-sm text-amber-200">{unsupportedTab === 'saved' ? 'Server-backed saved clips are not implemented yet. No browser-local bookmarks are presented as account data.' : 'Profile editing and notification preferences are not connected to a backend endpoint yet. No changes have been saved.'}</div>}
    {!unsupportedTab && <section className="rounded-xl border border-neutral-800 bg-neutral-900/70 p-4"><div className="flex justify-between items-center gap-3 mb-3"><div><h2 className="font-semibold">Completed downloads</h2><p className="text-xs text-neutral-400">History is loaded from your authenticated account on the server.</p></div><button className="rounded-lg border border-neutral-700 px-3 py-2 text-xs disabled:opacity-50" disabled={busy} onClick={() => void load()}>Refresh</button></div>
      {busy && <p role="status" className="text-sm text-neutral-300">Loading download history…</p>}{error && <p role="alert" className="text-sm text-rose-400">{error}. No local records were substituted.</p>}
      {!busy && !error && items.length === 0 && <p className="text-sm text-neutral-400 py-4">No completed downloads are recorded for this account.</p>}
      {!error && items.length > 0 && <><p className="text-xs text-neutral-400 mb-2">{total} records (showing up to 200 most recent)</p><ul className="divide-y divide-neutral-800">{items.map(item => <li key={item.id} className="py-3 flex flex-wrap justify-between gap-2"><div><p className="text-sm">{item.clip_title}</p><p className="text-xs text-neutral-400">Use: {item.requested_use} · {new Date(item.created_at).toLocaleString()}</p></div><span className="text-xs text-neutral-400">{(item.size_bytes / (1024 * 1024)).toFixed(2)} MB</span></li>)}</ul></>}
    </section>}
  </main>;
};

export const UserDashboardPage: React.FC = () => import.meta.env.DEV ? <LegacyUserDashboardPage /> : <LiveUserDashboardPage />;
