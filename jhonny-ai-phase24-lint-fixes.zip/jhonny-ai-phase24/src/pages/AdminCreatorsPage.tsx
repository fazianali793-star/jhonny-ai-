import React from 'react';
import { AdminLiveDataPage } from './AdminLiveDataPage';
export const AdminCreatorsPage: React.FC = () => <AdminLiveDataPage section="creators" />;
