import React, { useCallback, useEffect, useState } from 'react';
import { Link } from '../router/Router';
import { apiRequest } from '../lib/api';

type Analytics = { clips_by_status: Record<string, number>; users_by_role: Record<string, number>; licenses_by_status: Record<string, number>; completed_downloads: number; clips_created_last_30_days: number; generated_at: string };
const Stat: React.FC<{label:string;value:number}> = ({label,value}) => <div className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-5"><p className="text-xs text-neutral-400">{label}</p><p className="mt-2 text-2xl font-bold text-white">{value.toLocaleString()}</p></div>;
export const AdminAnalyticsPage: React.FC = () => {
  const [data,setData] = useState<Analytics|null>(null); const [error,setError] = useState(''); const [busy,setBusy] = useState(false);
  const load = useCallback(async () => { setBusy(true); setError(''); try { setData(await apiRequest<Analytics>('/api/admin/analytics')); } catch(e) { setData(null); setError(e instanceof Error ? e.message : 'Live analytics are unavailable.'); } finally { setBusy(false); } }, []);
  useEffect(() => { void load(); }, [load]);
  const clips = data ? Object.values(data.clips_by_status).reduce((a,b)=>a+b,0) : null;
  const users = data ? Object.values(data.users_by_role).reduce((a,b)=>a+b,0) : null;
  return <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-white">
    <div className="flex items-center justify-between gap-3 mb-6"><div><div className="text-xs text-neutral-400 mb-1"><Link href="/admin">Admin Console</Link> / Analytics</div><h1 className="text-2xl font-bold">Platform Analytics</h1><p className="text-xs text-neutral-400 mt-1">Server-derived counts only. Views, conversion ratios, and category metrics are not collected by this backend.</p></div><button onClick={()=>void load()} disabled={busy} className="rounded-lg border border-neutral-700 px-3 py-2 text-sm disabled:opacity-50">{busy?'Refreshing…':'Refresh'}</button></div>
    {error && <div role="alert" className="rounded-lg border border-rose-900 bg-rose-950/30 p-4 text-sm text-rose-300">Live analytics unavailable: {error}. No demo statistics are substituted.</div>}
    {data && <><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4"><Stat label="Total clips" value={clips ?? 0}/><Stat label="Registered users" value={users ?? 0}/><Stat label="Completed downloads" value={data.completed_downloads}/><Stat label="Clips created (30 days)" value={data.clips_created_last_30_days}/></div><div className="grid gap-4 md:grid-cols-3 mt-6">{[['Clips by publication status',data.clips_by_status],['Users by role',data.users_by_role],['Licenses by status',data.licenses_by_status]].map(([title,values])=><section key={String(title)} className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-5"><h2 className="font-semibold text-sm mb-3">{title as string}</h2>{Object.entries(values as Record<string,number>).length ? Object.entries(values as Record<string,number>).map(([k,v])=><div key={k} className="flex justify-between border-b border-neutral-800 py-2 text-sm"><span className="text-neutral-300">{k}</span><strong>{v}</strong></div>) : <p className="text-sm text-neutral-500">No records</p>}</section>)}</div><p className="mt-4 text-[11px] text-neutral-500">Generated {new Date(data.generated_at).toLocaleString()} from backend database.</p></>}
    {!data && !error && <p role="status" className="text-sm text-neutral-400">Loading live analytics…</p>}
  </div>;
};
