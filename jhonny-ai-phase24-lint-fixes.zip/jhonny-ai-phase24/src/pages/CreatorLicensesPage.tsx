import React, { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { Link } from '../router/Router';
import { LicenseBadge } from '../components/common/LicenseBadge';
import { AlertTriangle, AlertCircle, ExternalLink } from 'lucide-react';
import { ApiCreatorLicense, ApiError, fetchMyLicenses } from '../lib/api';

const LegacyCreatorLicensesPage: React.FC = () => {
  const { licenses, currentUser } = useApp();
  const [filter, setFilter] = useState<'All' | 'Active' | 'Expiring' | 'Expired'>('All');

  const filteredLicenses = licenses.filter(lic => {
    if (filter === 'All') return true;
    return lic.status === filter;
  });

  const expiringCount = licenses.filter(l => l.status === 'Expiring').length;
  const expiredCount = licenses.filter(l => l.status === 'Expired').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-neutral-400 mb-1">
            <Link href="/creator" className="hover:text-white">Creator Portal</Link>
            <span>/</span>
            <span className="text-neutral-200">Rights & License Registry</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">License Management</h1>
          <p className="text-xs text-neutral-400">
            Legal syndication grants and clearance verification for third-party social redistribution
          </p>
        </div>
      </div>

      {/* Warning State Banners for Expiring or Expired */}
      {expiringCount > 0 && (
        <div className="mb-4 p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="text-xs">
            <p className="font-semibold text-amber-200">
              {expiringCount} License Agreement(s) Approaching Expiration
            </p>
            <p className="text-amber-300/80 mt-0.5 leading-relaxed">
              Syndicated clips with expiring licenses will automatically be withdrawn from user search unless renewed with the creator.
            </p>
          </div>
        </div>
      )}

      {expiredCount > 0 && (
        <div className="mb-6 p-4 rounded-xl bg-neutral-900 border border-neutral-800 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-neutral-400 shrink-0 mt-0.5" />
          <div className="text-xs">
            <p className="font-semibold text-neutral-300">
              {expiredCount} Lapsed Agreement(s)
            </p>
            <p className="text-neutral-400 mt-0.5 leading-relaxed">
              Expired licenses remain preserved in the permanent audit ledger for rights clearance history.
            </p>
          </div>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 mb-6 border-b border-neutral-800 pb-3 text-xs">
        {(['All', 'Active', 'Expiring', 'Expired'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              filter === tab
                ? 'bg-neutral-800 text-white'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Licenses List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredLicenses.map((lic, idx) => {
          const isExpiring = lic.status === 'Expiring';
          const isExpired = lic.status === 'Expired';

          return (
            <div
              key={`${lic.id}-${idx}`}
              className={`p-5 rounded-xl border bg-neutral-900/60 flex flex-col justify-between transition-all ${
                isExpiring
                  ? 'border-amber-500/40 bg-amber-500/5'
                  : isExpired
                  ? 'border-neutral-800/80 opacity-70'
                  : 'border-neutral-800'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono text-xs text-neutral-400">
                    {lic.id}
                  </span>
                  <LicenseBadge status={lic.status} />
                </div>

                <h3 className="font-semibold text-sm text-neutral-100 mb-1">
                  {lic.clipTitle}
                </h3>
                <p className="text-xs text-neutral-400 mb-4">
                  Licensor: <strong className="text-neutral-200">{lic.creatorName}</strong>
                </p>

                <div className="space-y-2 text-xs font-mono">
                  <div className="flex justify-between py-1 border-b border-neutral-800/80">
                    <span className="text-neutral-500">License Scope</span>
                    <span className="text-neutral-300 font-sans">{lic.licenseType}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-neutral-800/80">
                    <span className="text-neutral-500">Effective Date</span>
                    <span className="text-neutral-300">{lic.startDate}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-neutral-800/80">
                    <span className="text-neutral-500">Term Expiry</span>
                    <span className={isExpiring ? 'text-amber-400 font-semibold' : 'text-neutral-300'}>
                      {lic.expiryDate}
                    </span>
                  </div>
                  <div className="py-1">
                    <span className="text-neutral-500 block mb-1">Allowed Syndication Targets</span>
                    <div className="flex flex-wrap gap-1 font-sans">
                      {lic.allowedPlatforms.map(p => (
                        <span
                          key={p}
                          className="px-2 py-0.5 rounded bg-neutral-800 text-[11px] text-neutral-300 border border-neutral-700"
                        >
                          {p}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {lic.notes && (
                  <p className="mt-3 text-[11px] text-neutral-400 italic bg-neutral-950/60 p-2.5 rounded-lg border border-neutral-850">
                    "{lic.notes}"
                  </p>
                )}
              </div>

              <div className="mt-4 pt-3 border-t border-neutral-800 flex items-center justify-between text-xs">
                <a
                  href={lic.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-neutral-400 hover:text-white flex items-center gap-1 transition-colors"
                >
                  <span>Source URL</span>
                  <ExternalLink className="w-3 h-3" />
                </a>

                {isExpiring && (
                  <button
                    onClick={() => alert('Renewal requested: Creator management alerted.')}
                    className="px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 font-medium text-xs border border-amber-500/40"
                  >
                    Request Extension
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};


const ProductionCreatorLicensesPage: React.FC = () => {
  const [items, setItems] = useState<ApiCreatorLicense[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('All');

  const refresh = async () => {
    setLoading(true);
    setError('');
    try {
      const result = await fetchMyLicenses();
      setItems(result.items);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Unable to load your licenses.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void refresh(); }, []);
  const visible = items.filter(item => filter === 'All' || item.status === filter);
  const uses = (value: string) => {
    try {
      const parsed: unknown = JSON.parse(value);
      return Array.isArray(parsed) ? parsed.filter((x): x is string => typeof x === 'string') : [];
    } catch { return []; }
  };
  const restrictions = (value: string) => {
    try {
      const parsed: unknown = JSON.parse(value);
      return Array.isArray(parsed) ? parsed.filter((x): x is string => typeof x === 'string') : [];
    } catch { return []; }
  };

  return <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-white">
    <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
      <div><h1 className="text-2xl font-bold mb-2">Creator Licenses</h1><p className="text-sm text-neutral-400">Server records for licenses attached to your uploaded clips.</p></div>
      <button onClick={() => void refresh()} className="rounded-lg border border-neutral-700 px-3 py-2 text-sm hover:bg-neutral-800" disabled={loading}>Refresh</button>
    </div>
    <div className="flex flex-wrap gap-2 mb-5">
      {['All', 'Pending Review', 'Active', 'Revoked', 'Expired'].map(status => <button key={status} onClick={() => setFilter(status)} className={`rounded-lg px-3 py-2 text-sm border ${filter === status ? 'border-indigo-400 bg-indigo-500/15 text-white' : 'border-neutral-800 text-neutral-400'}`}>{status}</button>)}
    </div>
    {loading ? <p role="status" className="text-sm text-neutral-400 py-8">Loading licenses…</p> : error ? <div role="alert" className="rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-200">{error}<button onClick={() => void refresh()} className="ml-3 underline">Retry</button></div> : visible.length === 0 ? <div role="status" className="rounded-xl border border-neutral-800 p-8 text-center text-sm text-neutral-400">{items.length === 0 ? 'No license records are associated with your uploaded clips yet.' : 'No licenses match this filter.'}</div> :
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">{visible.map(lic => <article key={lic.id} className="rounded-xl border border-neutral-800 bg-neutral-900/50 p-5">
        <div className="flex items-start justify-between gap-3"><div><h2 className="font-semibold">{lic.clip_title}</h2><p className="text-xs text-neutral-500 mt-1">Clip status: {lic.clip_status}</p></div><span className={`rounded-full px-2.5 py-1 text-xs ${lic.status === 'Active' ? 'bg-emerald-500/15 text-emerald-300' : 'bg-neutral-800 text-neutral-300'}`}>{lic.status}</span></div>
        <dl className="mt-4 space-y-3 text-sm"><div><dt className="text-neutral-500 text-xs">Permitted uses</dt><dd>{uses(lic.allowed_uses).join(', ') || 'None listed'}</dd></div><div><dt className="text-neutral-500 text-xs">Platform restrictions</dt><dd>{restrictions(lic.platform_restrictions).join(', ') || 'No platform restrictions recorded'}</dd></div><div><dt className="text-neutral-500 text-xs">Expires</dt><dd>{lic.expires_at ? new Date(lic.expires_at).toLocaleString() : 'No expiry recorded'}</dd></div>{lic.verification_note && <div><dt className="text-neutral-500 text-xs">Rights verification note</dt><dd className="text-neutral-300">{lic.verification_note}</dd></div>}</dl>
      </article>)}</div>}
  </main>;
};

export const CreatorLicensesPage: React.FC = () => import.meta.env.DEV ? <LegacyCreatorLicensesPage /> : <ProductionCreatorLicensesPage />;
