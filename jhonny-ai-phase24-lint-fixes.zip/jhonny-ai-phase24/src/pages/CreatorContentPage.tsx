import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Link } from '../router/Router';
import { StatusBadge } from '../components/common/StatusBadge';
import { LicenseBadge } from '../components/common/LicenseBadge';
import { UploadModal } from '../components/creator/UploadModal';
import { EmptyState } from '../components/common/EmptyState';
import { Video, Plus, Search, Eye, ExternalLink, Sparkles, Sliders } from 'lucide-react';
import { CreatorSubmissionsPanel } from '../components/common/Phase4BackendPanels';

export const CreatorContentPage: React.FC = () => {
  const { clips, currentUser, updateClipStatus, openPreviewModal, openStudioModal, openAiPipelineModal } = useApp();
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  const creatorId = currentUser?.creatorId || 'c1';
  const creatorClips = clips.filter(c => c.creatorId === creatorId || c.creator.name === currentUser?.name);

  const filteredClips = creatorClips.filter(c => {
    if (statusFilter !== 'All' && c.status !== statusFilter) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      return (
        c.title.toLowerCase().includes(q) ||
        c.category.toLowerCase().includes(q) ||
        c.tags.some(t => t.toLowerCase().includes(q))
      );
    }
    return true;
  });

  // The older content editor uses browser-local records. Production exposes only the live server submissions panel.
  if (!import.meta.env.DEV) {
    return <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8"><h1 className="text-2xl font-bold text-white mb-2">Creator Content</h1><p className="text-sm text-neutral-400 mb-6">Live submission status from your authenticated account. Upload and editing controls are unavailable here until the legacy editor is migrated to server APIs.</p><CreatorSubmissionsPanel /></main>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-neutral-400 mb-1">
            <Link href="/creator" className="hover:text-white">Creator Portal</Link>
            <span>/</span>
            <span className="text-neutral-200">Content Management</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Content Library</h1>
          <p className="text-xs text-neutral-400">
            Monitor moderation status, track syndication downloads, and manage video licenses
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={openAiPipelineModal}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-rose-400 hover:text-rose-300 border border-neutral-800 hover:border-neutral-700 text-xs font-semibold shadow-md transition-all active:scale-95"
          >
            <Sparkles className="w-4 h-4" />
            <span>AI Auto-Clip Pipeline</span>
          </button>
          <button
            onClick={() => setUploadModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-semibold shadow-md transition-all active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Upload Clip</span>
          </button>
        </div>
      </div>

      <div className="mb-6"><CreatorSubmissionsPanel /></div>

      <div className="mb-3 text-[11px] text-neutral-500">Legacy prototype content below is browser-local. For authoritative submission and license status, use the live backend panel above.</div>

      {/* Filter and Search Bar */}
      <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-4 mb-6 flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search your clips..."
            className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-rose-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          <span className="text-xs text-neutral-400 whitespace-nowrap">Status:</span>
          {['All', 'Published', 'Processing', 'Pending', 'Disabled'].map(st => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                statusFilter === st
                  ? 'bg-neutral-800 text-white'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Content Table / Cards */}
      {filteredClips.length === 0 ? (
        <EmptyState
          icon={Video}
          title="No clips found"
          description="You haven't uploaded clips matching this filter yet."
          actionLabel="Upload First Clip"
          onAction={() => setUploadModalOpen(true)}
        />
      ) : (
        <div className="bg-neutral-900/60 rounded-xl border border-neutral-800 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-neutral-950/80 border-b border-neutral-800 text-neutral-400 uppercase font-mono text-[10px]">
                <tr>
                  <th className="py-3.5 px-4 font-semibold">Clip Details</th>
                  <th className="py-3.5 px-4 font-semibold">Category</th>
                  <th className="py-3.5 px-4 font-semibold">Status</th>
                  <th className="py-3.5 px-4 font-semibold">License Scope</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Downloads</th>
                  <th className="py-3.5 px-4 font-semibold">Upload Date</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/80">
                {filteredClips.map((clip, idx) => (
                  <tr key={`${clip.id}-${idx}`} className="hover:bg-neutral-900/50 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={clip.thumbnail}
                          alt=""
                          className="w-10 h-14 rounded object-cover bg-neutral-950 shrink-0 border border-neutral-800"
                        />
                        <div className="min-w-0 max-w-xs">
                          <Link
                            href={`/clips/${clip.slug}`}
                            className="font-medium text-neutral-200 hover:text-white line-clamp-1 block"
                          >
                            {clip.title}
                          </Link>
                          <span className="text-[11px] text-neutral-500 font-mono">
                            {clip.durationFormatted} · 1080×1920
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-neutral-300">
                      {clip.category}
                    </td>

                    <td className="py-3.5 px-4">
                      <StatusBadge status={clip.status} />
                    </td>

                    <td className="py-3.5 px-4">
                      <LicenseBadge status={clip.licenseInfo.status} />
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono tabular-nums text-neutral-200 font-medium">
                      {clip.downloads.toLocaleString()}
                    </td>

                    <td className="py-3.5 px-4 text-neutral-400 font-mono text-[11px]">
                      {new Date(clip.createdAt).toLocaleDateString()}
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => openPreviewModal(clip)}
                          title="Preview clip"
                          className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => openStudioModal(clip)}
                          title="Edit in Studio (Captions, Reframe, Hooks)"
                          className="p-1.5 rounded hover:bg-neutral-800 text-rose-400 hover:text-rose-300 transition-colors"
                        >
                          <Sliders className="w-4 h-4" />
                        </button>
                        <Link
                          href={`/clips/${clip.slug}`}
                          title="View public page"
                          className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </Link>
                        {clip.status === 'Published' ? (
                          <button
                            onClick={() => updateClipStatus(clip.id, 'Disabled')}
                            title="Disable clip"
                            className="px-2 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-[10px] text-neutral-300 font-medium"
                          >
                            Disable
                          </button>
                        ) : (
                          <span
                            title="Clips are published or restored by an administrator after license review."
                            className="px-2 py-1 text-[10px] text-neutral-500 font-medium"
                          >
                            {clip.status === 'Disabled' ? 'Admin restore needed' : clip.status === 'Takedown' ? 'Taken down' : 'Awaiting admin'}
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Upload Modal */}
      <UploadModal
        isOpen={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
      />
    </div>
  );
};
