import React, { useState } from 'react';
import { useRouter, Link } from '../router/Router';
import { useApp } from '../context/AppContext';
import { ShieldCheck, UserCheck, Sparkles, ArrowRight } from 'lucide-react';
import { DEMO_ADMIN_PERSONA_ENABLED, DEMO_PERSONAS_ENABLED } from '../lib/demo';
import { loginApi, clearApiToken, ApiError } from '../lib/api';

export const LoginPage: React.FC = () => {
  const { navigate } = useRouter();
  const { switchRole, setCurrentUser } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setError(null); setMessage(null);
    try { const user = await loginApi(email, password); setCurrentUser({ ...user, avatar: '' });
      navigate(user.role === 'admin' ? '/admin' : user.role === 'creator' ? '/creator' : '/studio');
    } catch (err) { setError(err instanceof ApiError ? err.message : 'Sign in failed.'); } finally { setBusy(false); }
  };

  const handleDemo = (role: 'user' | 'creator' | 'admin') => {
    clearApiToken(); setMessage('Demo session only: protected backend actions still require a real server login.');
    switchRole(role);
    if (role === 'admin') navigate('/admin');
    else if (role === 'creator') navigate('/creator');
    else navigate('/studio');
  };

  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl p-6 sm:p-8">
        <div className="text-center mb-6">
          <Link href="/" className="inline-block text-xl font-extrabold text-white mb-2">
            JHONNY <span className="text-rose-500">AI</span>
          </Link>
          <h1 className="text-lg font-bold text-white tracking-tight">Sign in</h1>
          <p className="text-xs text-neutral-400 mt-1">Access your studio projects, saved clips and creator tools</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-3 mb-5">
          <label className="block text-xs text-neutral-300">Email address<input type="email" required autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} className="mt-1 w-full rounded-lg bg-neutral-950 border border-neutral-800 px-3 py-2 text-sm" /></label>
          <label className="block text-xs text-neutral-300">Password<input type="password" required autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)} className="mt-1 w-full rounded-lg bg-neutral-950 border border-neutral-800 px-3 py-2 text-sm" /></label>
          {error && <p role="alert" className="text-xs text-rose-300">{error}</p>}
          {message && <p role="status" className="text-xs text-amber-200">{message}</p>}
          <button disabled={busy} className="w-full rounded-lg bg-rose-500 hover:bg-rose-600 disabled:opacity-50 px-4 py-2.5 text-sm font-semibold text-white">{busy ? 'Signing in…' : 'Sign in securely'}</button>
        </form>
        {DEMO_PERSONAS_ENABLED && <>
        <div className="border-t border-neutral-800 pt-4 mb-3"><p className="text-[11px] text-neutral-400">Or explore with a local demo session. Demo roles do not grant backend permissions.</p></div>

        <div className="space-y-2 mb-2">
          <p className="text-[11px] uppercase font-mono text-neutral-500 mb-1">Demo sessions (not real accounts)</p>
          <button
            type="button"
            onClick={() => handleDemo('user')}
            className="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-left transition-colors group"
          >
            <div className="flex items-center gap-3">
              <UserCheck className="w-4 h-4 text-neutral-400" />
              <div>
                <div className="text-xs font-semibold text-neutral-200">Regular user</div>
                <div className="text-[11px] text-neutral-500">Browse, save and edit projects</div>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-neutral-600 group-hover:text-rose-400" />
          </button>
          <button
            type="button"
            onClick={() => handleDemo('creator')}
            className="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-left transition-colors group"
          >
            <div className="flex items-center gap-3">
              <Sparkles className="w-4 h-4 text-neutral-400" />
              <div>
                <div className="text-xs font-semibold text-neutral-200">Creator</div>
                <div className="text-[11px] text-neutral-500">Submit clips and track licenses</div>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-neutral-600 group-hover:text-rose-400" />
          </button>
          {DEMO_ADMIN_PERSONA_ENABLED && (
            <button
              type="button"
              onClick={() => handleDemo('admin')}
              className="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-left transition-colors group"
            >
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-4 h-4 text-neutral-400" />
                <div>
                  <div className="text-xs font-semibold text-neutral-200">Administrator (development only)</div>
                  <div className="text-[11px] text-neutral-500">Moderation, rights and AI tools</div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-neutral-600 group-hover:text-rose-400" />
            </button>
          )}
        </div>
        </>}
      </div>
    </div>
  );
};
