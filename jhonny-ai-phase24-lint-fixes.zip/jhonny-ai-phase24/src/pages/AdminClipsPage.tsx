import React from 'react';
import { Link } from '../router/Router';
import { BackendAdminPanel } from '../components/common/Phase4BackendPanels';
export const AdminClipsPage: React.FC = () => <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-white"><p className="text-xs text-neutral-400 mb-1"><Link href="/admin">Admin Console</Link> / Clip Moderation</p><h1 className="text-2xl font-bold mb-2">Clip Moderation Queue</h1><p className="text-xs text-neutral-400 mb-6">Only server-confirmed submissions and server-enforced moderation actions are shown.</p><BackendAdminPanel /></main>;
