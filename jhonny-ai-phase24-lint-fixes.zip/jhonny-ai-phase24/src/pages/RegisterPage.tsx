import React, { useState } from 'react';
import { Link } from '../router/Router';
import { ShieldCheck } from 'lucide-react';
import { registerApi, ApiError } from '../lib/api';

export const RegisterPage: React.FC = () => {

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [accountType, setAccountType] = useState<'user' | 'creator'>('user');

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setError(null); setSuccess(null);
    try { await registerApi(name.trim(), email.trim(), password); setSuccess(accountType === 'creator' ? 'Account created as a user. Creator privileges must be granted by an administrator after review.' : 'Account created. You can now sign in.'); }
    catch (err) { setError(err instanceof ApiError ? err.message : 'Registration failed.'); } finally { setBusy(false); }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl p-6 sm:p-8">
        <div className="text-center mb-6">
          <Link href="/" className="inline-block text-xl font-extrabold text-white mb-2">
            JHONNY <span className="text-rose-500">AI</span>
          </Link>
          <h1 className="text-lg font-bold text-white tracking-tight">Create your account</h1>
          <p className="text-xs text-neutral-400 mt-1">
            Free access to thousands of licensed vertical short clips
          </p>
        </div>

        <div role="status" className="mb-6 p-3 rounded-xl bg-neutral-950 border border-neutral-800 text-[11px] text-neutral-300">
          <div className="flex items-center gap-1.5 font-semibold"><ShieldCheck className="w-3.5 h-3.5 text-rose-400" /><span>Server-backed registration</span></div>
          <p>New accounts are created with the user role. Creator and administrator privileges cannot be self-assigned.</p>
        </div>

        <form onSubmit={handleRegister} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1">Account Intent</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setAccountType('user')}
                className={`py-2 px-3 rounded-lg border text-xs font-medium transition-colors ${
                  accountType === 'user'
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                    : 'bg-neutral-950 text-neutral-400 border-neutral-800 hover:text-neutral-200'
                }`}
              >
                Channel Publisher
              </button>
              <button
                type="button"
                onClick={() => setAccountType('creator')}
                className={`py-2 px-3 rounded-lg border text-xs font-medium transition-colors ${
                  accountType === 'creator'
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                    : 'bg-neutral-950 text-neutral-400 border-neutral-800 hover:text-neutral-200'
                }`}
              >
                Content Creator
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1">Full Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Jordan Miller"
              className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 focus:outline-none focus:border-rose-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1">Email address</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="jordan@example.com"
              className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 focus:outline-none focus:border-rose-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1">Password</label>
            <input
              type="password"
              required
              minLength={10}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 focus:outline-none focus:border-rose-500"
            />
          </div>

          <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 text-[11px] text-neutral-400">
            By creating an account, you agree to comply with JHONNY AI syndication licensing terms and acceptable platform use rules.
          </div>

          {error && <p role="alert" className="text-xs text-rose-300">{error}</p>}
          {success && <p role="status" className="text-xs text-emerald-300">{success}</p>}
          <button
            type="submit"
            className="w-full py-2.5 rounded-lg bg-rose-500 hover:bg-rose-600 text-white font-semibold text-xs transition-colors shadow-md"
          >
            {busy ? 'Creating account…' : 'Create account'}
          </button>

        </form>

        <p className="mt-6 text-center text-xs text-neutral-400">
          Already registered?{' '}
          <Link href="/login" className="text-rose-400 hover:text-rose-300 font-medium">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
};
