import React, { useState } from 'react';
import { Link } from '../router/Router';
import { useApp } from '../context/AppContext';
import { StatCard } from '../components/common/StatCard';
import { DollarSign, TrendingUp, Calendar, CreditCard, AlertTriangle } from 'lucide-react';

export const CreatorEarningsPage: React.FC = () => {
  const { currentUser, addToast } = useApp();
  const [payoutMethod, setPayoutMethod] = useState<'paypal' | 'bank'>('bank');
  const [payoutEmail, setPayoutEmail] = useState('marcus@vanguardmedia.com');

  const monthlyData = [
    { month: 'March 2026', downloads: '48,200', cpm: '$12.40', earnings: '$597.68', status: 'Paid' },
    { month: 'February 2026', downloads: '41,500', cpm: '$11.80', earnings: '$489.70', status: 'Paid' },
    { month: 'January 2026', downloads: '28,100', cpm: '$12.10', earnings: '$340.01', status: 'Paid' },
    { month: 'Current (April)', downloads: '14,200', cpm: '$12.20', earnings: '$173.24', status: 'Accruing' }
  ];

  const handleUpdatePayout = (e: React.FormEvent) => {
    e.preventDefault();
    addToast('Payouts Not Connected', 'Nothing was saved. This build has no payout provider.', 'warning');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-neutral-400 mb-1">
            <Link href="/creator" className="hover:text-white">Creator Portal</Link>
            <span>/</span>
            <span className="text-neutral-200">Revenue & Earnings</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Ad Revenue Share</h1>
          <p className="text-xs text-neutral-400">
            Phase 1 model: Ad-supported monetization pool distributed based on verified syndication downloads
          </p>
        </div>
      </div>

      <div role="note" className="mb-6 p-3 rounded-xl bg-amber-500/5 border border-amber-500/30 text-[11px] text-amber-200 flex gap-2">
        <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
        <p>
          Sample data. The revenue figures, monthly rows and "Paid" statuses on this page are illustrative placeholders.
          No ad revenue is tracked and no payouts are made in this build.
        </p>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <StatCard
          label="Lifetime Ad Revenue"
          value="$1,600.63"
          change="+$173.24 accrued this month"
          trend="up"
          icon={DollarSign}
          description="Direct creator revenue share"
        />
        <StatCard
          label="Effective Download CPM"
          value="$12.15"
          change="Top tier syndication rate"
          trend="up"
          icon={TrendingUp}
          description="Calculated per 1,000 downloads"
        />
        <StatCard
          label="Next Scheduled Payout"
          value="April 15, 2026"
          trend="neutral"
          icon={Calendar}
          description="Direct ACH / Bank Wire"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-8">
        {/* Monthly Breakdown Table (8 cols) */}
        <div className="lg:col-span-8 bg-neutral-900/60 rounded-xl border border-neutral-800 overflow-hidden">
          <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between">
            <h3 className="font-semibold text-sm text-neutral-100">Monthly Earnings Statement</h3>
            <span className="text-xs text-neutral-400 font-mono">Net 15 Payout Cadence</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-neutral-950/80 border-b border-neutral-800 text-neutral-400 uppercase font-mono text-[10px]">
                <tr>
                  <th className="py-3 px-4 font-semibold">Billing Period</th>
                  <th className="py-3 px-4 font-semibold text-right">Syndication Downloads</th>
                  <th className="py-3 px-4 font-semibold text-right">Effective CPM</th>
                  <th className="py-3 px-4 font-semibold text-right">Net Share</th>
                  <th className="py-3 px-4 font-semibold text-right">Payout Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800">
                {monthlyData.map((row) => (
                  <tr key={row.month} className="hover:bg-neutral-900/40">
                    <td className="py-3.5 px-4 font-medium text-neutral-200">
                      {row.month}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono tabular-nums text-neutral-300">
                      {row.downloads}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono tabular-nums text-neutral-400">
                      {row.cpm}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono tabular-nums font-semibold text-neutral-100">
                      {row.earnings}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[11px] font-medium font-mono ${
                          row.status === 'Paid'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        }`}
                      >
                        {row.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Payout Settings Form (4 cols) */}
        <div className="lg:col-span-4 bg-neutral-900/60 rounded-xl border border-neutral-800 p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <CreditCard className="w-4 h-4 text-rose-400" />
              <h3 className="font-semibold text-sm text-neutral-100">Payout Preferences</h3>
            </div>
            <p className="text-xs text-neutral-400 mb-4">
              Earnings are disbursed monthly when balance reaches the $50 minimum threshold.
            </p>

            <form onSubmit={handleUpdatePayout} className="space-y-4 text-xs">
              <div>
                <label className="block font-medium text-neutral-300 mb-1">Payout Method</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPayoutMethod('bank')}
                    className={`py-2 px-3 rounded-lg border text-xs font-medium transition-colors ${
                      payoutMethod === 'bank'
                        ? 'bg-neutral-800 text-white border-neutral-600'
                        : 'bg-neutral-950 text-neutral-400 border-neutral-800'
                    }`}
                  >
                    Direct ACH / Wire
                  </button>
                  <button
                    type="button"
                    onClick={() => setPayoutMethod('paypal')}
                    className={`py-2 px-3 rounded-lg border text-xs font-medium transition-colors ${
                      payoutMethod === 'paypal'
                        ? 'bg-neutral-800 text-white border-neutral-600'
                        : 'bg-neutral-950 text-neutral-400 border-neutral-800'
                    }`}
                  >
                    PayPal Express
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-medium text-neutral-300 mb-1">
                  {payoutMethod === 'bank' ? 'Routing / Account Reference' : 'PayPal Email'}
                </label>
                <input
                  type="text"
                  value={payoutEmail}
                  onChange={(e) => setPayoutEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 focus:outline-none focus:border-rose-500 font-mono"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-medium text-xs border border-neutral-700 transition-colors"
              >
                Save Payout Account
              </button>
            </form>
          </div>

          <div className="mt-6 pt-4 border-t border-neutral-800 text-[11px] text-neutral-500 leading-relaxed">
            Note: Prototype demonstration. No real banking or tax reporting services are invoked.
          </div>
        </div>
      </div>
    </div>
  );
};
