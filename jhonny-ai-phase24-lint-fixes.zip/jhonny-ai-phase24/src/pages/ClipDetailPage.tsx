import React, { useEffect, useState } from 'react';
import { useRouter, Link } from '../router/Router';
import { useApp } from '../context/AppContext';
import { ClipCard } from '../components/common/ClipCard';
import { EmptyState } from '../components/common/EmptyState';
import { AdPlacement } from '../components/common/AdPlacement';
import { canViewClipDetail, canDownloadClip, isPublicClip } from '../lib/rights';
import { ApiError, ApiClip, apiRequest, downloadApiFile, fetchApiClip } from '../lib/api';
import {
  Download,
  Bookmark,
  Share2,
  ShieldCheck,
  CheckCircle2,
  Play,
  Pause,
  Volume2,
  VolumeX,
  RotateCcw,
  Flag,
  Video,
  Sliders
} from 'lucide-react';

export const ClipDetailPage: React.FC = () => {
  const { params, navigate } = useRouter();
  const {
    currentUser,
    getClipBySlug,
    clips,
    openDownloadModal,
    openStudioModal,
    toggleSaveClip,
    isClipSaved,
    submitReport,
    addToast
  } = useApp();

  const slug = params.slug || '';
  const clip = getClipBySlug(slug);
  const [serverClip, setServerClip] = useState<(ApiClip & { license_id?: string }) | null>(null);
  const [serverState, setServerState] = useState<'loading'|'ready'|'missing'|'error'>('loading');
  const [serverError, setServerError] = useState('');
  const [downloadBusy, setDownloadBusy] = useState(false);
  const [liveReportOpen, setLiveReportOpen] = useState(false);
  const [liveReportName, setLiveReportName] = useState('');
  const [liveReportEmail, setLiveReportEmail] = useState('');
  const [liveReportReason, setLiveReportReason] = useState('Copyright Infringement');
  const [liveReportDetails, setLiveReportDetails] = useState('');
  const [liveReportBusy, setLiveReportBusy] = useState(false);
  useEffect(() => {
    let active = true;
    setServerState('loading'); setServerClip(null); setServerError('');
    fetchApiClip(slug).then(data => { if (active) { setServerClip(data); setServerState('ready'); } }).catch(error => {
      if (!active) return;
      if (error instanceof ApiError && error.status === 404) setServerState('missing');
      else { setServerState('error'); setServerError(error instanceof Error ? error.message : 'Unable to load clip details.'); }
    });
    return () => { active = false; };
  }, [slug]);

  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [isLooping, setIsLooping] = useState(true);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportReason, setReportReason] = useState<'Copyright Infringement' | 'Unauthorized Re-upload' | 'Misattribution' | 'Other'>('Copyright Infringement');
  const [reporterName, setReporterName] = useState('');
  const [reporterEmail, setReporterEmail] = useState('');
  const [reportDetails, setReportDetails] = useState('');

  if (serverState === 'loading') return <div className="max-w-4xl mx-auto px-4 py-20 text-center text-neutral-300">Loading clip details from JHONNY AI…</div>;
  if (serverState === 'error') return <div className="max-w-4xl mx-auto px-4 py-20"><EmptyState icon={Video} title="Clip details unavailable" description={serverError || 'The backend could not load this clip.'} actionLabel="Return to Clip Library" onAction={() => navigate('/clips')} /></div>;
  if (serverState === 'missing' || !serverClip) return <div className="max-w-4xl mx-auto px-4 py-20"><EmptyState icon={Video} title="Clip not found" description="No accessible published clip matches this URL. Pending, suspended, removed, and unlicensed media are not disclosed publicly." actionLabel="Return to Clip Library" onAction={() => navigate('/clips')} /></div>;

  const validServerClip = serverClip;
  const liveUses = Array.isArray(validServerClip.allowed_uses) ? validServerClip.allowed_uses : (() => { try { return JSON.parse(validServerClip.allowed_uses || '[]'); } catch { return []; } })();
  const licenseValid = validServerClip.license_status === 'Active' && (!validServerClip.expires_at || Date.parse(validServerClip.expires_at) > Date.now());
  const downloadEligible = validServerClip.status === 'Published' && licenseValid && liveUses.includes('personal');
  const handleRealDownload = async () => {
    setDownloadBusy(true);
    try { await downloadApiFile(`/api/clips/${encodeURIComponent(validServerClip.id)}/download?requested_use=personal`, `${validServerClip.title.replace(/[^a-z0-9._ -]/gi, '_').trim() || 'jhonny-clip'}.mp4`); addToast('Download started', 'The authorized media response was received.', 'success'); }
    catch (error) { addToast('Download unavailable', error instanceof Error ? error.message : 'The server could not provide this media.', 'error'); }
    finally { setDownloadBusy(false); }
  };
  const submitLiveReport = async (event: React.FormEvent) => { event.preventDefault(); setLiveReportBusy(true); try { await apiRequest('/api/reports?clip_id=' + encodeURIComponent(validServerClip.id), { method: 'POST', body: JSON.stringify({ reporter_name: liveReportName, reporter_email: liveReportEmail, reason: liveReportReason, details: liveReportDetails }) }); addToast('Report submitted', 'Your report was saved for administrator review.', 'success'); setLiveReportOpen(false); setLiveReportName(''); setLiveReportEmail(''); setLiveReportDetails(''); } catch (error) { addToast('Report not submitted', error instanceof Error ? error.message : 'The server could not save this report.', 'error'); } finally { setLiveReportBusy(false); } };
  const serverDetail = <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10 text-neutral-100">
    <button onClick={() => navigate('/clips')} className="text-sm text-neutral-400 hover:text-white mb-6">← Back to Library</button>
    <div className="grid gap-8 md:grid-cols-[minmax(0,1fr)_320px]">
      <section className="rounded-2xl border border-neutral-800 bg-neutral-950 p-6">
        <div className="aspect-video rounded-xl bg-neutral-900 flex items-center justify-center mb-6"><Video size={48} className="text-neutral-600" /></div>
        <h1 className="text-2xl font-bold">{validServerClip.title}</h1>
        <p className="mt-2 text-sm text-neutral-400">Creator: {validServerClip.creator_name || 'Creator unavailable'}</p>
        <div className="mt-5 grid grid-cols-2 gap-3 text-sm"><div className="rounded-lg bg-neutral-900 p-3"><div className="text-neutral-500">Duration</div><div>{validServerClip.duration ? `${Math.floor(validServerClip.duration / 60)}:${String(Math.floor(validServerClip.duration % 60)).padStart(2,'0')}` : 'Unavailable'}</div></div><div className="rounded-lg bg-neutral-900 p-3"><div className="text-neutral-500">Publication</div><div>{validServerClip.status}</div></div></div>
        <p className="mt-4 text-xs text-neutral-500">Published {validServerClip.created_at ? new Date(validServerClip.created_at).toLocaleDateString() : 'date unavailable'}</p>
        <div className="mt-5 flex flex-wrap gap-2"><button onClick={() => toggleSaveClip(validServerClip.id)} className="rounded-lg border border-neutral-700 px-3 py-2 text-sm">{isClipSaved(validServerClip.id) ? 'Saved' : 'Save clip'}</button><button onClick={() => { if (navigator.clipboard) void navigator.clipboard.writeText(window.location.href).then(() => addToast('Link copied','Clip link copied to clipboard.','success')).catch(() => addToast('Copy unavailable','Copy the URL from your browser address bar.','warning')); }} className="rounded-lg border border-neutral-700 px-3 py-2 text-sm">Share</button><button onClick={() => setLiveReportOpen(true)} className="rounded-lg border border-neutral-700 px-3 py-2 text-sm">Report / Rights inquiry</button></div>
      </section>
      <aside className="rounded-2xl border border-neutral-800 bg-neutral-950 p-5 h-fit"><h2 className="font-semibold flex items-center gap-2"><ShieldCheck size={18}/> Rights & Download</h2>
        <p className="mt-4 text-sm">License: <strong>{validServerClip.license_status || 'No license record'}</strong></p>
        <p className="mt-2 text-sm text-neutral-400">Allowed uses: {liveUses.length ? liveUses.join(', ') : 'None recorded'}</p>
        <p className="mt-2 text-sm text-neutral-400">{validServerClip.expires_at ? `Expires ${new Date(validServerClip.expires_at).toLocaleString()}` : 'No expiry recorded'}</p>
        <p className={`mt-4 text-sm ${downloadEligible ? 'text-emerald-400' : 'text-amber-400'}`}>{downloadEligible ? 'Eligible for personal-use download' : 'Download not eligible under current publication/license rules'}</p>
        <button disabled={!downloadEligible || downloadBusy} onClick={handleRealDownload} className="mt-5 w-full rounded-lg bg-violet-600 px-4 py-3 font-semibold disabled:opacity-40">{downloadBusy ? 'Requesting…' : 'Download original media'}</button>
      </aside>
    </div>
    {liveReportOpen && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"><form onSubmit={submitLiveReport} className="w-full max-w-lg space-y-3 rounded-xl border border-neutral-700 bg-neutral-900 p-5"><h2 className="font-semibold">Report clip / rights inquiry</h2><input required maxLength={120} value={liveReportName} onChange={e=>setLiveReportName(e.target.value)} placeholder="Your name" className="w-full rounded bg-neutral-950 border border-neutral-700 p-2 text-sm"/><input required type="email" value={liveReportEmail} onChange={e=>setLiveReportEmail(e.target.value)} placeholder="Your email" className="w-full rounded bg-neutral-950 border border-neutral-700 p-2 text-sm"/><select value={liveReportReason} onChange={e=>setLiveReportReason(e.target.value)} className="w-full rounded bg-neutral-950 border border-neutral-700 p-2 text-sm"><option>Copyright Infringement</option><option>Unauthorized Re-upload</option><option>Misattribution</option><option>Other</option></select><textarea required minLength={10} maxLength={5000} value={liveReportDetails} onChange={e=>setLiveReportDetails(e.target.value)} placeholder="Describe the issue and provide evidence links" className="w-full rounded bg-neutral-950 border border-neutral-700 p-2 text-sm" rows={4}/><div className="flex justify-end gap-2"><button type="button" onClick={()=>setLiveReportOpen(false)} className="rounded border border-neutral-700 px-3 py-2 text-sm">Cancel</button><button disabled={liveReportBusy} className="rounded bg-rose-600 px-3 py-2 text-sm disabled:opacity-50">{liveReportBusy?'Submitting…':'Submit report'}</button></div></form></div>}
  </div>;

  // The API response is authoritative. Use it when this clip is not in the local
  // catalog; otherwise keep the existing creator/studio/review UI after the
  // server has confirmed that this URL resolves to an accessible clip.
  if (!clip) return serverDetail;

  // Non-public clips are hidden from everyone except administrators reviewing them.
  // The message is the same as "not found" so takedown status is not disclosed.
  if (!canViewClipDetail(clip, currentUser?.role)) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20">
        <EmptyState
          icon={Video}
          title="Clip not available"
          description="This clip is not available. It may have been removed or disabled, or the URL may be incorrect."
          actionLabel="Return to Clip Library"
          onAction={() => navigate('/clips')}
        />
      </div>
    );
  }

  const validClip = clip;
  const saved = isClipSaved(validClip.id);
  const downloadDecision = canDownloadClip(validClip);
  const reviewOnly = currentUser?.role === 'admin' && !isPublicClip(validClip);
  const relatedClips = clips
    .filter(c => c.id !== validClip.id && c.category === validClip.category && isPublicClip(c))
    .slice(0, 4);

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      addToast('Link Copied', 'Clip URL copied to clipboard.', 'success');
    }
  };

  const handleSubmitReport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reporterName || !reporterEmail || !reportDetails) {
      addToast('Incomplete Report', 'Please fill out all required fields.', 'warning');
      return;
    }
    submitReport({
      clipId: validClip.id,
      clipTitle: validClip.title,
      creatorName: validClip.creator.name,
      reporterName,
      reporterEmail,
      reason: reportReason,
      details: reportDetails
    });
    setReportModalOpen(false);
    setReporterName('');
    setReporterEmail('');
    setReportDetails('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-neutral-400 mb-6">
        <Link href="/" className="hover:text-white">Home</Link>
        <span>/</span>
        <Link href="/clips" className="hover:text-white">Clips</Link>
        <span>/</span>
        <Link href={`/clips?category=${encodeURIComponent(validClip.category)}`} className="hover:text-white">
          {validClip.category}
        </Link>
        <span>/</span>
        <span className="text-neutral-200 truncate max-w-xs">{validClip.title}</span>
      </div>

      {/* Main Grid: Player + Information & Clearance */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-16">
        {/* Left Column: Vertical Video Player / Display (7 cols) */}
        <div className="lg:col-span-7 flex flex-col items-center">
          <div className="w-full max-w-md aspect-[9/16] bg-black rounded-2xl border border-neutral-800 shadow-2xl relative overflow-hidden group">
            {/* Visual Thumbnail / Video Feed */}
            <img
              src={validClip.thumbnail}
              alt={validClip.title}
              className="w-full h-full object-cover"
            />

            {/* Live Playing Indicator */}
            {isPlaying && (
              <div className="absolute top-4 left-4 z-10 px-2.5 py-1 rounded-md bg-black/60 backdrop-blur-md text-[11px] font-mono text-emerald-400 border border-emerald-500/20 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>60 FPS PREVIEW</span>
              </div>
            )}

            {/* Play/Pause Overlay Click */}
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="absolute inset-0 flex items-center justify-center focus:outline-none"
              aria-label={isPlaying ? 'Pause' : 'Play'}
            >
              {!isPlaying && (
                <div className="w-16 h-16 rounded-full bg-white/90 text-neutral-950 flex items-center justify-center shadow-2xl hover:scale-110 transition-transform">
                  <Play className="w-8 h-8 ml-1 fill-current" />
                </div>
              )}
            </button>

            {/* Bottom Scrim & Control Bar */}
            <div className="absolute inset-x-0 bottom-0 p-4 bg-gradient-to-t from-neutral-950 via-neutral-950/80 to-transparent">
              <div className="flex items-center justify-between text-neutral-300">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="p-1.5 hover:text-white"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
                  </button>
                  <button
                    onClick={() => setIsMuted(!isMuted)}
                    className="p-1.5 hover:text-white"
                  >
                    {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => setIsLooping(!isLooping)}
                    className={`p-1.5 ${isLooping ? 'text-rose-400' : 'text-neutral-500'}`}
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>
                <span className="font-mono text-xs tabular-nums text-neutral-300">
                  {validClip.durationFormatted} / 1080×1920
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Clip Details & Actions (5 cols) */}
        <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
          <div>
            {/* Unboxed Metadata (Zero-Pill Rule) */}
            <div className="flex items-center gap-2 text-xs text-neutral-400 mb-2 font-medium">
              <span className="text-neutral-300">{validClip.category}</span>
              <span aria-hidden="true" className="text-neutral-600">·</span>
              <span className="font-mono tabular-nums">{validClip.downloads.toLocaleString()} downloads</span>
              <span aria-hidden="true" className="text-neutral-600">·</span>
              <span className="font-mono tabular-nums">{validClip.fps} FPS</span>
            </div>

            {/* Title */}
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight leading-snug mb-3">
              {validClip.title}
            </h1>

            {/* Description */}
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed mb-5">
              {validClip.description}
            </p>

            {/* Creator Lockup */}
            <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800 flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <img
                  src={validClip.creator.avatar}
                  alt={validClip.creator.name}
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-full object-cover border border-neutral-700"
                />
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-semibold text-neutral-200">
                      {validClip.creator.name}
                    </span>
                    {validClip.creator.verified && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                    )}
                  </div>
                  <span className="text-[11px] font-mono text-neutral-400">
                    {validClip.creator.handle}
                  </span>
                </div>
              </div>
              <Link
                href={`/clips?creator=${encodeURIComponent(validClip.creatorId)}`}
                className="text-xs font-medium text-rose-400 hover:text-rose-300"
              >
                More clips →
              </Link>
            </div>

            {/* Primary Action Buttons */}
            <div className="space-y-2.5 mb-6">
              <button
                onClick={() => openStudioModal(validClip)}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-rose-500 via-rose-600 to-rose-500 hover:from-rose-600 hover:to-rose-700 text-white font-bold text-sm flex items-center justify-center gap-2.5 shadow-lg shadow-rose-950/60 transition-all active:scale-[0.98] border border-rose-400/30"
              >
                <Sliders className="w-4 h-4" />
                <span>Edit Clip in Studio (Captions, Reframe, Hooks)</span>
              </button>

              {reviewOnly && (
                <p className="text-[11px] text-amber-300 bg-amber-500/5 border border-amber-500/30 rounded-lg p-2.5">
                  Review mode: this clip is not public ({validClip.status}). Visitors cannot see or download it.
                </p>
              )}

              <button
                onClick={() => openDownloadModal(validClip)}
                disabled={!downloadDecision.allowed}
                aria-describedby={downloadDecision.allowed ? undefined : 'download-unavailable'}
                className={`w-full py-3 px-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 border transition-all ${
                  downloadDecision.allowed
                    ? 'bg-neutral-900 hover:bg-neutral-800 text-neutral-100 border-neutral-700/80 active:scale-[0.98]'
                    : 'bg-neutral-900/60 text-neutral-500 border-neutral-800 cursor-not-allowed'
                }`}
              >
                <Download className="w-4 h-4 text-neutral-400" />
                <span>{downloadDecision.allowed ? 'Download MP4' : 'Download unavailable'}</span>
              </button>
              {!downloadDecision.allowed && (
                <p id="download-unavailable" className="text-[11px] text-neutral-400">
                  {'message' in downloadDecision ? downloadDecision.message : 'Download is unavailable.'}
                </p>
              )}

              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => toggleSaveClip(validClip.id)}
                  className={`py-2 px-3 rounded-lg border text-xs font-medium flex items-center justify-center gap-1.5 transition-colors ${
                    saved
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                      : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border-neutral-800'
                  }`}
                >
                  <Bookmark className={`w-3.5 h-3.5 ${saved ? 'fill-current' : ''}`} />
                  <span>{saved ? 'Saved' : 'Save'}</span>
                </button>

                <button
                  onClick={handleShare}
                  className="py-2 px-3 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-800 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Share</span>
                </button>

                <button
                  onClick={() => setReportModalOpen(true)}
                  className="py-2 px-3 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-rose-400 border border-neutral-800 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Flag className="w-3.5 h-3.5" />
                  <span>Report</span>
                </button>
              </div>
            </div>

            {/* Rights & Licensing Box */}
            <div className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 text-xs space-y-2">
              <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                <ShieldCheck className="w-4 h-4" />
                <span>Verified Syndication License</span>
              </div>
              <p className="text-[11px] text-neutral-400 leading-relaxed">
                This media is provided directly to JHONNY AI with permission from{' '}
                <strong className="text-neutral-200">{validClip.creator.name}</strong>. Permitted for social media republication without watermarks.
              </p>
              <div className="pt-2 border-t border-neutral-800/80 grid grid-cols-2 gap-2 text-[11px] font-mono text-neutral-400">
                <div>
                  <span className="text-neutral-500 block">License Type:</span>
                  <span className="text-neutral-300">{validClip.licenseInfo.type}</span>
                </div>
                <div>
                  <span className="text-neutral-500 block">Platforms:</span>
                  <span className="text-neutral-300">TikTok, Reels, Shorts</span>
                </div>
              </div>
            </div>
          </div>

          {/* Tags */}
          <div className="pt-4 border-t border-neutral-900">
            <span className="text-xs text-neutral-500 block mb-2 font-mono uppercase tracking-wider">
              Keywords
            </span>
            <div className="flex flex-wrap gap-1.5">
              {validClip.tags.map(t => (
                <Link
                  key={t}
                  href={`/clips?q=${encodeURIComponent(t)}`}
                  className="px-2.5 py-1 rounded bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200 text-xs font-mono border border-neutral-800 transition-colors"
                >
                  #{t}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Ad Placement */}
      <AdPlacement type="leaderboard" />

      {/* Related Clips */}
      {relatedClips.length > 0 && (
        <section className="py-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-white tracking-tight">
              More in {validClip.category}
            </h2>
            <Link
              href={`/clips?category=${encodeURIComponent(validClip.category)}`}
              className="text-xs font-medium text-rose-400 hover:text-rose-300"
            >
              Browse all {validClip.category} →
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {relatedClips.map((rel, idx) => (
              <ClipCard key={`${rel.id}-${idx}`} clip={rel} />
            ))}
          </div>
        </section>
      )}

      {/* Report / DMCA inquiry modal */}
      {reportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl p-6">
            <h3 className="font-semibold text-sm text-neutral-100 mb-1">Report Clip / Rights Inquiry</h3>
            <p className="text-xs text-neutral-400 mb-4">
              If you believe this clip infringes on your intellectual property or was published without valid authorization, submit a notice below.
            </p>

            <form onSubmit={handleSubmitReport} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Your Name</label>
                <input
                  type="text"
                  required
                  value={reporterName}
                  onChange={(e) => setReporterName(e.target.value)}
                  placeholder="Full name or company representative"
                  className="w-full px-3 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Contact Email</label>
                <input
                  type="email"
                  required
                  value={reporterEmail}
                  onChange={(e) => setReporterEmail(e.target.value)}
                  placeholder="legal@rightsowner.com"
                  className="w-full px-3 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Reason</label>
                <select
                  value={reportReason}
                  onChange={(e) => setReportReason(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 focus:outline-none focus:border-rose-500"
                >
                  <option value="Copyright Infringement">Copyright Infringement</option>
                  <option value="Unauthorized Re-upload">Unauthorized Re-upload</option>
                  <option value="Misattribution">Misattribution</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Description / Proof</label>
                <textarea
                  rows={3}
                  required
                  value={reportDetails}
                  onChange={(e) => setReportDetails(e.target.value)}
                  placeholder="Provide original copyright proof or broadcast link..."
                  className="w-full px-3 py-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="pt-3 border-t border-neutral-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setReportModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg bg-neutral-800 text-xs text-neutral-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold"
                >
                  Submit Report
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
