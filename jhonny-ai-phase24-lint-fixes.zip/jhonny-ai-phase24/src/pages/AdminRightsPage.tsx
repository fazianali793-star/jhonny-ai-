import React from 'react';
import { AdminLiveDataPage } from './AdminLiveDataPage';
export const AdminRightsPage: React.FC = () => <AdminLiveDataPage section="licenses" />;
