import React, { useState } from 'react';
import { ShieldCheck, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const CopyrightPage: React.FC = () => {
  const { submitReport, addToast } = useApp();

  const [clipTitle, setClipTitle] = useState('');
  const [reporterName, setReporterName] = useState('');
  const [reporterEmail, setReporterEmail] = useState('');
  const [reporterOrg, setReporterOrg] = useState('');
  const [details, setDetails] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clipTitle || !reporterName || !reporterEmail || !details) return;

    submitReport({
      clipId: 'inquiry-' + Date.now(),
      clipTitle,
      creatorName: 'Unknown / Platform Clip',
      reporterName,
      reporterEmail,
      reporterOrg: reporterOrg || undefined,
      reason: 'Copyright Infringement',
      details
    });

    setIsSubmitted(true);
    addToast('DMCA Claim Logged', 'Your notice has entered our expedited compliance triage queue.', 'success');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Title */}
      <div className="mb-10 text-center">
        <div className="inline-flex items-center gap-2 text-xs font-mono text-emerald-400 mb-2">
          <ShieldCheck className="w-4 h-4" />
          <span>Rights Clearance & DMCA Enforcement</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Copyright & Intellectual Property Policy
        </h1>
        <p className="text-xs sm:text-sm text-neutral-400 mt-2 max-w-2xl mx-auto">
          JHONNY AI operates strictly as an authorized, permission-cleared video syndication platform.
        </p>
      </div>

      {/* Core Principles */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
        <div className="p-5 rounded-xl bg-neutral-900/60 border border-neutral-800">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-rose-400 font-mono mb-2">
            01. Authorized Content Only
          </h3>
          <p className="text-xs text-neutral-300 leading-relaxed">
            JHONNY AI only accepts content provided directly by original creators, verified tournament operators, or authorized rights owners who hold explicit legal syndication rights.
          </p>
        </div>

        <div className="p-5 rounded-xl bg-neutral-900/60 border border-neutral-800">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-rose-400 font-mono mb-2">
            02. Creator Warranties
          </h3>
          <p className="text-xs text-neutral-300 leading-relaxed">
            Content creators are solely responsible for certifying that their uploads do not infringe on third-party trademarks, synchronized master recordings, or broadcast exclusivity pacts.
          </p>
        </div>

        <div className="p-5 rounded-xl bg-neutral-900/60 border border-neutral-800">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-rose-400 font-mono mb-2">
            03. Immediate Takedown Protocol
          </h3>
          <p className="text-xs text-neutral-300 leading-relaxed">
            Upon receipt of a bona fide rights inquiry or DMCA notification, JHONNY AI immediately disables public access to disputed clips pending compliance audit.
          </p>
        </div>
      </div>

      {/* Policy Details */}
      <div className="bg-neutral-900/40 rounded-2xl border border-neutral-800 p-6 sm:p-8 space-y-6 text-xs text-neutral-300 leading-relaxed mb-12">
        <section>
          <h2 className="text-sm font-bold text-white mb-2">1. Downloader License Scope</h2>
          <p>
            Users who download clips from JHONNY AI receive a revocable, non-exclusive license to republish the clip on short-form platforms (TikTok, Instagram Reels, YouTube Shorts, and X) in accordance with the specific license attributes displayed on the clip's detail page. Users may not resell, sublicense, or register copyright in the downloaded clips.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-bold text-white mb-2">2. Notice and Takedown Procedure</h2>
          <p>
            If you are a copyright owner or authorized agent thereof and believe that any clip published on JHONNY AI infringes upon your copyright, you may submit a formal notification by completing the dispute intake form below.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-bold text-white mb-2">3. Counter-Notification Procedure</h2>
          <p>
            If a clip uploaded by a partner creator is removed pursuant to a copyright notice, the affected creator will be given notice and the opportunity to submit a counter-notice certifying authorized rights or fair use.
          </p>
        </section>
      </div>

      {/* Online Takedown Submission Form */}
      <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-6 sm:p-8">
        <div className="flex items-center gap-2 mb-2">
          <AlertTriangle className="w-5 h-5 text-rose-400" />
          <h2 className="text-base font-bold text-white">Submit a Rights Claim or DMCA Notice</h2>
        </div>
        <p className="text-xs text-neutral-400 mb-6">
          Our legal compliance department reviews submissions within 24 hours.
        </p>

        {isSubmitted ? (
          <div className="p-6 rounded-xl bg-neutral-950 border border-neutral-800 text-center space-y-3">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
            <h3 className="text-sm font-semibold text-neutral-100">Notice Registered</h3>
            <p className="text-xs text-neutral-400 max-w-md mx-auto">
              Thank you for submitting your inquiry. The target media item has been flagged for legal compliance review in the admin queue.
            </p>
            <button
              onClick={() => setIsSubmitted(false)}
              className="px-4 py-2 rounded-lg bg-neutral-800 text-xs font-medium text-neutral-200"
            >
              Submit Another Inquiry
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-medium text-neutral-300 mb-1">Your Full Name *</label>
                <input
                  type="text"
                  required
                  value={reporterName}
                  onChange={(e) => setReporterName(e.target.value)}
                  placeholder="e.g. Jane Doe"
                  className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-200 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block font-medium text-neutral-300 mb-1">Contact Email *</label>
                <input
                  type="email"
                  required
                  value={reporterEmail}
                  onChange={(e) => setReporterEmail(e.target.value)}
                  placeholder="legal@rightsowner.com"
                  className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-200 focus:outline-none focus:border-rose-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-medium text-neutral-300 mb-1">Target Clip URL or Title *</label>
                <input
                  type="text"
                  required
                  value={clipTitle}
                  onChange={(e) => setClipTitle(e.target.value)}
                  placeholder="Paste URL or exact clip title"
                  className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-200 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block font-medium text-neutral-300 mb-1">Represented Organization (Optional)</label>
                <input
                  type="text"
                  value={reporterOrg}
                  onChange={(e) => setReporterOrg(e.target.value)}
                  placeholder="e.g. Apex Rights Management"
                  className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-200 focus:outline-none focus:border-rose-500"
                />
              </div>
            </div>

            <div>
              <label className="block font-medium text-neutral-300 mb-1">Statement of Claim & Evidence *</label>
              <textarea
                rows={4}
                required
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="Explain why this content constitutes an unauthorized synchronization, broadcast breach, or intellectual property violation..."
                className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-200 focus:outline-none focus:border-rose-500"
              />
            </div>

            <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 text-[11px] text-neutral-400">
              By submitting this notice, you state under penalty of perjury that you have a good faith belief that the disputed use of the material is not authorized by the copyright owner, its agent, or the law.
            </div>

            <button
              type="submit"
              className="py-2.5 px-6 rounded-lg bg-rose-500 hover:bg-rose-600 text-white font-semibold text-xs shadow-md transition-colors"
            >
              Submit Formal Takedown Notice
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
