import React, { useState } from 'react';
import { CheckCircle2, MessageSquare } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ContactPage: React.FC = () => {
  const { addToast } = useApp();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('Licensing Inquiry');
  const [message, setMessage] = useState('');
  const [isSent, setIsSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !message) return;
    setIsSent(true);
    addToast('Message Transmitted', 'Our operational team will follow up at your provided email.', 'success');
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-1.5 text-xs font-mono text-rose-400 mb-2">
          <MessageSquare className="w-4 h-4" />
          <span>Support & Partnerships Desk</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white tracking-tight">Contact JHONNY AI</h1>
        <p className="text-xs sm:text-sm text-neutral-400 mt-1">
          Have licensing questions, partnership proposals, or technical inquiries?
        </p>
      </div>

      <div className="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-6 sm:p-8 shadow-xl">
        {isSent ? (
          <div className="text-center py-8 space-y-3">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
            <h3 className="text-base font-semibold text-neutral-100">Message Dispatched</h3>
            <p className="text-xs text-neutral-400 max-w-sm mx-auto">
              Thank you for reaching out. A JHONNY AI team member has received your message.
            </p>
            <button
              onClick={() => {
                setIsSent(false);
                setMessage('');
              }}
              className="px-4 py-2 rounded-lg bg-neutral-800 text-neutral-200 text-xs font-medium"
            >
              Send Another Note
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-medium text-neutral-300 mb-1">Your Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Full name"
                  className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-200 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block font-medium text-neutral-300 mb-1">Email Address *</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-200 focus:outline-none focus:border-rose-500"
                />
              </div>
            </div>

            <div>
              <label className="block font-medium text-neutral-300 mb-1">Inquiry Subject</label>
              <select
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-200 focus:outline-none focus:border-rose-500"
              >
                <option value="Licensing Inquiry">Licensing & Rights Scope Inquiry</option>
                <option value="Creator Partnership">Creator Program / Syndication Partnership</option>
                <option value="Advertiser Placement">Sponsor / Advertising Placement</option>
                <option value="Technical Support">Technical & Download Support</option>
                <option value="General">General Inquiry</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-neutral-300 mb-1">Message *</label>
              <textarea
                rows={5}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="How can we assist your publishing or creator pipeline?"
                className="w-full px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-200 focus:outline-none focus:border-rose-500"
              />
            </div>

            <button
              type="submit"
              className="py-2.5 px-6 rounded-lg bg-rose-500 hover:bg-rose-600 text-white font-semibold text-xs shadow-md transition-colors"
            >
              Transmit Inquiry
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
