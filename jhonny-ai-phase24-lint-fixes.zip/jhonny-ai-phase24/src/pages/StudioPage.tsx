import React, { useState } from 'react';
import { Film, FolderPlus, Copy, Trash2, Clock, Scissors } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useRouter, Link } from '../router/Router';
import { EmptyState } from '../components/common/EmptyState';
import { projectsForOwner, PROJECT_NAME_MAX } from '../lib/projects';
import { BackendStudioPanel } from '../components/common/Phase4BackendPanels';

export const StudioPage: React.FC = () => {
  const { currentUser, projects, clips, createProjectForUser, duplicateOwnedProject, deleteOwnedProject, addToast } = useApp();
  const { navigate } = useRouter();
  const [newName, setNewName] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const mine = projectsForOwner(projects, currentUser?.id);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    const result = createProjectForUser({
      name: newName,
      sourceClipId: null,
      trimStart: 0,
      trimEnd: 30,
      hookText: ''
    });
    if (!result.ok) {
      setFormError(result.error);
      return;
    }
    setNewName('');
    navigate(`/studio/projects/${result.project.id}`);
  };

  const handleDuplicate = (id: string) => {
    const result = duplicateOwnedProject(id);
    if (!result.ok) addToast('Could not duplicate', result.error, 'error');
  };

  const handleDelete = (id: string) => {
    const result = deleteOwnedProject(id);
    setConfirmDeleteId(null);
    if (!result.ok) addToast('Could not delete', result.error, 'error');
  };

  const sourceTitle = (clipId: string | null) => {
    if (!clipId) return 'No source clip';
    const clip = clips.find(c => c.id === clipId);
    return clip ? clip.title : 'Source clip unavailable';
  };

  // Do not expose the browser-local project editor in production. The server-backed panel owns persisted projects and real render jobs.
  if (!import.meta.env.DEV) {
    return <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8"><h1 className="text-2xl font-extrabold text-white mb-2">Studio</h1><p className="text-sm text-neutral-400 mb-6">Server-saved projects and FFmpeg render jobs.</p><BackendStudioPanel /><p className="mt-4 text-xs text-amber-300">Advanced editor controls are not yet migrated from the development-only local editor.</p></main>;
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Studio</h1>
        <p className="text-xs sm:text-sm text-neutral-400 mt-1">
          Edit clip projects, save your progress, and come back to them later.
        </p>
      </div>

      <div className="mb-6"><BackendStudioPanel /></div>
      <div className="mb-6 p-3 rounded-xl bg-neutral-950 border border-neutral-800 text-[11px] text-neutral-400 space-y-1">
        <p>Legacy Phase 2 browser-local projects remain below for compatibility. Use the server-saved projects above for backend persistence and FFmpeg render jobs.</p>
      </div>

      <form onSubmit={handleCreate} className="bg-neutral-900/80 border border-neutral-800 rounded-xl p-4 mb-6">
        <label htmlFor="new-project-name" className="block text-xs text-neutral-300 font-medium mb-2">
          New project name
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            id="new-project-name"
            type="text"
            value={newName}
            maxLength={PROJECT_NAME_MAX}
            onChange={e => setNewName(e.target.value)}
            placeholder="e.g. Podcast highlight – episode 12"
            className="flex-1 px-3 py-2 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-rose-500"
          />
          <button
            type="submit"
            className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-rose-500 hover:bg-rose-600 text-white text-xs font-semibold transition-colors"
          >
            <FolderPlus className="w-4 h-4" />
            Create project
          </button>
        </div>
        {formError && (
          <p role="alert" className="mt-2 text-[11px] text-rose-400">
            {formError}
          </p>
        )}
      </form>

      {mine.length === 0 ? (
        <EmptyState
          icon={Film}
          title="No projects yet"
          description="Create a project above, then choose a source clip and trim window in the editor."
        />
      ) : (
        <ul className="space-y-3" aria-label="Your projects">
          {mine.map(p => (
            <li
              key={p.id}
              className="bg-neutral-900/80 border border-neutral-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center gap-3 justify-between"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <h2 className="text-sm font-semibold text-neutral-100 truncate">{p.name}</h2>
                  <span
                    className={`text-[10px] font-mono uppercase px-1.5 py-0.5 rounded border ${
                      p.status === 'saved'
                        ? 'text-emerald-400 border-emerald-500/30'
                        : 'text-amber-400 border-amber-500/30'
                    }`}
                  >
                    {p.status === 'saved' ? 'Saved' : 'Draft'}
                  </span>
                </div>
                <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-neutral-400">
                  <span className="truncate max-w-xs">{sourceTitle(p.sourceClipId)}</span>
                  <span className="inline-flex items-center gap-1">
                    <Scissors className="w-3 h-3" />
                    {p.trimStart}s – {p.trimEnd}s
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    Updated {new Date(p.updatedAt).toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {confirmDeleteId === p.id ? (
                  <>
                    <span className="text-[11px] text-neutral-300">Delete this project?</span>
                    <button
                      type="button"
                      onClick={() => handleDelete(p.id)}
                      className="px-3 py-1.5 rounded-lg bg-rose-500 hover:bg-rose-600 text-white text-xs font-semibold"
                    >
                      Delete
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteId(null)}
                      className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs"
                    >
                      Cancel
                    </button>
                  </>
                ) : (
                  <>
                    <Link
                      href={`/studio/projects/${p.id}`}
                      className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-100 text-xs font-medium border border-neutral-700"
                    >
                      Open
                    </Link>
                    <button
                      type="button"
                      onClick={() => handleDuplicate(p.id)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      Duplicate
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteId(p.id)}
                      aria-label={`Delete ${p.name}`}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-rose-300 text-xs"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Delete
                    </button>
                  </>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};
