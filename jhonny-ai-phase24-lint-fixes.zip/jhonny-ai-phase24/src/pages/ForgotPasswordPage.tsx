import React from 'react';
import { Link } from '../router/Router';
import { AlertTriangle, ArrowLeft } from 'lucide-react';

export const ForgotPasswordPage: React.FC = () => {

  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl p-6 sm:p-8">
        <Link
          href="/login"
          className="inline-flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white mb-6"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to sign in</span>
        </Link>

        <h1 className="text-lg font-bold text-white tracking-tight mb-2">Reset Password</h1>
        <p className="text-xs text-neutral-400 mb-6 leading-relaxed">
          Password recovery needs an identity provider and an email service, and this build has neither.
        </p>

        <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 text-center space-y-3">
          <AlertTriangle className="w-8 h-8 text-amber-400 mx-auto" />
          <h4 role="status" className="text-xs font-semibold text-neutral-200">Password reset unavailable</h4>
          <p className="text-[11px] text-neutral-400">No password-reset request was sent. Contact the service operator for account recovery until an email-based reset flow is configured.</p>
          <Link href="/login" className="inline-block px-4 py-2 rounded-lg bg-rose-500 text-white text-xs font-semibold">Go to sign in</Link>
        </div>
      </div>
    </div>
  );
};
