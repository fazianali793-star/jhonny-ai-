import React from 'react';
import { FileText } from 'lucide-react';

export const TermsPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <div className="inline-flex items-center gap-1.5 text-xs font-mono text-neutral-400 mb-2">
          <FileText className="w-4 h-4 text-rose-400" />
          <span>Legal Agreement · Effective April 2026</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white tracking-tight">Terms of Service</h1>
        <p className="text-xs text-neutral-400 mt-1">
          Rules governing the discovery, downloading, and social republishing of video clips on JHONNY AI
        </p>
      </div>

      <div className="bg-neutral-900/40 rounded-2xl border border-neutral-800 p-6 sm:p-8 space-y-6 text-xs text-neutral-300 leading-relaxed">
        <section>
          <h2 className="text-sm font-bold text-white mb-2">1. Overview of the Platform</h2>
          <p>
            JHONNY AI is a syndication marketplace providing permission-cleared short-form video clips. Creators license video assets to JHONNY AI, which makes them available for preview and download to publishers, video editors, and social media account operators.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-bold text-white mb-2">2. Phase 1 Business Model & Access</h2>
          <p>
            During Phase 1 operations, all clip downloads are provided free of charge, with zero watermarks. Platform operations and creator revenue share are financed exclusively through on-site sponsor advertisements. JHONNY AI reserves the right to introduce optional premium features or memberships in subsequent phases.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-bold text-white mb-2">3. Social Platform Syndication License</h2>
          <p>
            When you download a clip from JHONNY AI, you are granted a non-exclusive, non-transferable license to publish that clip on short-form social media platforms (including TikTok, YouTube Shorts, and Instagram Reels) subject to the following covenants:
          </p>
          <ul className="list-disc pl-5 mt-2 space-y-1 text-neutral-400">
            <li>You may not claim ownership or register digital fingerprints/Content ID for the original clip.</li>
            <li>You may not resell the raw source video package to other asset libraries or stock platforms.</li>
            <li>You agree to cease distribution if a clip is revoked due to an intellectual property dispute.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-sm font-bold text-white mb-2">4. Creator Obligations and Representations</h2>
          <p>
            Creators uploading content represent and warrant that: (i) they own the copyright or hold explicit sublicensing rights to the media; (ii) the content does not violate any third-party contracts, non-disclosure agreements, or broadcast rights; and (iii) all synchronized musical compositions and master audio recordings are fully cleared.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-bold text-white mb-2">5. Disclaimers & Limitation of Liability</h2>
          <p>
            JHONNY AI makes reasonable efforts to verify creator syndication rights. However, third-party social media platform policies and algorithms remain beyond our control. JHONNY AI provides the service on an "as is" and "as available" basis.
          </p>
        </section>
      </div>
    </div>
  );
};
