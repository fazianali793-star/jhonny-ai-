import React from 'react';
import { HeroSection } from '../components/home/HeroSection';
import { PopularCategoriesSection } from '../components/home/PopularCategoriesSection';
import { HowItWorksSection } from '../components/home/HowItWorksSection';
import { ClipCard } from '../components/common/ClipCard';
import { CreatorCard } from '../components/common/CreatorCard';
import { AdPlacement } from '../components/common/AdPlacement';
import { useApp } from '../context/AppContext';
import { BackendLibraryPanel } from '../components/common/Phase4BackendPanels';
import { isPublicClip } from '../lib/rights';
import { Link } from '../router/Router';
import { ArrowRight, Flame, Sparkles, UploadCloud } from 'lucide-react';

export const HomePage: React.FC = () => {
  const { clips, creators } = useApp();

  const publishedClips = clips.filter(c => isPublicClip(c));
  const trendingClips = publishedClips.filter(c => c.trending).slice(0, 4);
  const latestClips = [...publishedClips]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 4);

  if (!import.meta.env.DEV) {
    return <div className="w-full"><HeroSection /><PopularCategoriesSection /><section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10"><h2 className="text-xl font-bold text-white mb-2">Licensed Clip Library</h2><p className="text-sm text-neutral-400 mb-5">Live published clips from the JHONNY AI backend. Only server-approved, actively licensed content is listed.</p><BackendLibraryPanel /></section><HowItWorksSection /><section className="py-12 text-center"><h2 className="text-2xl font-bold text-white mb-3">Have Content? Become a JHONNY AI Creator.</h2><Link href="/creator" className="inline-flex rounded-xl bg-rose-500 px-5 py-3 text-sm font-semibold text-white">Open Creator Portal</Link></section></div>;
  }

  return (
    <div className="w-full">
      {/* 1. Hero Section */}
      <HeroSection />

      {/* 2. Popular Categories */}
      <PopularCategoriesSection />

      {/* 3. Trending Clips Section */}
      <section className="py-14 border-b border-neutral-900 bg-neutral-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-400 border border-rose-500/20">
                <Flame className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight">Trending Clips</h2>
                <p className="text-xs text-neutral-400">High-velocity viral downloads this week</p>
              </div>
            </div>
            <Link
              href="/clips?sort=trending"
              className="text-xs font-semibold text-rose-400 hover:text-rose-300 flex items-center gap-1 transition-colors"
            >
              <span>View all trending</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {trendingClips.map((clip, idx) => (
              <ClipCard key={`${clip.id}-${idx}`} clip={clip} />
            ))}
          </div>
        </div>
      </section>

      {/* Ad Placement: In-feed / Leaderboard */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AdPlacement type="leaderboard" />
      </div>

      {/* 4. Latest Clips Section */}
      <section className="py-14 border-b border-neutral-900 bg-neutral-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-sky-500/10 flex items-center justify-center text-sky-400 border border-sky-500/20">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight">Latest Clips</h2>
                <p className="text-xs text-neutral-400">Freshly cleared for syndicate publishing</p>
              </div>
            </div>
            <Link
              href="/clips?sort=newest"
              className="text-xs font-semibold text-rose-400 hover:text-rose-300 flex items-center gap-1 transition-colors"
            >
              <span>Explore fresh drops</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {latestClips.map((clip, idx) => (
              <ClipCard key={`${clip.id}-${idx}`} clip={clip} />
            ))}
          </div>
        </div>
      </section>

      {/* 5. Featured Creators Section */}
      <section className="py-14 border-b border-neutral-900 bg-neutral-950/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">Featured Creators</h2>
              <p className="text-xs text-neutral-400">
                Verified creators providing licensed media to the JHONNY AI platform
              </p>
            </div>
            <Link
              href="/creator"
              className="text-xs font-semibold text-rose-400 hover:text-rose-300 transition-colors"
            >
              Creator program details →
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {creators.slice(0, 3).map(creator => (
              <CreatorCard key={creator.id} creator={creator} />
            ))}
          </div>
        </div>
      </section>

      {/* 6. How It Works */}
      <HowItWorksSection />

      {/* 7. Creator CTA Banner */}
      <section className="py-16 bg-neutral-950">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="rounded-2xl border border-neutral-800 bg-gradient-to-r from-neutral-900 via-neutral-900 to-neutral-950 p-8 sm:p-12 text-center relative overflow-hidden">
            <div className="w-12 h-12 rounded-xl bg-rose-500/10 flex items-center justify-center text-rose-400 mx-auto mb-4 border border-rose-500/20">
              <UploadCloud className="w-6 h-6" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mb-3">
              Have Content? Become a JHONNY AI Creator.
            </h2>
            <p className="text-xs sm:text-sm text-neutral-300 max-w-xl mx-auto mb-6 leading-relaxed">
              Earn advertising revenue share while expanding your brand across thousands of social channels. Maintain complete rights control with granular syndication agreements.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <Link
                href="/creator"
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-semibold text-xs shadow-md transition-all active:scale-95"
              >
                Join the Creator Program
              </Link>
              <Link
                href="/copyright"
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 font-semibold text-xs transition-colors"
              >
                Read Rights & Terms
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
