/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { RouterProvider, useRouter } from './router/Router';
import { AppProvider } from './context/AppContext';
import { Navbar } from './components/common/Navbar';
import { Footer } from './components/common/Footer';
import { DownloadModal } from './components/common/DownloadModal';
import { VideoPlayerModal } from './components/common/VideoPlayerModal';
import { ToastContainer } from './components/common/ToastContainer';
import { ClipStudioModal } from './components/studio/ClipStudioModal';
import { AiProcessingPipelineModal } from './components/studio/AiProcessingPipelineModal';
import { SocialPublishModal } from './components/studio/SocialPublishModal';
import { AccessGate } from './components/auth/AccessGate';
import { requirementForPath } from './lib/auth';

// Public Pages
import { HomePage } from './pages/HomePage';
import { ClipsPage } from './pages/ClipsPage';
import { ClipDetailPage } from './pages/ClipDetailPage';
import { SearchPage } from './pages/SearchPage';

// Auth Pages
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { ForgotPasswordPage } from './pages/ForgotPasswordPage';

// User Dashboard
import { UserDashboardPage } from './pages/UserDashboardPage';

// Creator Experience Pages
import { CreatorDashboardPage } from './pages/CreatorDashboardPage';
import { CreatorContentPage } from './pages/CreatorContentPage';
import { CreatorLicensesPage } from './pages/CreatorLicensesPage';
import { CreatorEarningsPage } from './pages/CreatorEarningsPage';

// Admin Experience Pages
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { AdminClipsPage } from './pages/AdminClipsPage';
import { AdminCreatorsPage } from './pages/AdminCreatorsPage';
import { AdminRightsPage } from './pages/AdminRightsPage';
import { AdminReportsPage } from './pages/AdminReportsPage';
import { AdminLiveDataPage } from './pages/AdminLiveDataPage';
import { AdminAnalyticsPage } from './pages/AdminAnalyticsPage';

// Legal & Trust Pages
import { CopyrightPage } from './pages/CopyrightPage';
import { TermsPage } from './pages/TermsPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { ContactPage } from './pages/ContactPage';

// Studio, AI tooling and error pages
import { StudioPage } from './pages/StudioPage';
import { ProjectEditorPage } from './pages/ProjectEditorPage';
import { AdminAiPage } from './pages/AdminAiPage';
import { NotFoundPage } from './pages/NotFoundPage';

const AppContent: React.FC = () => {
  const { path } = useRouter();

  const renderPage = (): React.ReactNode => {
    // Exact or prefix matches
    if (path === '/' || path === '') return <HomePage />;
    if (path === '/clips') return <ClipsPage />;
    if (path.startsWith('/clips/')) return <ClipDetailPage />;
    if (path === '/search') return <SearchPage />;
    if (path === '/login') return <LoginPage />;
    if (path === '/register') return <RegisterPage />;
    if (path === '/forgot-password') return <ForgotPasswordPage />;
    if (path === '/dashboard') return <UserDashboardPage />;

    // Studio (signed-in users; projects are owner-scoped)
    if (path === '/studio') return <StudioPage />;
    if (path.startsWith('/studio/projects/')) return <ProjectEditorPage />;

    // Creator Pages
    if (path === '/creator') return <CreatorDashboardPage />;
    if (path === '/creator/content') return <CreatorContentPage />;
    if (path === '/creator/licenses') return <CreatorLicensesPage />;
    if (path === '/creator/earnings') return <CreatorEarningsPage />;

    // Admin Pages
    if (path === '/admin') return <AdminDashboardPage />;
    if (path === '/admin/clips') return <AdminClipsPage />;
    if (path === '/admin/creators') return <AdminCreatorsPage />;
    if (path === '/admin/rights') return <AdminRightsPage />;
    if (path === '/admin/reports') return <AdminReportsPage />;
    if (path === '/admin/users') return <AdminLiveDataPage section="users" />;
    if (path === '/admin/moderation') return <AdminLiveDataPage section="moderation" />;
    if (path === '/admin/analytics') return <AdminAnalyticsPage />;
    if (path === '/admin/ai') return <AdminAiPage />;

    // Legal & Support
    if (path === '/copyright') return <CopyrightPage />;
    if (path === '/terms') return <TermsPage />;
    if (path === '/privacy') return <PrivacyPage />;
    if (path === '/contact') return <ContactPage />;

    // Unknown routes get a real 404 page rather than the home page.
    return <NotFoundPage />;
  };

  // Protected routes are checked in the UI before rendering. The server must enforce the same rules.
  const renderCurrentPage = () => (
    <AccessGate requirement={requirementForPath(path)}>{renderPage()}</AccessGate>
  );

  return (
    <div className="flex flex-col min-h-screen bg-neutral-950 text-neutral-100 antialiased font-sans selection:bg-rose-500/20 selection:text-rose-200">
      <Navbar />
      <main className="flex-1 w-full pb-16 md:pb-0">
        {renderCurrentPage()}
      </main>
      <Footer />

      {/* Global Modals & Notifications */}
      <DownloadModal />
      <VideoPlayerModal />
      <ClipStudioModal />
      <AiProcessingPipelineModal />
      <SocialPublishModal />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <RouterProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </RouterProvider>
  );
}
