import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Clip,
  Creator,
  LicenseRecord,
  CopyrightReport,
  UserDownloadRecord,
  UserAccount,
  ToastMessage,
  ClipStatus,
  ReportStatus,
  ProcessingJob
} from '../types';
import { INITIAL_CLIPS, INITIAL_CREATORS, INITIAL_LICENSES, INITIAL_REPORTS } from '../data/mockData';
import { STORAGE_KEYS, loadCollection, loadValue, saveVersioned, clearKey, makeId, LoadResult } from '../lib/storage';
import {
  isClipRecord,
  isCreatorRecord,
  isLicenseRecord,
  isReportRecord,
  isUserAccount,
  isSavedClipId,
  isDownloadRecord,
  isProcessingJobRecord,
  isProjectRecord
} from '../lib/models';
import { canDownloadClip, canViewClipDetail } from '../lib/rights';
import { decideStatusChange, canEditClip, isAdmin } from '../lib/permissions';
import { DEMO_ADMIN_PERSONA_ENABLED, DEMO_PERSONAS_ENABLED } from '../lib/demo';
import { currentUserApi, getApiToken, clearApiToken } from '../lib/api';
import {
  createProject,
  updateProject,
  duplicateProject,
  removeOwnedProject,
  type Project,
  type ProjectInput,
  type ProjectResult
} from '../lib/projects';

interface AppContextType {
  currentUser: UserAccount | null;
  setCurrentUser: (user: UserAccount | null) => void;
  clips: Clip[];
  creators: Creator[];
  licenses: LicenseRecord[];
  reports: CopyrightReport[];
  savedClipIds: string[];
  downloadHistory: UserDownloadRecord[];
  toasts: ToastMessage[];
  processingJobs: ProcessingJob[];
  projects: Project[];

  // Quick Switcher / Auth
  switchRole: (role: 'guest' | 'user' | 'creator' | 'admin') => void;
  
  // Clip Actions
  getClipBySlug: (slug: string) => Clip | undefined;
  getClipById: (id: string) => Clip | undefined;
  addClip: (newClip: Partial<Clip>) => void;
  updateClipStatus: (clipId: string, status: ClipStatus) => void;
  updateClipCustomization: (clipId: string, updates: Partial<Clip>) => void;
  toggleFeatureClip: (clipId: string) => void;
  toggleSaveClip: (clipId: string) => void;
  isClipSaved: (clipId: string) => boolean;
  /** Returns false (and shows why) when the clip is not downloadable under current rights. */
  recordDownload: (clip: Clip) => boolean;
  /** Admin approval: moves a pending submission to Published with an Active license. */
  approveClip: (clipId: string) => void;

  // Creator Actions
  approveCreator: (creatorId: string) => void;
  disableCreator: (creatorId: string) => void;

  // Reports Actions
  submitReport: (report: Omit<CopyrightReport, 'id' | 'submittedAt' | 'status'>) => void;
  updateReportStatus: (reportId: string, status: ReportStatus, actionTaken?: string) => void;
  disableClipFromReport: (reportId: string, clipId: string) => void;

  // License Actions
  addLicense: (license: Omit<LicenseRecord, 'id'>) => void;

  // Modals & Triggers
  activeDownloadClip: Clip | null;
  openDownloadModal: (clip: Clip) => void;
  closeDownloadModal: () => void;

  activePreviewClip: Clip | null;
  openPreviewModal: (clip: Clip) => void;
  closePreviewModal: () => void;

  // OpenShorts Studio Modals & Pipelines
  activeStudioClip: Clip | null;
  openStudioModal: (clip: Clip) => void;
  closeStudioModal: () => void;

  isAiPipelineOpen: boolean;
  openAiPipelineModal: () => void;
  closeAiPipelineModal: () => void;

  activeSocialClip: Clip | null;
  openSocialModal: (clip: Clip) => void;
  closeSocialModal: () => void;

  // Job Queue Actions
  addProcessingJob: (job: ProcessingJob) => void;
  updateProcessingJob: (jobId: string, updates: Partial<ProcessingJob>) => void;
  publishJobClips: (jobId: string) => void;

  // Studio projects (owner-scoped)
  createProjectForUser: (input: ProjectInput) => ProjectResult;
  saveProjectEdits: (projectId: string, patch: Partial<ProjectInput>) => ProjectResult;
  duplicateOwnedProject: (projectId: string) => ProjectResult;
  deleteOwnedProject: (projectId: string) => { ok: true } | { ok: false; error: string };

  // Toasts
  addToast: (title: string, description?: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  removeToast: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const DEMO_USERS: Record<string, UserAccount> = {
  user: {
    id: 'usr-1',
    name: 'Jordan Miller',
    email: 'jordan@socialcreator.io',
    role: 'user',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    socialLinks: {
      tiktok: 'https://tiktok.com/@jordanclips',
      youtube: 'https://youtube.com/@jordaneditor'
    }
  },
  creator: {
    id: 'usr-creator-1',
    name: 'Marcus Vance',
    email: 'marcus@vanguardmedia.com',
    role: 'creator',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    creatorId: 'c1'
  },
  admin: {
    id: 'usr-admin-1',
    name: 'Sarah Chen (Compliance)',
    email: 'compliance@jhonny.ai',
    role: 'admin',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80'
  }
};

// No download history is invented. Records are created only by a real, rights-checked download.
const seedDownloads = (): UserDownloadRecord[] => [];

/** Ids of the fake download records that earlier builds seeded. They are removed from stored data on load. */
const LEGACY_SEED_DOWNLOAD_IDS = new Set(['dl-1', 'dl-2']);

const seedProcessingJobs = (): ProcessingJob[] => [
  {
    id: 'job-101',
    sourceTitle: 'The Vanguard Podcast Ep. 89: AI Agents and Autonomous Robotics',
    sourceUrl: 'https://youtube.com/watch?v=mock-vanguard-89',
    fileSize: '412 MB',
    status: 'completed',
    progress: 100,
    currentStepText: 'AI analysis completed. 4 viral moments extracted and captioned.',
    viralMomentsFound: 4,
    generatedClips: [],
    createdAt: '2026-04-05T14:10:00Z',
    creatorId: 'c1'
  }
];

const CUSTOMIZABLE_CLIP_FIELDS = [
  'title',
  'thumbnail',
  'duration',
  'durationFormatted',
  'subtitles',
  'hookOverlay',
  'hookText',
  'reframe'
] as const;

interface PersistedState {
  values: {
    currentUser: UserAccount | null;
    clips: Clip[];
    creators: Creator[];
    licenses: LicenseRecord[];
    reports: CopyrightReport[];
    savedClipIds: string[];
    downloads: UserDownloadRecord[];
    projects: Project[];
    processingJobs: ProcessingJob[];
  };
  /** False when stored data was unreadable or newer; writes are then skipped so it is not overwritten. */
  writable: Record<keyof PersistedState['values'], boolean>;
}

function loadPersistedState(): PersistedState {
  // No stored session means guest. Demo sessions must be chosen explicitly.
  const storedUser = loadValue<UserAccount>(STORAGE_KEYS.currentUser, isUserAccount, () => null);
  // The admin persona is a development-only demo. Outside dev builds a stored admin session is ignored.
  // Persisted browser roles are demo-only. In production, only a server-validated
  // bearer token may establish identity; the effect below revalidates it via /api/auth/me.
  const user = !DEMO_PERSONAS_ENABLED
    ? { ...storedUser, value: null }
    : storedUser.value?.role === 'admin' && !DEMO_ADMIN_PERSONA_ENABLED
      ? { ...storedUser, value: null }
      : storedUser;
  const clips = loadCollection<Clip>(STORAGE_KEYS.clips, isClipRecord, () => INITIAL_CLIPS, { idOf: c => c.id, repairPrefix: 'clip' });
  const creators = loadCollection<Creator>(STORAGE_KEYS.creators, isCreatorRecord, () => INITIAL_CREATORS, { idOf: c => c.id, repairPrefix: 'creator' });
  const licenses = loadCollection<LicenseRecord>(STORAGE_KEYS.licenses, isLicenseRecord, () => INITIAL_LICENSES, { idOf: l => l.id, repairPrefix: 'lic' });
  const reports = loadCollection<CopyrightReport>(STORAGE_KEYS.reports, isReportRecord, () => INITIAL_REPORTS, { idOf: r => r.id, repairPrefix: 'rep' });
  const saved = loadCollection<string>(STORAGE_KEYS.savedClips, isSavedClipId, () => ['clip-1', 'clip-2']);
  const downloads = loadCollection<UserDownloadRecord>(STORAGE_KEYS.downloads, isDownloadRecord, seedDownloads, { idOf: d => d.id, repairPrefix: 'dl' });
  const projects = loadCollection<Project>(STORAGE_KEYS.projects, isProjectRecord, () => [], { idOf: p => p.id, repairPrefix: 'proj' });
  const jobs = loadCollection<ProcessingJob>(STORAGE_KEYS.processingJobs, isProcessingJobRecord, seedProcessingJobs, { idOf: j => j.id, repairPrefix: 'job' });

  const parts: Record<keyof PersistedState['values'], LoadResult<unknown>> = {
    currentUser: user as LoadResult<unknown>,
    clips: clips as LoadResult<unknown>,
    creators: creators as LoadResult<unknown>,
    licenses: licenses as LoadResult<unknown>,
    reports: reports as LoadResult<unknown>,
    savedClipIds: saved as LoadResult<unknown>,
    downloads: downloads as LoadResult<unknown>,
    projects: projects as LoadResult<unknown>,
    processingJobs: jobs as LoadResult<unknown>
  };
  for (const [name, r] of Object.entries(parts)) {
    if (r.status === 'corrupt' || r.status === 'unsupported' || r.status === 'unavailable') {
      console.warn(`[storage] "${name}" is ${r.status}; using defaults (dropped ${r.droppedCount} invalid entries).`);
    }
  }

  return {
    values: {
      currentUser: user.value,
      clips: clips.value,
      creators: creators.value,
      licenses: licenses.value,
      reports: reports.value,
      savedClipIds: Array.from(new Set(saved.value)),
      downloads: downloads.value.filter(d => !LEGACY_SEED_DOWNLOAD_IDS.has(d.id)),
      projects: projects.value,
      processingJobs: jobs.value
    },
    writable: {
      currentUser: user.writable,
      clips: clips.writable,
      creators: creators.writable,
      licenses: licenses.writable,
      reports: reports.writable,
      savedClipIds: saved.writable,
      downloads: downloads.writable,
      projects: projects.writable,
      processingJobs: jobs.writable
    }
  };
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Persisted state is loaded once through the validated storage layer. Invalid,
  // unavailable or newer-version data falls back to safe defaults without crashing.
  const [initial] = useState<PersistedState>(() => loadPersistedState());
  const { values, writable } = initial;

  const [currentUser, setCurrentUser] = useState<UserAccount | null>(values.currentUser);
  const [clips, setClips] = useState<Clip[]>(values.clips);
  const [creators, setCreators] = useState<Creator[]>(values.creators);
  const [licenses, setLicenses] = useState<LicenseRecord[]>(values.licenses);
  const [reports, setReports] = useState<CopyrightReport[]>(values.reports);
  const [savedClipIds, setSavedClipIds] = useState<string[]>(values.savedClipIds);
  const [downloadHistory, setDownloadHistory] = useState<UserDownloadRecord[]>(values.downloads);
  const [projects, setProjects] = useState<Project[]>(values.projects);

  // Restore the server identity from the session token; localStorage roles are never authoritative.
  useEffect(() => {
    let active = true;
    const expire = () => { clearApiToken(); setCurrentUser(null); };
    window.addEventListener('jhonny:auth-expired', expire);
    if (getApiToken()) {
      currentUserApi().then(user => { if (active) setCurrentUser({ id: user.id, name: user.name, email: user.email, role: user.role, avatar: '' }); })
        .catch(() => { if (active) { clearApiToken(); setCurrentUser(null); } });
    }
    return () => { active = false; window.removeEventListener('jhonny:auth-expired', expire); };
  }, []);
  const [processingJobs, setProcessingJobs] = useState<ProcessingJob[]>(values.processingJobs);

  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [activeDownloadClip, setActiveDownloadClip] = useState<Clip | null>(null);
  const [activePreviewClip, setActivePreviewClip] = useState<Clip | null>(null);

  // OpenShorts Studio Modals & Jobs state
  const [activeStudioClip, setActiveStudioClip] = useState<Clip | null>(null);
  const [isAiPipelineOpen, setIsAiPipelineOpen] = useState<boolean>(false);
  const [activeSocialClip, setActiveSocialClip] = useState<Clip | null>(null);

  // Persist each collection through the versioned storage layer.
  useEffect(() => {
    if (!writable.currentUser) return;
    if (currentUser) saveVersioned(STORAGE_KEYS.currentUser, currentUser);
    else clearKey(STORAGE_KEYS.currentUser);
  }, [currentUser, writable.currentUser]);

  useEffect(() => { if (writable.clips) saveVersioned(STORAGE_KEYS.clips, clips); }, [clips, writable.clips]);
  useEffect(() => { if (writable.creators) saveVersioned(STORAGE_KEYS.creators, creators); }, [creators, writable.creators]);
  useEffect(() => { if (writable.licenses) saveVersioned(STORAGE_KEYS.licenses, licenses); }, [licenses, writable.licenses]);
  useEffect(() => { if (writable.reports) saveVersioned(STORAGE_KEYS.reports, reports); }, [reports, writable.reports]);
  useEffect(() => { if (writable.savedClipIds) saveVersioned(STORAGE_KEYS.savedClips, savedClipIds); }, [savedClipIds, writable.savedClipIds]);
  useEffect(() => { if (writable.downloads) saveVersioned(STORAGE_KEYS.downloads, downloadHistory); }, [downloadHistory, writable.downloads]);
  useEffect(() => { if (writable.projects) saveVersioned(STORAGE_KEYS.projects, projects); }, [projects, writable.projects]);
  useEffect(() => { if (writable.processingJobs) saveVersioned(STORAGE_KEYS.processingJobs, processingJobs); }, [processingJobs, writable.processingJobs]);

  const addToast = (title: string, description?: string, type: 'success' | 'info' | 'warning' | 'error' = 'info') => {
    const id = 'toast-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
    setToasts(prev => [...prev, { id, title, description, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const switchRole = (role: 'guest' | 'user' | 'creator' | 'admin') => {
    if (role !== 'guest' && !DEMO_PERSONAS_ENABLED) {
      addToast('Demo session unavailable', 'Use server-backed sign-in. Demo identities are disabled outside development builds.', 'warning');
      return;
    }
    if (role === 'guest') {
      setCurrentUser(null);
      addToast('Switched to Guest', 'Browsing in unauthenticated public visitor state.', 'info');
    } else {
      if (role === 'admin' && !DEMO_ADMIN_PERSONA_ENABLED) {
        addToast('Not Available', 'The administrator demo session is only offered in development builds.', 'warning');
        return;
      }
      setCurrentUser(DEMO_USERS[role]);
      addToast(`Switched Role: ${role.toUpperCase()}`, `Active session as ${DEMO_USERS[role].name}`, 'success');
    }
  };

  const getClipBySlug = (slug: string) => clips.find(c => c.slug === slug);
  const getClipById = (id: string) => clips.find(c => c.id === id);

  /**
   * Adds a submitted clip. Submissions can never publish themselves: status is
   * forced to Pending and the license is forced to Pending Review until an
   * administrator approves it (see approveClip).
   */
  const addClip = (newClipData: Partial<Clip>) => {
    if (!currentUser || (currentUser.role !== 'creator' && currentUser.role !== 'admin')) {
      addToast('Submission Not Allowed', 'Only creator or administrator accounts can submit clips.', 'warning');
      return;
    }
    const randomSuffix = Math.random().toString(36).substring(2, 8);
    const generatedId = `clip-${Date.now()}-${randomSuffix}`;
    const initialId = (newClipData.id && typeof newClipData.id === 'string' && newClipData.id.trim().length > 0)
      ? newClipData.id.trim()
      : generatedId;

    const slug = (newClipData.slug || (newClipData.title || 'new-clip')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '') + '-' + initialId.slice(-6));

    const providedLicense = newClipData.licenseInfo;
    const fullClip: Clip = {
      id: initialId,
      slug,
      title: newClipData.title || 'Untitled Clip',
      description: newClipData.description || 'Permission-cleared creator clip.',
      thumbnail: newClipData.thumbnail || INITIAL_CLIPS[0].thumbnail,
      // A creator can only submit under their own creator id.
      creatorId:
        currentUser.role === 'creator' && currentUser.creatorId
          ? currentUser.creatorId
          : newClipData.creatorId || currentUser?.creatorId || 'c1',
      creator: newClipData.creator || {
        id: currentUser?.creatorId || 'c1',
        name: currentUser?.name || 'Marcus Vance',
        handle: '@' + (currentUser?.name?.toLowerCase().replace(/\s+/g, '') || 'marcusvance'),
        avatar: currentUser?.avatar || INITIAL_CREATORS[0].avatar,
        verified: true
      },
      category: newClipData.category || 'Gaming',
      duration: newClipData.duration || 30,
      durationFormatted: newClipData.durationFormatted || '0:30',
      resolution: newClipData.resolution || '1080x1920 (9:16)',
      fps: newClipData.fps || 60,
      downloads: newClipData.downloads ?? 0,
      views: newClipData.views ?? 0,
      likes: newClipData.likes ?? 0,
      tags: newClipData.tags || ['clip', 'social'],
      status: 'Pending',
      featured: newClipData.featured ?? false,
      trending: newClipData.trending ?? false,
      viralScore: newClipData.viralScore,
      reasoning: newClipData.reasoning,
      hookText: newClipData.hookText,
      hookOverlay: newClipData.hookOverlay,
      subtitles: newClipData.subtitles,
      reframe: newClipData.reframe,
      sourceStartSeconds: newClipData.sourceStartSeconds,
      sourceEndSeconds: newClipData.sourceEndSeconds,
      createdAt: newClipData.createdAt || new Date().toISOString(),
      licenseInfo: {
        licenseId: providedLicense?.licenseId || 'LIC-' + Date.now() + '-' + randomSuffix,
        type: providedLicense?.type || 'Non-Exclusive',
        status: 'Pending Review',
        sourceUrl: providedLicense?.sourceUrl || 'https://youtube.com',
        allowedPlatforms: providedLicense?.allowedPlatforms || ['TikTok', 'Instagram Reels', 'YouTube Shorts', 'X'],
        attributionRequired: providedLicense?.attributionRequired ?? false,
        expiresAt: providedLicense?.expiresAt || new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString()
      }
    };

    setClips(prev => {
      let finalId = fullClip.id;
      if (prev.some(c => c.id === finalId)) {
        finalId = `${fullClip.id}-${Math.random().toString(36).substring(2, 7)}`;
      }
      return [{ ...fullClip, id: finalId }, ...prev];
    });

    setLicenses(prev => [
      {
        id: fullClip.licenseInfo.licenseId,
        clipId: fullClip.id,
        clipTitle: fullClip.title,
        creatorId: fullClip.creatorId,
        creatorName: fullClip.creator.name,
        sourceUrl: fullClip.licenseInfo.sourceUrl,
        licenseType: fullClip.licenseInfo.type,
        status: 'Pending Review',
        startDate: fullClip.createdAt.split('T')[0],
        expiryDate: fullClip.licenseInfo.expiresAt.split('T')[0],
        allowedPlatforms: fullClip.licenseInfo.allowedPlatforms,
        notes: 'Submitted for administrator license review.'
      },
      ...prev
    ]);

    addToast('Clip Submitted', 'It is not public until an administrator approves its license.', 'success');
  };

  const updateClipStatus = (clipId: string, status: ClipStatus) => {
    const clip = clips.find(c => c.id === clipId);
    if (!clip) return;
    const creator = creators.find(cr => cr.id === clip.creatorId);
    const decision = decideStatusChange(clip, status, currentUser, { creatorActive: creator ? creator.status === 'Active' : undefined });
    if (!decision.allowed) {
      addToast('Change Not Allowed', decision.message, 'warning');
      return;
    }
    setClips(prev =>
      prev.map(c => (c.id === clipId ? { ...c, status } : c))
    );
    addToast('Clip Status Updated', `Clip status changed to "${status}".`, 'info');
  };

  const approveClip = (clipId: string) => {
    if (!isAdmin(currentUser)) {
      addToast('Change Not Allowed', 'Only an administrator can approve clips.', 'warning');
      return;
    }
    const clip = clips.find(c => c.id === clipId);
    if (!clip) return;
    const expires = Date.parse(clip.licenseInfo.expiresAt);
    if (Number.isNaN(expires) || expires <= Date.now()) {
      addToast('Approval Not Possible', 'This clip\'s license has expired or has no valid expiry date.', 'warning');
      return;
    }
    if (clip.status !== 'Pending') {
      addToast('Approval Not Applicable', `Only pending submissions can be approved (current status: ${clip.status}).`, 'warning');
      return;
    }
    setClips(prev =>
      prev.map(c =>
        c.id === clipId
          ? {
              ...c,
              status: 'Published',
              licenseInfo: {
                ...c.licenseInfo,
                status: c.licenseInfo.status === 'Pending Review' ? 'Active' : c.licenseInfo.status
              }
            }
          : c
      )
    );
    setLicenses(prev =>
      prev.map(l => (l.clipId === clipId && l.status === 'Pending Review' ? { ...l, status: 'Active' } : l))
    );
    addToast('Clip Approved', `"${clip.title}" is now public.`, 'success');
  };

  const toggleFeatureClip = (clipId: string) => {
    if (!isAdmin(currentUser)) {
      addToast('Change Not Allowed', 'Only an administrator can change featured clips.', 'warning');
      return;
    }
    setClips(prev =>
      prev.map(c => (c.id === clipId ? { ...c, featured: !c.featured } : c))
    );
    addToast('Featured Status Toggled', 'Clip visibility updated.', 'info');
  };

  const toggleSaveClip = (clipId: string) => {
    const isSaved = savedClipIds.includes(clipId);
    if (isSaved) {
      setSavedClipIds(prev => prev.filter(id => id !== clipId));
      addToast('Removed from Saved', 'Clip was removed from your saved list.', 'info');
    } else {
      setSavedClipIds(prev => [clipId, ...prev]);
      addToast('Clip Saved', 'Added to your favorites dashboard.', 'success');
    }
  };

  const isClipSaved = (clipId: string) => savedClipIds.includes(clipId);

  /**
   * Records a completed download. Enforces rights here, not only in the UI.
   * Returns false when the clip may not be downloaded.
   */
  const recordDownload = (clip: Clip): boolean => {
    const current = clips.find(c => c.id === clip.id) ?? clip;
    const decision = canDownloadClip(current);
    if (!decision.allowed) {
      addToast('Download Not Allowed', decision.message, 'warning');
      return false;
    }

    setClips(prev =>
      prev.map(c => (c.id === clip.id ? { ...c, downloads: c.downloads + 1 } : c))
    );

    const newRecord: UserDownloadRecord = {
      id: makeId('dl'),
      clipId: clip.id,
      clipTitle: clip.title,
      thumbnail: clip.thumbnail,
      category: clip.category,
      downloadedAt: new Date().toISOString(),
      durationFormatted: clip.durationFormatted,
      fileSize: 'Reported by media service'
    };

    setDownloadHistory(prev => [newRecord, ...prev.filter(d => d.clipId !== clip.id)]);
    return true;
  };

  const approveCreator = (creatorId: string) => {
    if (!isAdmin(currentUser)) {
      addToast('Change Not Allowed', 'Only an administrator can approve creators.', 'warning');
      return;
    }
    setCreators(prev =>
      prev.map(c => (c.id === creatorId ? { ...c, status: 'Active' } : c))
    );
    addToast('Creator Approved', 'Creator privileges and syndication grant enabled.', 'success');
  };

  const disableCreator = (creatorId: string) => {
    if (!isAdmin(currentUser)) {
      addToast('Change Not Allowed', 'Only an administrator can suspend creators.', 'warning');
      return;
    }
    setCreators(prev =>
      prev.map(c => (c.id === creatorId ? { ...c, status: 'Suspended' } : c))
    );
    // Also disable their clips
    setClips(prev =>
      prev.map(c => (c.creatorId === creatorId ? { ...c, status: 'Disabled' } : c))
    );
    addToast('Creator Suspended', 'Creator and their published clips were disabled.', 'warning');
  };

  const submitReport = (reportData: Omit<CopyrightReport, 'id' | 'submittedAt' | 'status'>) => {
    const newReport: CopyrightReport = {
      ...reportData,
      id: 'REP-' + (1050 + reports.length),
      status: 'Open',
      submittedAt: new Date().toISOString()
    };
    setReports(prev => [newReport, ...prev]);
    addToast('Report Submitted', 'Our legal compliance team has received your inquiry.', 'success');
  };

  const updateReportStatus = (reportId: string, status: ReportStatus, actionTaken?: string) => {
    if (!isAdmin(currentUser)) {
      addToast('Change Not Allowed', 'Only an administrator can update reports.', 'warning');
      return;
    }
    setReports(prev =>
      prev.map(r =>
        r.id === reportId
          ? {
              ...r,
              status,
              resolvedAt: status === 'Resolved' ? new Date().toISOString() : r.resolvedAt,
              actionTaken: actionTaken || r.actionTaken
            }
          : r
      )
    );
    addToast('Report Status Updated', `Case marked as ${status}.`, 'info');
  };

  const disableClipFromReport = (reportId: string, clipId: string) => {
    if (!isAdmin(currentUser)) {
      addToast('Change Not Allowed', 'Only an administrator can take down clips.', 'warning');
      return;
    }
    updateClipStatus(clipId, 'Takedown');
    updateReportStatus(reportId, 'Resolved', 'Clip placed into emergency takedown status pending rights dispute.');
    addToast('Takedown Executed', 'Clip disabled immediately from public directory.', 'warning');
  };

  const addLicense = (licenseData: Omit<LicenseRecord, 'id'>) => {
    if (!isAdmin(currentUser)) {
      addToast('Change Not Allowed', 'Only an administrator can register licenses.', 'warning');
      return;
    }
    const newLic: LicenseRecord = {
      ...licenseData,
      id: 'LIC-' + Date.now()
    };
    setLicenses(prev => [newLic, ...prev]);
    addToast('License Registered', 'New syndication agreement logged in registry.', 'success');
  };

  const openDownloadModal = (clip: Clip) => {
    setActiveDownloadClip(clip);
  };

  const closeDownloadModal = () => {
    setActiveDownloadClip(null);
  };

  const openPreviewModal = (clip: Clip) => {
    setActivePreviewClip(clip);
  };

  const closePreviewModal = () => {
    setActivePreviewClip(null);
  };

  // OpenShorts Studio Modals & Pipelines
  const openStudioModal = (clip: Clip) => {
    setActiveStudioClip(clip);
  };

  const closeStudioModal = () => {
    setActiveStudioClip(null);
  };

  const openAiPipelineModal = () => {
    setIsAiPipelineOpen(true);
  };

  const closeAiPipelineModal = () => {
    setIsAiPipelineOpen(false);
  };

  const openSocialModal = (clip: Clip) => {
    setActiveSocialClip(clip);
  };

  const closeSocialModal = () => {
    setActiveSocialClip(null);
  };

  const updateClipCustomization = (clipId: string, updates: Partial<Clip>) => {
    const target = clips.find(c => c.id === clipId);
    if (!target || !canEditClip(target, currentUser)) {
      addToast('Changes Not Saved', 'Only the clip owner or an administrator can save changes to a clip.', 'warning');
      return;
    }
    // Only presentation fields may change here. Status, license, ownership and media URL are never editable this way.
    const safe: Partial<Clip> = {};
    for (const key of CUSTOMIZABLE_CLIP_FIELDS) {
      if (key in updates) (safe as Record<string, unknown>)[key] = (updates as Record<string, unknown>)[key];
    }
    setClips(prev =>
      prev.map(c => (c.id === clipId ? { ...c, ...safe } : c))
    );
    if (activeStudioClip && activeStudioClip.id === clipId) {
      setActiveStudioClip(prev => (prev ? { ...prev, ...safe } : null));
    }
    addToast('Clip Customizations Saved', 'Captions, hook overlay, and 9:16 reframe updated.', 'success');
  };

  const addProcessingJob = (job: ProcessingJob) => {
    setProcessingJobs(prev => [job, ...prev]);
    addToast('Job Queued', `AI processing started for "${job.sourceTitle}".`, 'info');
  };

  const updateProcessingJob = (jobId: string, updates: Partial<ProcessingJob>) => {
    setProcessingJobs(prev =>
      prev.map(j => (j.id === jobId ? { ...j, ...updates } : j))
    );
  };

  const publishJobClips = (jobId: string) => {
    if (!currentUser || (currentUser.role !== 'creator' && currentUser.role !== 'admin')) {
      addToast('Submission Not Allowed', 'Only creator or administrator accounts can submit clips.', 'warning');
      return;
    }
    const job = processingJobs.find(j => j.id === jobId);
    if (!job || !job.generatedClips || job.generatedClips.length === 0) {
      addToast('No Generated Clips', 'This job has no clips ready to publish.', 'warning');
      return;
    }

    setClips(prev => {
      const existingIds = new Set(prev.map(c => c.id));
      const deduplicatedNewClips = job.generatedClips.map((c, i) => {
        let uniqueId = c.id;
        if (!uniqueId || existingIds.has(uniqueId)) {
          uniqueId = `${c.id || 'ai-clip'}-${Date.now()}-${i}-${Math.random().toString(36).substring(2, 6)}`;
        }
        existingIds.add(uniqueId);
        return {
          ...c,
          id: uniqueId,
          status: 'Pending' as const,
          licenseInfo: { ...c.licenseInfo, status: 'Pending Review' as const }
        };
      });

      // Also register new licenses
      const newLicenses: LicenseRecord[] = deduplicatedNewClips.map((c, i) => ({
        id: c.licenseInfo?.licenseId || `LIC-${Date.now()}-${i}-${Math.random().toString(36).substring(2, 6)}`,
        clipId: c.id,
        clipTitle: c.title,
        creatorId: c.creatorId,
        creatorName: c.creator.name,
        sourceUrl: c.licenseInfo?.sourceUrl || 'https://youtube.com',
        licenseType: c.licenseInfo?.type || 'Non-Exclusive',
        status: 'Pending Review' as const,
        startDate: new Date().toISOString().split('T')[0],
        expiryDate: c.licenseInfo?.expiresAt ? c.licenseInfo.expiresAt.split('T')[0] : new Date(Date.now() + 365 * 86400000).toISOString().split('T')[0],
        allowedPlatforms: c.licenseInfo?.allowedPlatforms || ['TikTok', 'Instagram Reels', 'YouTube Shorts', 'X'],
        notes: `Published from AI Ingestion Engine (${job.sourceTitle}).`
      }));

      setLicenses(licPrev => [...newLicenses, ...licPrev]);
      return [...deduplicatedNewClips, ...prev];
    });

    updateProcessingJob(jobId, { status: 'completed', progress: 100, currentStepText: 'Clips submitted for administrator license review.' });
    addToast('Clips Submitted for Review', `${job.generatedClips.length} clips will go live after an administrator approves their licenses.`, 'success');
  };

  // ----- Studio projects: every operation is scoped to the signed-in owner -----
  const resolveSourceClip = (clipId: string | null): { ok: true; duration?: number } | { ok: false; error: string } => {
    if (!clipId) return { ok: true, duration: undefined };
    const clip = clips.find(c => c.id === clipId);
    if (!clip || !canViewClipDetail(clip, currentUser?.role)) {
      return { ok: false, error: 'The selected source clip is not available.' };
    }
    return { ok: true, duration: clip.duration };
  };

  const createProjectForUser = (input: ProjectInput): ProjectResult => {
    if (!currentUser) return { ok: false, error: 'Sign in to create projects.' };
    const source = resolveSourceClip(input.sourceClipId);
    if (!source.ok) return source;
    const result = createProject(currentUser.id, input, { id: makeId('proj'), sourceDurationSeconds: source.duration });
    if (result.ok) {
      setProjects(prev => [result.project, ...prev]);
      addToast('Project Created', `"${result.project.name}" was added to your studio.`, 'success');
    }
    return result;
  };

  const saveProjectEdits = (projectId: string, patch: Partial<ProjectInput>): ProjectResult => {
    const current = projects.find(p => p.id === projectId);
    if (!current) return { ok: false, error: 'Project not found.' };
    const source = resolveSourceClip(patch.sourceClipId !== undefined ? patch.sourceClipId : current.sourceClipId);
    if (!source.ok) return source;
    const result = updateProject(current, patch, currentUser?.id, { sourceDurationSeconds: source.duration });
    if (result.ok) {
      setProjects(prev => prev.map(p => (p.id === projectId ? result.project : p)));
      addToast('Project Saved', `"${result.project.name}" was saved.`, 'success');
    }
    return result;
  };

  const duplicateOwnedProject = (projectId: string): ProjectResult => {
    const current = projects.find(p => p.id === projectId);
    if (!current) return { ok: false, error: 'Project not found.' };
    const result = duplicateProject(current, currentUser?.id, { id: makeId('proj') });
    if (result.ok) {
      setProjects(prev => [result.project, ...prev]);
      addToast('Project Duplicated', `Created "${result.project.name}".`, 'success');
    }
    return result;
  };

  const deleteOwnedProject = (projectId: string) => {
    const result = removeOwnedProject(projects, projectId, currentUser?.id);
    if (!result.ok) return result;
    setProjects(result.projects);
    addToast('Project Deleted', 'The project was removed from your studio.', 'info');
    return { ok: true as const };
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        clips,
        creators,
        licenses,
        reports,
        savedClipIds,
        downloadHistory,
        toasts,
        processingJobs,
        projects,
        switchRole,
        getClipBySlug,
        getClipById,
        addClip,
        updateClipStatus,
        updateClipCustomization,
        toggleFeatureClip,
        toggleSaveClip,
        isClipSaved,
        recordDownload,
        approveClip,
        createProjectForUser,
        saveProjectEdits,
        duplicateOwnedProject,
        deleteOwnedProject,
        approveCreator,
        disableCreator,
        submitReport,
        updateReportStatus,
        disableClipFromReport,
        addLicense,
        activeDownloadClip,
        openDownloadModal,
        closeDownloadModal,
        activePreviewClip,
        openPreviewModal,
        closePreviewModal,
        activeStudioClip,
        openStudioModal,
        closeStudioModal,
        isAiPipelineOpen,
        openAiPipelineModal,
        closeAiPipelineModal,
        activeSocialClip,
        openSocialModal,
        closeSocialModal,
        addProcessingJob,
        updateProcessingJob,
        publishJobClips,
        addToast,
        removeToast
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
