/**
 * Runtime validators for persisted records. Stored data is untrusted input:
 * anything that does not pass these checks is dropped instead of crashing the UI.
 */
import type {
  Clip,
  ClipStatus,
  Creator,
  CopyrightReport,
  LicenseRecord,
  UserAccount,
  UserDownloadRecord,
  ProcessingJob
} from '../types';
import type { Project } from './projects';

type Obj = Record<string, unknown>;

const isObj = (x: unknown): x is Obj => typeof x === 'object' && x !== null && !Array.isArray(x);
const str = (x: unknown): x is string => typeof x === 'string';
const num = (x: unknown): x is number => typeof x === 'number' && Number.isFinite(x);
const oneOf = <T extends string>(list: readonly T[]) => (x: unknown): x is T =>
  typeof x === 'string' && (list as readonly string[]).includes(x);

export const CLIP_STATUSES: readonly ClipStatus[] = ['Published', 'Pending', 'Processing', 'Disabled', 'Takedown'];
export const LICENSE_STATUSES = ['Active', 'Expiring', 'Expired', 'Revoked', 'Pending Review'] as const;
export const ROLES = ['user', 'creator', 'admin'] as const;

export const isClipRecord = (x: unknown): x is Clip =>
  isObj(x) &&
  str(x.id) &&
  str(x.slug) &&
  str(x.title) &&
  str(x.thumbnail) &&
  str(x.creatorId) &&
  isObj(x.creator) &&
  num(x.duration) &&
  oneOf(CLIP_STATUSES)(x.status) &&
  isObj(x.licenseInfo) &&
  str(x.licenseInfo.licenseId) &&
  oneOf(LICENSE_STATUSES)(x.licenseInfo.status) &&
  str(x.licenseInfo.expiresAt) &&
  (x.mediaUrl === undefined || str(x.mediaUrl));

export const isLicenseRecord = (x: unknown): x is LicenseRecord =>
  isObj(x) && str(x.id) && str(x.clipId) && str(x.clipTitle) && oneOf(LICENSE_STATUSES)(x.status) && str(x.expiryDate);

export const isCreatorRecord = (x: unknown): x is Creator =>
  isObj(x) && str(x.id) && str(x.name) && str(x.handle);

export const isReportRecord = (x: unknown): x is CopyrightReport =>
  isObj(x) && str(x.id) && str(x.clipId) && str(x.status) && str(x.submittedAt);

export const isDownloadRecord = (x: unknown): x is UserDownloadRecord =>
  isObj(x) && str(x.id) && str(x.clipId) && str(x.clipTitle) && str(x.downloadedAt);

export const isProcessingJobRecord = (x: unknown): x is ProcessingJob =>
  isObj(x) && str(x.id) && str(x.sourceTitle) && str(x.status) && num(x.progress);

export const isUserAccount = (x: unknown): x is UserAccount =>
  isObj(x) && str(x.id) && str(x.name) && str(x.email) && oneOf(ROLES)(x.role);

export const isSavedClipId = (x: unknown): x is string => str(x) && x.length > 0;

export const isProjectRecord = (x: unknown): x is Project =>
  isObj(x) &&
  str(x.id) &&
  str(x.ownerId) &&
  str(x.name) &&
  num(x.trimStart) &&
  num(x.trimEnd) &&
  str(x.hookText) &&
  (x.sourceClipId === null || str(x.sourceClipId)) &&
  (x.status === 'draft' || x.status === 'saved') &&
  str(x.createdAt) &&
  str(x.updatedAt);
