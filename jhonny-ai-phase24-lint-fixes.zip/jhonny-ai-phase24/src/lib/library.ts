/**
 * Pure query helpers for clip libraries: search, filter, sort and pagination.
 * Kept free of React and storage so they can be unit tested directly.
 */
import type { Clip, ClipStatus } from '../types';

export const LIBRARY_PAGE_SIZE = 12;

export const LIBRARY_SORTS = ['trending', 'newest', 'downloads', 'title'] as const;
export type LibrarySort = (typeof LIBRARY_SORTS)[number];

export const DURATION_FILTERS = ['all', 'short', 'medium', 'long'] as const;
export type DurationFilter = (typeof DURATION_FILTERS)[number];

export const isLibrarySort = (x: unknown): x is LibrarySort =>
  typeof x === 'string' && (LIBRARY_SORTS as readonly string[]).includes(x);

export const isDurationFilter = (x: unknown): x is DurationFilter =>
  typeof x === 'string' && (DURATION_FILTERS as readonly string[]).includes(x);

export interface PageResult<T> {
  items: T[];
  page: number;
  pageSize: number;
  totalItems: number;
  totalPages: number;
}

/** Clamps the page into range so an out-of-date URL never shows an empty page. */
export function paginate<T>(items: readonly T[], requestedPage: number, pageSize: number = LIBRARY_PAGE_SIZE): PageResult<T> {
  const size = Number.isInteger(pageSize) && pageSize > 0 ? pageSize : LIBRARY_PAGE_SIZE;
  const totalItems = items.length;
  const totalPages = Math.max(1, Math.ceil(totalItems / size));
  const wanted = Number.isFinite(requestedPage) ? Math.floor(requestedPage) : 1;
  const page = Math.min(Math.max(wanted, 1), totalPages);
  const start = (page - 1) * size;
  return { items: items.slice(start, start + size), page, pageSize: size, totalItems, totalPages };
}

export function matchesSearch(clip: Clip, term: string): boolean {
  const q = term.trim().toLowerCase();
  if (!q) return true;
  return (
    clip.title.toLowerCase().includes(q) ||
    clip.creator.name.toLowerCase().includes(q) ||
    clip.category.toLowerCase().includes(q) ||
    (clip.tags || []).some(t => t.toLowerCase().includes(q))
  );
}

export function matchesDuration(clip: Clip, filter: DurationFilter): boolean {
  switch (filter) {
    case 'short':
      return clip.duration < 30;
    case 'medium':
      return clip.duration >= 30 && clip.duration <= 60;
    case 'long':
      return clip.duration > 60;
    default:
      return true;
  }
}

function timeOf(value: string): number {
  const t = Date.parse(value);
  return Number.isNaN(t) ? 0 : t;
}

/** Returns a new sorted array. Ties are broken by id so pagination is stable. */
export function sortClips(clips: readonly Clip[], sort: LibrarySort): Clip[] {
  const copy = [...clips];
  const tieBreak = (a: Clip, b: Clip) => a.id.localeCompare(b.id);
  copy.sort((a, b) => {
    let diff = 0;
    switch (sort) {
      case 'trending':
        diff = b.views + b.downloads * 2 - (a.views + a.downloads * 2);
        break;
      case 'newest':
        diff = timeOf(b.createdAt) - timeOf(a.createdAt);
        break;
      case 'downloads':
        diff = b.downloads - a.downloads;
        break;
      case 'title':
        return a.title.localeCompare(b.title) || tieBreak(a, b);
    }
    return diff !== 0 ? diff : tieBreak(a, b);
  });
  return copy;
}

export interface ClipQuery {
  search?: string;
  category?: string;        // 'All' or a category name
  creatorId?: string;       // 'all' or a creator id
  duration?: DurationFilter;
  status?: ClipStatus | 'All';
  sort?: LibrarySort;
}

/** Applies every filter in the query, then sorts. The caller decides visibility rules. */
export function queryClips(clips: readonly Clip[], query: ClipQuery): Clip[] {
  const filtered = clips.filter(clip => {
    if (query.status && query.status !== 'All' && clip.status !== query.status) return false;
    if (query.category && query.category !== 'All' && clip.category !== query.category) return false;
    if (query.creatorId && query.creatorId !== 'all' && clip.creatorId !== query.creatorId) return false;
    if (query.duration && !matchesDuration(clip, query.duration)) return false;
    if (query.search && !matchesSearch(clip, query.search)) return false;
    return true;
  });
  return sortClips(filtered, query.sort ?? 'trending');
}
