const API_BASE = (import.meta.env.VITE_API_BASE_URL as string | undefined)?.replace(/\/$/, '') || 'http://127.0.0.1:8000';
const TOKEN_KEY = 'jhonny_api_token';
export const getApiToken = () => sessionStorage.getItem(TOKEN_KEY);
export const setApiToken = (token: string) => sessionStorage.setItem(TOKEN_KEY, token);
export const clearApiToken = () => sessionStorage.removeItem(TOKEN_KEY);
export class ApiError extends Error { constructor(message: string, public status: number) { super(message); this.name = 'ApiError'; } }
async function responseErrorMessage(response: Response, fallback: string): Promise<string> {
  // Never relay server-side 5xx details to the browser; they may contain internal paths or diagnostics.
  if (response.status >= 500) return 'The server could not complete this request. Please try again later.';
  try {
    const data: unknown = await response.json();
    if (isRecord(data) && typeof data.detail === 'string' && data.detail.trim()) return data.detail;
  } catch { /* Empty and non-JSON error responses use the stable fallback. */ }
  return fallback;
}
export async function apiRequest<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  const token = getApiToken();
  if (token) headers.set('Authorization', `Bearer ${token}`);
  if (init.body && !(init.body instanceof FormData) && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  let response: Response;
  try { response = await fetch(`${API_BASE}${path}`, { ...init, headers }); }
  catch { throw new ApiError('Cannot connect to JHONNY AI backend. Start the FastAPI server and check VITE_API_BASE_URL.', 0); }
  if (response.status === 401) { clearApiToken(); if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent('jhonny:auth-expired')); }
  if (!response.ok) {
    throw new ApiError(await responseErrorMessage(response, `Request failed (${response.status})`), response.status);
  }
  // Some successful operations (for example a future DELETE endpoint) may intentionally have no body.
  if (response.status === 204 || response.headers.get('Content-Length') === '0') return undefined as T;
  // Successful HTTP status is not enough: reverse proxies and crashed services can
  // return HTML or an empty body. Convert that into a stable API error instead of
  // leaking a SyntaxError into page-level UI handlers.
  try {
    return await response.json() as T;
  } catch {
    throw new ApiError('The backend returned an invalid or empty response. Please retry.', 502);
  }
}
export interface ApiUser { id: string; name: string; email: string; role: 'user' | 'creator' | 'admin'; }
export async function loginApi(email: string, password: string) {
  const data = await apiRequest<{access_token:string;user:ApiUser}>('/api/auth/login', { method:'POST', body:JSON.stringify({email,password}) });
  setApiToken(data.access_token); return data.user;
}
export async function registerApi(name: string, email: string, password: string) {
  return apiRequest<ApiUser>('/api/auth/register', { method:'POST', body:JSON.stringify({name,email,password}) });
}
export async function logoutApi() {
  try { if (getApiToken()) await apiRequest('/api/auth/logout', { method:'POST' }); } finally { clearApiToken(); }
}
export function uploadApi(file: File, title: string, onProgress: (percent: number) => void): Promise<{id:string;status:string;duration:number;width:number;height:number}> {
  return new Promise((resolve,reject) => {
    const xhr = new XMLHttpRequest(); xhr.open('POST', `${API_BASE}/api/clips/upload`);
    const token = getApiToken(); if (token) xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    xhr.upload.onprogress = e => { if (e.lengthComputable) onProgress(Math.round(e.loaded/e.total*100)); };
    xhr.onerror = () => reject(new ApiError('Network error while uploading. Check that the backend is running.',0));
    xhr.onload = () => {
      let data: unknown = {}; try { data=JSON.parse(xhr.responseText) as unknown; } catch { /* malformed response */ }
      const payload = isRecord(data) ? data : {};
      if (xhr.status>=200 && xhr.status<300) {
        if (typeof payload.id !== 'string' || typeof payload.status !== 'string') { reject(new ApiError('Upload response was malformed.', 502)); return; }
        resolve(payload as {id:string;status:string;duration:number;width:number;height:number});
      } else {
        if (xhr.status===401) { clearApiToken(); if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent('jhonny:auth-expired')); }
        const message = xhr.status >= 500 ? 'The server could not complete this upload. Please try again later.' : (typeof payload.detail === 'string' ? payload.detail : `Upload failed (${xhr.status})`);
        reject(new ApiError(message,xhr.status));
      }
    };
    const form = new FormData(); form.append('file',file); form.append('title',title); xhr.send(form);
  });
}

export interface ApiClip {
  id: string; title: string; creator_name?: string; owner_id?: string; mime_type: string;
  size_bytes: number; duration: number | null; width: number | null; height: number | null;
  codec: string | null; status: string; created_at: string; moderated_at?: string | null;
  license_status?: string | null; allowed_uses?: string | string[]; expires_at?: string | null;
  platform_restrictions?: string | string[];
}
export interface ApiPage<T> { items: T[]; page: number; page_size: number; total: number; }
export interface ApiProject { id: string; owner_id: string; name: string; source_clip_id: string | null; settings: Record<string, unknown>; created_at: string; updated_at: string; }
export interface ApiRender { id: string; project_id: string; status: 'queued'|'running'|'completed'|'failed'; progress: number; error?: string | null; download_url?: string; }
export const fetchApiClips = (params: { q?: string; status?: string; sort?: string; page?: number; pageSize?: number } = {}) => {
  const query = new URLSearchParams();
  if (params.q) query.set('q', params.q);
  if (params.status) query.set('status', params.status);
  if (params.sort) query.set('sort', params.sort);
  query.set('page', String(params.page ?? 1)); query.set('page_size', String(params.pageSize ?? 24));
  return apiRequest<ApiPage<ApiClip>>(`/api/clips?${query.toString()}`);
};
export const fetchApiClip = (idOrSlug: string) => apiRequest<ApiClip & { license_id?: string }>(`/api/clips/${encodeURIComponent(idOrSlug)}`);
export const fetchMyClips = (params: { q?: string; status?: string; page?: number; pageSize?: number } = {}) => {
  const query = new URLSearchParams();
  if (params.q) query.set('q', params.q);
  if (params.status) query.set('status', params.status);
  query.set('page', String(params.page ?? 1));
  query.set('page_size', String(params.pageSize ?? 100));
  return apiRequest<ApiPage<ApiClip>>(`/api/me/clips?${query.toString()}`);
};
export const fetchApiProjects = () => apiRequest<ApiProject[]>('/api/projects');
export const createApiProject = (name: string, sourceClipId: string | null = null, settings: Record<string, unknown> = {}) =>
  apiRequest<ApiProject>('/api/projects', { method: 'POST', body: JSON.stringify({ name, source_clip_id: sourceClipId, settings }) });
export const saveApiProject = (project: ApiProject) => apiRequest<{ id: string; updated_at: string }>(`/api/projects/${encodeURIComponent(project.id)}`, { method: 'PUT', body: JSON.stringify({ name: project.name, source_clip_id: project.source_clip_id, settings: project.settings }) });
export const duplicateApiProject = (id: string) => apiRequest<ApiProject>(`/api/projects/${encodeURIComponent(id)}/duplicate`, { method: 'POST' });
export const deleteApiProject = (id: string) => apiRequest<{ deleted: boolean; id: string }>(`/api/projects/${encodeURIComponent(id)}`, { method: 'DELETE' });
export const moderateApiClip = (id: string, action: 'approve'|'reject'|'suspend'|'remove', note = '') => apiRequest<{ id: string; status: string; moderated_at: string }>(`/api/admin/clips/${encodeURIComponent(id)}/moderate`, { method: 'POST', body: JSON.stringify({ action, note }) });
export const updateApiLicense = (id: string, input: { status: 'Active'|'Revoked'|'Expired'|'Pending Review'; allowed_uses: string[]; expires_at?: string | null; platform_restrictions: string[]; verification_note: string }) => apiRequest<{ clip_id: string; status: string }>(`/api/admin/clips/${encodeURIComponent(id)}/license`, { method: 'PUT', body: JSON.stringify(input) });
export const createApiRender = (projectId: string, input: { trim_start: number; trim_end: number; width: number; height: number; aspect_ratio: string; output_format: 'mp4' }) => apiRequest<ApiRender>(`/api/projects/${encodeURIComponent(projectId)}/renders`, { method: 'POST', body: JSON.stringify(input) });
export const fetchApiRender = (id: string) => apiRequest<ApiRender>(`/api/renders/${encodeURIComponent(id)}`);
export async function downloadApiFile(path: string, filename: string) {
  const headers = new Headers(); const token = getApiToken(); if (token) headers.set('Authorization', `Bearer ${token}`);
  let response: Response;
  try { response = await fetch(`${API_BASE}${path}`, { headers }); } catch { throw new ApiError('Cannot connect to JHONNY AI backend.', 0); }
  if (response.status === 401) { clearApiToken(); if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent('jhonny:auth-expired')); }
  if (!response.ok) throw new ApiError(await responseErrorMessage(response, `Download failed (${response.status})`), response.status);
  const blob = await response.blob();
  if (!blob.size) throw new ApiError('The server returned an empty media file.', 502);
  const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url;
  const disposition = response.headers.get('Content-Disposition') || '';
  const encoded = disposition.match(/filename\*=UTF-8''([^;]+)/i)?.[1];
  const plain = disposition.match(/filename=\"?([^\";]+)\"?/i)?.[1];
  let serverFilename = encoded || plain;
  if (serverFilename) { try { serverFilename = decodeURIComponent(serverFilename); } catch { /* use server-supplied raw filename */ } }
  a.download = (serverFilename || filename).replace(/[\\/\0-\x1f]/g, '_').slice(0, 255) || 'download';
  document.body.appendChild(a); a.click(); a.remove(); window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export const currentUserApi = () => apiRequest<ApiUser & { created_at?: string }>('/api/auth/me');
export interface ApiDownloadRecord { id: string; clip_id: string; requested_use: string; created_at: string; clip_title: string; size_bytes: number; mime_type: string; }
export const fetchMyDownloads = () => apiRequest<{ items: ApiDownloadRecord[]; total: number }>('/api/me/downloads');

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

export interface ApiCreatorLicense {
  id: string;
  clip_id: string;
  status: 'Pending Review' | 'Active' | 'Revoked' | 'Expired' | string;
  allowed_uses: string;
  expires_at: string | null;
  platform_restrictions: string;
  verification_note: string;
  updated_at: string;
  clip_title: string;
  clip_status: string;
}
export const fetchMyLicenses = () => apiRequest<{ items: ApiCreatorLicense[]; total: number }>('/api/me/licenses');
