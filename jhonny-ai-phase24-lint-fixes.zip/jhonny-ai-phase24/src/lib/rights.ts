/**
 * Rights and visibility rules shared by browse, search, clip detail and download.
 *
 * These are client-side checks for display and for the download action in this
 * build. They are NOT production security: the server must re-check publication
 * status, license validity and the viewer's permissions on every request, and
 * must issue short-lived signed URLs for media.
 */
import type { Clip } from '../types';

export type LicenseState = 'valid' | 'expired' | 'inactive' | 'missing';

export type DenyReason =
  | 'not_published'
  | 'license_missing'
  | 'license_inactive'
  | 'license_expired'
  | 'no_media';

export type AccessDecision =
  | { allowed: true }
  | { allowed: false; reason: DenyReason; message: string };

const LICENSE_STATES_THAT_CAN_BE_VALID = new Set(['Active', 'Expiring']);

export function getLicenseState(clip: Clip, now: number = Date.now()): LicenseState {
  const license = clip.licenseInfo;
  if (!license) return 'missing';
  if (!LICENSE_STATES_THAT_CAN_BE_VALID.has(license.status)) return 'inactive';
  const expires = Date.parse(license.expiresAt);
  // An unreadable expiry date fails closed.
  if (Number.isNaN(expires) || expires <= now) return 'expired';
  return 'valid';
}

/** A clip may appear in public browse/search results only when published with a valid license. */
export function isPublicClip(clip: Clip, now: number = Date.now()): boolean {
  return clip.status === 'Published' && getLicenseState(clip, now) === 'valid';
}

/** Admins may open any clip for review; everyone else may only open public clips. */
export function canViewClipDetail(clip: Clip, role: string | null | undefined, now: number = Date.now()): boolean {
  if (isPublicClip(clip, now)) return true;
  return role === 'admin';
}

const UNAVAILABLE_MESSAGES: Record<DenyReason, string> = {
  not_published: 'This clip is not published, so it cannot be downloaded.',
  license_missing: 'This clip has no license record, so it cannot be downloaded.',
  license_inactive: 'This clip\'s license is not active, so it cannot be downloaded.',
  license_expired: 'This clip\'s license has expired, so it cannot be downloaded.',
  no_media:
    'The media file for this clip is not available in this build. Downloads require the production media service.'
};

/**
 * Decides whether a download may start. Callers must use this result in the
 * download action itself, not only to hide buttons.
 */
export function canDownloadClip(clip: Clip, now: number = Date.now()): AccessDecision {
  if (clip.status !== 'Published') return deny('not_published');
  const state = getLicenseState(clip, now);
  if (state === 'missing') return deny('license_missing');
  if (state === 'inactive') return deny('license_inactive');
  if (state === 'expired') return deny('license_expired');
  // A media URL is only ever a server-issued, signed https URL. Mock data has none.
  if (!isHttpsUrl(clip.mediaUrl)) return deny('no_media');
  return { allowed: true };
}

/** Only well-formed https URLs may be used as a download target (no javascript:, data:, blob: or http:). */
export function isHttpsUrl(value: string | undefined): value is string {
  if (!value) return false;
  try {
    return new URL(value).protocol === 'https:';
  } catch {
    return false;
  }
}

function deny(reason: DenyReason): AccessDecision {
  return { allowed: false, reason, message: UNAVAILABLE_MESSAGES[reason] };
}

export function describeUnavailable(clip: Clip, now: number = Date.now()): string | null {
  const decision = canDownloadClip(clip, now);
  return decision.allowed ? null : decision.message;
}
