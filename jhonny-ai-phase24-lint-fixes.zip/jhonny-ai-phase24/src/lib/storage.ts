/**
 * Centralized, defensive access to browser storage for JHONNY AI.
 *
 * Every persisted collection is written as a versioned envelope:
 *   { schemaVersion: 1, savedAt: ISO string, data: <payload> }
 *
 * Reads never throw. Invalid JSON, wrong shapes, unavailable storage and
 * unsupported (newer) schema versions all fall back to safe defaults. Corrupt
 * raw values are preserved once under `<key>.corrupt` before being replaced.
 *
 * IMPORTANT: localStorage is per-browser and not a security boundary. It is
 * suitable only for demo persistence. Production needs a server-side store.
 */

export const STORAGE_SCHEMA_VERSION = 1;

export const STORAGE_KEYS = {
  currentUser: 'jhonny_current_user',
  clips: 'jhonny_clips',
  creators: 'jhonny_creators',
  licenses: 'jhonny_licenses',
  reports: 'jhonny_reports',
  savedClips: 'jhonny_saved_clips',
  downloads: 'jhonny_downloads',
  processingJobs: 'jhonny_processing_jobs',
  projects: 'jhonny_projects'
} as const;

export interface StorageAdapter {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

/** Returns a working localStorage, or null if it is missing or throws (private mode, disabled cookies). */
export function getBrowserStorage(): StorageAdapter | null {
  try {
    const s = (globalThis as { localStorage?: StorageAdapter }).localStorage;
    if (!s) return null;
    const probe = '__jhonny_probe__';
    s.setItem(probe, '1');
    s.removeItem(probe);
    return s;
  } catch {
    return null;
  }
}

export type LoadStatus =
  | 'loaded'        // stored data was valid
  | 'empty'         // nothing stored yet; defaults used
  | 'migrated'      // legacy (unversioned) data was read; next save writes the envelope
  | 'corrupt'       // stored data was unreadable; defaults used, raw value backed up
  | 'unsupported'   // stored by a newer schema version; defaults used and writes are blocked
  | 'unavailable';  // storage itself is not accessible; defaults used and writes are blocked

export interface LoadResult<T> {
  value: T;
  status: LoadStatus;
  /** Number of stored items rejected by validation. */
  droppedCount: number;
  /** False when saving would overwrite data we could not read safely. */
  writable: boolean;
}

interface Envelope {
  schemaVersion: number;
  savedAt: string;
  data: unknown;
}

const isEnvelope = (x: unknown): x is Envelope =>
  typeof x === 'object' &&
  x !== null &&
  !Array.isArray(x) &&
  typeof (x as Envelope).schemaVersion === 'number' &&
  'data' in (x as object);

/** Generates an identifier that is unlikely to collide with existing ids. */
export function makeId(prefix: string): string {
  const random =
    typeof globalThis.crypto?.randomUUID === 'function'
      ? globalThis.crypto.randomUUID().slice(0, 8)
      : Math.random().toString(36).slice(2, 10);
  return `${prefix}-${Date.now().toString(36)}-${random}`;
}

interface ReadRaw {
  status: LoadStatus;
  parsed?: unknown;
  writable: boolean;
}

function readRaw(key: string, storage: StorageAdapter | null): ReadRaw {
  if (!storage) return { status: 'unavailable', writable: false };

  let raw: string | null;
  try {
    raw = storage.getItem(key);
  } catch {
    return { status: 'unavailable', writable: false };
  }
  if (raw === null) return { status: 'empty', writable: true };

  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    backupCorrupt(key, raw, storage);
    return { status: 'corrupt', writable: true };
  }

  if (isEnvelope(parsed)) {
    if (parsed.schemaVersion > STORAGE_SCHEMA_VERSION) {
      return { status: 'unsupported', writable: false };
    }
    return { status: 'loaded', parsed: parsed.data, writable: true };
  }

  // Legacy, unversioned data written by earlier builds.
  return { status: 'migrated', parsed, writable: true };
}

function backupCorrupt(key: string, raw: string, storage: StorageAdapter): void {
  try {
    storage.setItem(`${key}.corrupt`, raw);
  } catch {
    // Backup is best-effort; the original value is replaced regardless.
  }
}

/**
 * Loads an array collection. Items failing `isItem` are dropped. When `idOf`
 * is supplied, missing or duplicate ids are repaired so React keys stay unique.
 * An empty result falls back to `fallback`, matching the app's seed-data behavior.
 */
export function loadCollection<T>(
  key: string,
  isItem: (x: unknown) => x is T,
  fallback: () => T[],
  options: { storage?: StorageAdapter | null; idOf?: (item: T) => string | undefined; repairPrefix?: string } = {}
): LoadResult<T[]> {
  const storage = options.storage === undefined ? getBrowserStorage() : options.storage;
  const read = readRaw(key, storage);

  if (read.status === 'corrupt' || read.status === 'unsupported' || read.status === 'unavailable' || read.status === 'empty') {
    return { value: fallback(), status: read.status, droppedCount: 0, writable: read.writable };
  }

  if (!Array.isArray(read.parsed)) {
    if (storage) backupCorrupt(key, JSON.stringify(read.parsed), storage);
    return { value: fallback(), status: 'corrupt', droppedCount: 0, writable: true };
  }

  const accepted: T[] = [];
  let dropped = 0;
  for (const candidate of read.parsed) {
    if (isItem(candidate)) accepted.push(candidate);
    else dropped += 1;
  }

  if (accepted.length === 0) {
    return { value: fallback(), status: dropped > 0 ? 'corrupt' : 'empty', droppedCount: dropped, writable: true };
  }

  let value = accepted;
  if (options.idOf) {
    const prefix = options.repairPrefix || key;
    const seen = new Set<string>();
    value = accepted.map((item, index) => {
      const id = options.idOf!(item);
      if (id && !seen.has(id)) {
        seen.add(id);
        return item;
      }
      const repaired = `${prefix}-${index}-${Math.random().toString(36).slice(2, 7)}`;
      seen.add(repaired);
      return { ...(item as object), id: repaired } as T;
    });
  }

  return {
    value,
    // Dropped items mean data loss, which must be visible even for legacy payloads.
    status: dropped > 0 ? 'corrupt' : read.status === 'migrated' ? 'migrated' : 'loaded',
    droppedCount: dropped,
    writable: true
  };
}

/** Loads a single validated value (for example the current session user). */
export function loadValue<T>(
  key: string,
  isValue: (x: unknown) => x is T,
  fallback: () => T | null,
  options: { storage?: StorageAdapter | null } = {}
): LoadResult<T | null> {
  const storage = options.storage === undefined ? getBrowserStorage() : options.storage;
  const read = readRaw(key, storage);

  if (read.status !== 'loaded' && read.status !== 'migrated') {
    return { value: fallback(), status: read.status, droppedCount: 0, writable: read.writable };
  }
  if (isValue(read.parsed)) {
    return { value: read.parsed, status: read.status, droppedCount: 0, writable: true };
  }
  return { value: fallback(), status: 'corrupt', droppedCount: 1, writable: true };
}

/** Writes a value inside a versioned envelope. Returns false if storage rejects it (quota, blocked). */
export function saveVersioned(
  key: string,
  data: unknown,
  options: { storage?: StorageAdapter | null; now?: Date } = {}
): boolean {
  const storage = options.storage === undefined ? getBrowserStorage() : options.storage;
  if (!storage) return false;
  const envelope: Envelope = {
    schemaVersion: STORAGE_SCHEMA_VERSION,
    savedAt: (options.now ?? new Date()).toISOString(),
    data
  };
  try {
    storage.setItem(key, JSON.stringify(envelope));
    return true;
  } catch (error) {
    console.warn(`[storage] could not save "${key}":`, error);
    return false;
  }
}

/** Removes a key. Failures are ignored because a stale value is recoverable on next load. */
export function clearKey(key: string, options: { storage?: StorageAdapter | null } = {}): void {
  const storage = options.storage === undefined ? getBrowserStorage() : options.storage;
  try {
    storage?.removeItem(key);
  } catch {
    // ignore
  }
}
