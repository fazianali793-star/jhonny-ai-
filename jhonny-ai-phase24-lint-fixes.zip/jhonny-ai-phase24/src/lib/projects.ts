/**
 * User studio projects. A project stores editing choices (name, trim window,
 * hook text, source clip reference). It does NOT contain rendered video; export
 * is not implemented in this build.
 *
 * Every mutation requires the acting user to be the project owner.
 */

export const PROJECT_NAME_MAX = 120;
export const HOOK_TEXT_MAX = 120;
export const PROJECT_MAX_SECONDS = 3600;

export type ProjectStatus = 'draft' | 'saved';

export interface Project {
  id: string;
  ownerId: string;
  name: string;
  sourceClipId: string | null;
  trimStart: number;
  trimEnd: number;
  hookText: string;
  status: ProjectStatus;
  createdAt: string;
  updatedAt: string;
}

export interface ProjectInput {
  name: string;
  sourceClipId: string | null;
  trimStart: number;
  trimEnd: number;
  hookText: string;
}

export type ProjectResult =
  | { ok: true; project: Project }
  | { ok: false; error: string };

export function validateProjectInput(input: ProjectInput, sourceDurationSeconds?: number): string[] {
  const errors: string[] = [];
  const name = input.name.trim();
  if (!name) errors.push('Project name is required.');
  if (name.length > PROJECT_NAME_MAX) errors.push(`Project name must be ${PROJECT_NAME_MAX} characters or fewer.`);
  if (!Number.isFinite(input.trimStart) || input.trimStart < 0) errors.push('Start time must be 0 or greater.');
  if (!Number.isFinite(input.trimEnd) || input.trimEnd <= input.trimStart) errors.push('End time must be after the start time.');
  if (Number.isFinite(input.trimEnd) && input.trimEnd > PROJECT_MAX_SECONDS) errors.push('End time is too large.');
  if (sourceDurationSeconds !== undefined && Number.isFinite(input.trimEnd) && input.trimEnd > sourceDurationSeconds) {
    errors.push('End time is beyond the length of the source clip.');
  }
  if (input.hookText.length > HOOK_TEXT_MAX) errors.push(`Hook text must be ${HOOK_TEXT_MAX} characters or fewer.`);
  return errors;
}

function normalize(input: ProjectInput): ProjectInput {
  return {
    name: input.name.trim(),
    sourceClipId: input.sourceClipId || null,
    trimStart: Number(input.trimStart),
    trimEnd: Number(input.trimEnd),
    hookText: input.hookText.trim()
  };
}

export function createProject(
  ownerId: string,
  input: ProjectInput,
  options: { id: string; now?: Date; sourceDurationSeconds?: number }
): ProjectResult {
  const errors = validateProjectInput(input, options.sourceDurationSeconds);
  if (errors.length) return { ok: false, error: errors[0] };
  const at = (options.now ?? new Date()).toISOString();
  const data = normalize(input);
  return {
    ok: true,
    project: {
      id: options.id,
      ownerId,
      ...data,
      status: 'draft',
      createdAt: at,
      updatedAt: at
    }
  };
}

export function isOwner(project: Project, userId: string | null | undefined): boolean {
  return !!userId && project.ownerId === userId;
}

export function updateProject(
  project: Project,
  patch: Partial<ProjectInput>,
  actorId: string | null | undefined,
  options: { now?: Date; sourceDurationSeconds?: number } = {}
): ProjectResult {
  if (!isOwner(project, actorId)) return { ok: false, error: 'You can only edit your own projects.' };
  const merged: ProjectInput = normalize({
    name: patch.name ?? project.name,
    sourceClipId: patch.sourceClipId !== undefined ? patch.sourceClipId : project.sourceClipId,
    trimStart: patch.trimStart ?? project.trimStart,
    trimEnd: patch.trimEnd ?? project.trimEnd,
    hookText: patch.hookText ?? project.hookText
  });
  const errors = validateProjectInput(merged, options.sourceDurationSeconds);
  if (errors.length) return { ok: false, error: errors[0] };
  return {
    ok: true,
    project: { ...project, ...merged, status: 'saved', updatedAt: (options.now ?? new Date()).toISOString() }
  };
}

export function duplicateProject(
  project: Project,
  actorId: string | null | undefined,
  options: { id: string; now?: Date }
): ProjectResult {
  if (!isOwner(project, actorId)) return { ok: false, error: 'You can only duplicate your own projects.' };
  const suffix = ' (copy)';
  const base = project.name.slice(0, PROJECT_NAME_MAX - suffix.length);
  const at = (options.now ?? new Date()).toISOString();
  return {
    ok: true,
    project: { ...project, id: options.id, name: base + suffix, status: 'draft', createdAt: at, updatedAt: at }
  };
}

/** Returns only the projects that belong to `ownerId`, most recently updated first. */
export function projectsForOwner(all: readonly Project[], ownerId: string | null | undefined): Project[] {
  if (!ownerId) return [];
  return all
    .filter(p => p.ownerId === ownerId)
    .sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt) || a.id.localeCompare(b.id));
}

export function findOwnedProject(all: readonly Project[], id: string, ownerId: string | null | undefined): Project | undefined {
  return all.find(p => p.id === id && isOwner(p, ownerId));
}

export function removeOwnedProject(
  all: readonly Project[],
  id: string,
  actorId: string | null | undefined
): { ok: true; projects: Project[] } | { ok: false; error: string } {
  const target = all.find(p => p.id === id);
  if (!target) return { ok: false, error: 'Project not found.' };
  if (!isOwner(target, actorId)) return { ok: false, error: 'You can only delete your own projects.' };
  return { ok: true, projects: all.filter(p => p.id !== id) };
}
