/**
 * UI route gating. The current user comes from browser storage or the demo role
 * switcher, so it is NOT trusted authorization. These checks hide admin screens
 * from ordinary visitors; the server must enforce the same rules on every API call.
 */
export type RouteRequirement = 'public' | 'signed_in' | 'creator' | 'admin';

export interface SessionUser {
  role: 'user' | 'creator' | 'admin';
}

export type RouteDecision =
  | { allowed: true }
  | { allowed: false; reason: 'login_required' | 'forbidden' };

export function decideRouteAccess(requirement: RouteRequirement, user: SessionUser | null | undefined): RouteDecision {
  if (requirement === 'public') return { allowed: true };
  if (!user) return { allowed: false, reason: 'login_required' };
  if (requirement === 'signed_in') return { allowed: true };
  if (requirement === 'creator') {
    return user.role === 'creator' || user.role === 'admin' ? { allowed: true } : { allowed: false, reason: 'forbidden' };
  }
  return user.role === 'admin' ? { allowed: true } : { allowed: false, reason: 'forbidden' };
}

/** Maps a path to the access it requires. Unknown paths are public so the 404 page can render. */
export function requirementForPath(path: string): RouteRequirement {
  if (path === '/admin' || path.startsWith('/admin/')) return 'admin';
  if (path === '/creator' || path.startsWith('/creator/')) return 'creator';
  if (path === '/studio' || path.startsWith('/studio/')) return 'signed_in';
  if (path === '/dashboard') return 'signed_in';
  return 'public';
}
