/**
 * Demo-session switches. The demo role switcher sets the signed-in user in the
 * browser without any server check, so the most privileged demo persona is only
 * offered in development builds. Production admin access needs real
 * authentication and server-side role checks.
 */
const isDev = typeof import.meta !== 'undefined' && (import.meta as { env?: { DEV?: boolean } }).env?.DEV === true;

export const DEMO_PERSONAS_ENABLED: boolean = isDev;
export const DEMO_ADMIN_PERSONA_ENABLED: boolean = DEMO_PERSONAS_ENABLED;

/** Email/password sign-in is not connected to an identity provider in this build. */
export const EMAIL_SIGN_IN_CONFIGURED = false;
