/**
 * Who may change a clip, and which status changes are allowed.
 *
 * Like the rest of the client-side checks these are NOT production security:
 * the signed-in user comes from browser storage. The server must repeat every
 * rule on each request.
 */
import type { Clip, ClipStatus } from '../types';
import { getLicenseState } from './rights';

export interface Actor {
  role: 'user' | 'creator' | 'admin';
  creatorId?: string;
}

export type ChangeDecision = { allowed: true } | { allowed: false; message: string };

const deny = (message: string): ChangeDecision => ({ allowed: false, message });

export function isAdmin(actor: Actor | null | undefined): boolean {
  return !!actor && actor.role === 'admin';
}

export function ownsClip(clip: Clip, actor: Actor | null | undefined): boolean {
  return !!actor && actor.role === 'creator' && !!actor.creatorId && actor.creatorId === clip.creatorId;
}

/** Admins may edit any clip; a creator may edit only their own. Everyone else may not save edits. */
export function canEditClip(clip: Clip, actor: Actor | null | undefined): boolean {
  return isAdmin(actor) || ownsClip(clip, actor);
}

/**
 * Status change rules:
 * - Nothing becomes Published here except restoring a Disabled clip, and only
 *   when its license is still valid. New submissions go live only through
 *   approveClip (administrator review).
 * - Takedown is final in this build; it cannot be undone from the UI.
 * - Creators may only disable their own published clips, and only while their
 *   creator account is Active. They cannot restore a disabled clip, because
 *   it may have been disabled by an administrator or by a creator suspension.
 */
export function decideStatusChange(
  clip: Clip,
  target: ClipStatus,
  actor: Actor | null | undefined,
  options: { creatorActive?: boolean; now?: number } = {}
): ChangeDecision {
  if (!actor) return deny('Sign in to change a clip.');
  if (clip.status === target) return deny(`This clip is already ${target}.`);
  if (clip.status === 'Takedown') return deny('A clip in takedown cannot be changed here.');

  if (target === 'Pending' || target === 'Processing') {
    return deny('A clip cannot be moved back to review or processing.');
  }

  if (target === 'Published') {
    if (!isAdmin(actor)) return deny('Only an administrator can restore a disabled clip.');
    if (clip.status !== 'Disabled') return deny('Only disabled clips can be restored. New submissions need license approval.');
    if (getLicenseState(clip, options.now) !== 'valid') {
      return deny('This clip\'s license is not valid, so it cannot be published.');
    }
    return { allowed: true };
  }

  if (isAdmin(actor)) return { allowed: true };

  if (ownsClip(clip, actor)) {
    if (options.creatorActive === false) return deny('Your creator account is not active.');
    if (target === 'Disabled' && clip.status === 'Published') return { allowed: true };
    return deny('Creators can only disable their own published clips.');
  }

  return deny('You do not have permission to change this clip.');
}
